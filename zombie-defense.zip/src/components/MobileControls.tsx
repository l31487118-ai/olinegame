import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Crosshair,
  Car,
  LogOut,
  Bell,
  Compass,
  Camera,
  Pause,
  Play,
  RotateCcw,
  Zap,
  Target,
  Flame,
} from 'lucide-react';
import { GameEngine3D } from '../game/GameEngine3D';
import { HudStats, WeaponType } from '../game/types';

interface MobileControlsProps {
  engine: GameEngine3D | null;
  stats: HudStats;
  onOpenMap?: () => void;
  onTogglePause?: () => void;
  onToggleCamera?: () => void;
  isPaused?: boolean;
}

export const MobileControls: React.FC<MobileControlsProps> = ({
  engine,
  stats,
  onOpenMap,
  onTogglePause,
  onToggleCamera,
  isPaused,
}) => {
  // Joystick state
  const joystickBaseRef = useRef<HTMLDivElement>(null);
  const [joystickActive, setJoystickActive] = useState(false);
  const [joystickPos, setJoystickPos] = useState({ x: 0, y: 0 });
  const touchIdRef = useRef<number | null>(null);
  const baseCenterRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  // Aim drag state (Right side)
  const aimTouchIdRef = useRef<number | null>(null);
  const aimCenterRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const [aimActive, setAimActive] = useState(false);
  const [aimPos, setAimPos] = useState({ x: 0, y: 0 });

  // Auto fire continuous interval ref
  const fireIntervalRef = useRef<number | null>(null);

  // Left Joystick Touch Handlers
  const handleJoystickTouchStart = useCallback(
    (e: React.TouchEvent<HTMLDivElement>) => {
      e.stopPropagation();
      e.preventDefault();
      if (!engine || touchIdRef.current !== null) return;

      const touch = e.changedTouches[0];
      touchIdRef.current = touch.identifier;

      if (joystickBaseRef.current) {
        const rect = joystickBaseRef.current.getBoundingClientRect();
        baseCenterRef.current = {
          x: rect.left + rect.width / 2,
          y: rect.top + rect.height / 2,
        };
      }

      const dx = touch.clientX - baseCenterRef.current.x;
      const dy = touch.clientY - baseCenterRef.current.y;
      const maxRadius = 48;
      const dist = Math.hypot(dx, dy);
      const clampedDist = Math.min(dist, maxRadius);
      const angle = Math.atan2(dy, dx);

      const knobX = Math.cos(angle) * clampedDist;
      const knobY = Math.sin(angle) * clampedDist;

      setJoystickPos({ x: knobX, y: knobY });
      setJoystickActive(true);

      const normX = knobX / maxRadius;
      const normY = knobY / maxRadius;
      engine.setVirtualMove(normX, normY);
    },
    [engine]
  );

  const handleJoystickTouchMove = useCallback(
    (e: TouchEvent) => {
      if (touchIdRef.current === null || !engine) return;

      for (let i = 0; i < e.changedTouches.length; i++) {
        const touch = e.changedTouches[i];
        if (touch.identifier === touchIdRef.current) {
          e.preventDefault();
          const dx = touch.clientX - baseCenterRef.current.x;
          const dy = touch.clientY - baseCenterRef.current.y;
          const maxRadius = 48;
          const dist = Math.hypot(dx, dy);
          const clampedDist = Math.min(dist, maxRadius);
          const angle = Math.atan2(dy, dx);

          const knobX = Math.cos(angle) * clampedDist;
          const knobY = Math.sin(angle) * clampedDist;

          setJoystickPos({ x: knobX, y: knobY });

          const normX = knobX / maxRadius;
          const normY = knobY / maxRadius;
          engine.setVirtualMove(normX, normY);
          break;
        }
      }
    },
    [engine]
  );

  const handleJoystickTouchEnd = useCallback(
    (e: TouchEvent) => {
      if (touchIdRef.current === null || !engine) return;

      for (let i = 0; i < e.changedTouches.length; i++) {
        const touch = e.changedTouches[i];
        if (touch.identifier === touchIdRef.current) {
          touchIdRef.current = null;
          setJoystickPos({ x: 0, y: 0 });
          setJoystickActive(false);
          engine.setVirtualMove(0, 0);
          break;
        }
      }
    },
    [engine]
  );

  // Right Aim Stick Handlers
  const handleAimTouchStart = useCallback(
    (e: React.TouchEvent<HTMLDivElement>) => {
      e.stopPropagation();
      e.preventDefault();
      if (!engine || aimTouchIdRef.current !== null) return;

      const touch = e.changedTouches[0];
      aimTouchIdRef.current = touch.identifier;

      const rect = e.currentTarget.getBoundingClientRect();
      aimCenterRef.current = {
        x: rect.left + rect.width / 2,
        y: rect.top + rect.height / 2,
      };

      const dx = touch.clientX - aimCenterRef.current.x;
      const dy = touch.clientY - aimCenterRef.current.y;
      const maxRadius = 42;
      const dist = Math.hypot(dx, dy);
      const clampedDist = Math.min(dist, maxRadius);
      const angle = Math.atan2(dy, dx);

      const knobX = Math.cos(angle) * clampedDist;
      const knobY = Math.sin(angle) * clampedDist;

      setAimPos({ x: knobX, y: knobY });
      setAimActive(true);

      // In 3D space: X is East/West, Y in 2D is Z in 3D (South/North)
      // Math.atan2(dx, dy) produces heading angle where 0 is South (+Z), PI/2 is East (+X)
      const aimHeading = Math.atan2(knobX, knobY);
      engine.setVirtualAim(aimHeading);
    },
    [engine]
  );

  const handleAimTouchMove = useCallback(
    (e: TouchEvent) => {
      if (aimTouchIdRef.current === null || !engine) return;

      for (let i = 0; i < e.changedTouches.length; i++) {
        const touch = e.changedTouches[i];
        if (touch.identifier === aimTouchIdRef.current) {
          e.preventDefault();
          const dx = touch.clientX - aimCenterRef.current.x;
          const dy = touch.clientY - aimCenterRef.current.y;
          const maxRadius = 42;
          const dist = Math.hypot(dx, dy);
          const clampedDist = Math.min(dist, maxRadius);
          const angle = Math.atan2(dy, dx);

          const knobX = Math.cos(angle) * clampedDist;
          const knobY = Math.sin(angle) * clampedDist;

          setAimPos({ x: knobX, y: knobY });

          const aimHeading = Math.atan2(knobX, knobY);
          engine.setVirtualAim(aimHeading);
          break;
        }
      }
    },
    [engine]
  );

  const handleAimTouchEnd = useCallback(
    (e: TouchEvent) => {
      if (aimTouchIdRef.current === null || !engine) return;

      for (let i = 0; i < e.changedTouches.length; i++) {
        const touch = e.changedTouches[i];
        if (touch.identifier === aimTouchIdRef.current) {
          aimTouchIdRef.current = null;
          setAimPos({ x: 0, y: 0 });
          setAimActive(false);
          break;
        }
      }
    },
    [engine]
  );

  // Setup window touchmove/touchend listeners
  useEffect(() => {
    window.addEventListener('touchmove', handleJoystickTouchMove, { passive: false });
    window.addEventListener('touchend', handleJoystickTouchEnd);
    window.addEventListener('touchcancel', handleJoystickTouchEnd);

    window.addEventListener('touchmove', handleAimTouchMove, { passive: false });
    window.addEventListener('touchend', handleAimTouchEnd);
    window.addEventListener('touchcancel', handleAimTouchEnd);

    return () => {
      window.removeEventListener('touchmove', handleJoystickTouchMove);
      window.removeEventListener('touchend', handleJoystickTouchEnd);
      window.removeEventListener('touchcancel', handleJoystickTouchEnd);

      window.removeEventListener('touchmove', handleAimTouchMove);
      window.removeEventListener('touchend', handleAimTouchEnd);
      window.removeEventListener('touchcancel', handleAimTouchEnd);

      if (fireIntervalRef.current) {
        clearInterval(fireIntervalRef.current);
      }
    };
  }, [handleJoystickTouchMove, handleJoystickTouchEnd, handleAimTouchMove, handleAimTouchEnd]);

  // Fire Button Handlers
  const handleFireStart = (e: React.TouchEvent | React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    if (!engine) return;

    engine.setVirtualFire(true);

    if (fireIntervalRef.current) clearInterval(fireIntervalRef.current);
    fireIntervalRef.current = window.setInterval(() => {
      if (engine) engine.setVirtualFire(true);
    }, 110);
  };

  const handleFireEnd = (e: React.TouchEvent | React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    if (!engine) return;

    engine.setVirtualFire(false);
    if (fireIntervalRef.current) {
      clearInterval(fireIntervalRef.current);
      fireIntervalRef.current = null;
    }
  };

  const weaponsList: { type: WeaponType; label: string; key: string }[] = [
    { type: 'pistol', label: 'PISTOL', key: '1' },
    { type: 'shotgun', label: 'SHOTGUN', key: '2' },
    { type: 'rifle', label: 'RIFLE', key: '3' },
    { type: 'plasma', label: 'PLASMA', key: '4' },
    { type: 'rpg', label: 'RPG', key: '5' },
  ];

  return (
    <div className="absolute inset-0 pointer-events-none select-none z-20 flex flex-col justify-between p-2 md:p-4">
      {/* Top Mobile Shortcut Buttons (Camera, Map, Pause) */}
      <div className="flex items-center justify-end gap-2 pointer-events-auto mt-16 md:mt-20">
        {onToggleCamera && (
          <button
            onClick={onToggleCamera}
            className="p-2.5 rounded bg-black/60 border border-white/20 text-zinc-300 hover:text-white active:scale-95 transition-transform flex items-center gap-1.5 shadow-lg backdrop-blur-sm"
            title="Toggle Camera Mode"
          >
            <Camera className="w-4 h-4 text-cyan-400" />
            <span className="text-[10px] font-mono font-bold uppercase hidden xs:inline">
              {stats.cameraMode === 'action' ? '3RD-PERSON' : 'ISO'}
            </span>
          </button>
        )}

        {onOpenMap && (
          <button
            onClick={onOpenMap}
            className="p-2.5 rounded bg-black/60 border border-amber-500/40 text-amber-400 hover:text-amber-300 active:scale-95 transition-transform flex items-center gap-1.5 shadow-lg backdrop-blur-sm"
            title="Open Tactical Map"
          >
            <Compass className="w-4 h-4 animate-spin-slow" />
            <span className="text-[10px] font-mono font-bold uppercase hidden xs:inline">MAP</span>
          </button>
        )}

        {onTogglePause && (
          <button
            onClick={onTogglePause}
            className="p-2.5 rounded bg-black/60 border border-white/20 text-zinc-300 hover:text-white active:scale-95 transition-transform flex items-center gap-1.5 shadow-lg backdrop-blur-sm"
            title={isPaused ? 'Resume Game' : 'Pause Game'}
          >
            {isPaused ? <Play className="w-4 h-4 text-emerald-400" /> : <Pause className="w-4 h-4 text-zinc-400" />}
          </button>
        )}
      </div>

      {/* Middle Floating Vehicle Notification / Action Prompts */}
      <div className="flex flex-col items-center justify-center gap-2 pointer-events-none my-auto">
        {/* Near Car Enter Prompt */}
        {!stats.isDriving && stats.nearCarId && (
          <button
            onClick={() => engine?.enterNearestCar()}
            className="pointer-events-auto px-5 py-3 rounded-full bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-syne font-black text-sm tracking-wider uppercase shadow-[0_0_25px_rgba(245,158,11,0.6)] border-2 border-amber-300 flex items-center gap-2.5 active:scale-95 transition-transform animate-bounce"
          >
            <Car className="w-5 h-5 text-black" />
            <span>ENTER {stats.nearCarName || 'VEHICLE'} [TAP]</span>
          </button>
        )}

        {/* In Car Driving Status & Exit / Horn Buttons */}
        {stats.isDriving && (
          <div className="pointer-events-auto flex items-center gap-2.5 bg-black/80 border border-cyan-500/60 p-2 rounded-xl backdrop-blur-md shadow-[0_0_20px_rgba(6,182,212,0.3)]">
            <button
              onClick={() => engine?.exitCar()}
              className="px-4 py-2.5 rounded-lg bg-red-600/90 hover:bg-red-500 text-white font-syne font-bold text-xs uppercase flex items-center gap-1.5 active:scale-95 transition-transform border border-red-400 shadow-md"
            >
              <LogOut className="w-4 h-4" />
              <span>EXIT CAR</span>
            </button>

            <button
              onClick={() => engine?.toggleCarHorn()}
              className="px-4 py-2.5 rounded-lg bg-cyan-600/90 hover:bg-cyan-500 text-white font-syne font-bold text-xs uppercase flex items-center gap-1.5 active:scale-95 transition-transform border border-cyan-400 shadow-md"
            >
              <Bell className="w-4 h-4 animate-wiggle" />
              <span>HONK</span>
            </button>
          </div>
        )}
      </div>

      {/* Bottom Area: Controls Bar (Left Joystick, Quick Weapons Center, Right Action & Aim Pad) */}
      <div className="flex items-end justify-between w-full pointer-events-none pb-2">
        {/* Left Joystick Area */}
        <div className="pointer-events-auto flex flex-col items-center">
          <div className="text-[10px] font-mono text-zinc-400 mb-1 font-bold tracking-wider flex items-center gap-1">
            {stats.isDriving ? (
              <span className="text-cyan-400">STEER &amp; DRIVE</span>
            ) : (
              <span className="text-zinc-400">MOVE</span>
            )}
          </div>

          <div
            ref={joystickBaseRef}
            onTouchStart={handleJoystickTouchStart}
            className="w-32 h-32 rounded-full bg-black/50 border-2 border-white/20 relative flex items-center justify-center backdrop-blur-md shadow-[0_0_20px_rgba(0,0,0,0.5)] touch-none active:border-[var(--accent)]"
          >
            {/* Compass guides */}
            <div className="absolute top-2 text-[9px] font-mono text-zinc-500 font-bold">
              {stats.isDriving ? 'W (GAS)' : 'W'}
            </div>
            <div className="absolute bottom-2 text-[9px] font-mono text-zinc-500 font-bold">
              {stats.isDriving ? 'S (BRAKE)' : 'S'}
            </div>
            <div className="absolute left-2 text-[9px] font-mono text-zinc-500 font-bold">A</div>
            <div className="absolute right-2 text-[9px] font-mono text-zinc-500 font-bold">D</div>

            {/* Crosshair grid lines */}
            <div className="absolute w-full h-[1px] bg-white/10" />
            <div className="absolute h-full w-[1px] bg-white/10" />

            {/* Draggable Knob */}
            <div
              className={`w-14 h-14 rounded-full border-2 transition-transform duration-75 flex items-center justify-center shadow-lg ${
                stats.isDriving
                  ? 'bg-cyan-500/80 border-cyan-300 shadow-[0_0_15px_rgba(6,182,212,0.6)]'
                  : 'bg-[var(--accent)]/80 border-red-300 shadow-[0_0_15px_rgba(255,62,62,0.6)]'
              }`}
              style={{
                transform: `translate(${joystickPos.x}px, ${joystickPos.y}px)`,
              }}
            >
              <div className="w-4 h-4 rounded-full bg-white/90" />
            </div>
          </div>
        </div>

        {/* Center: Quick Weapon Switch Bar */}
        <div className="pointer-events-auto flex items-center gap-1 bg-black/70 border border-white/15 p-1 rounded-xl backdrop-blur-md mb-2 max-w-[260px] xs:max-w-none overflow-x-auto">
          {weaponsList.map((w) => {
            const isUnlocked = !!stats.unlockedWeapons[w.type];
            const isActive = stats.activeWeapon === w.type;
            const ammoCount = w.type === 'pistol' ? '∞' : stats.ammo[w.type];

            return (
              <button
                key={w.type}
                disabled={!isUnlocked}
                onClick={() => isUnlocked && engine?.selectWeapon(w.type)}
                className={`px-2.5 py-1.5 rounded flex flex-col items-center justify-center transition-all ${
                  isActive
                    ? 'bg-[var(--accent)] text-white shadow-[0_0_12px_rgba(255,62,62,0.5)] border border-red-400'
                    : isUnlocked
                    ? 'bg-white/5 hover:bg-white/10 text-zinc-300 border border-transparent'
                    : 'bg-black/30 text-zinc-600 opacity-40 border border-transparent'
                }`}
              >
                <span className="text-[9px] font-syne font-extrabold uppercase">{w.label}</span>
                <span className="text-[8px] font-mono font-bold text-zinc-300">{ammoCount}</span>
              </button>
            );
          })}
        </div>

        {/* Right Area: Aim Joystick + Fire Button */}
        <div className="pointer-events-auto flex items-center gap-2">
          {/* Virtual Aim Pad */}
          {!stats.isDriving && (
            <div className="flex flex-col items-center">
              <div className="text-[10px] font-mono text-zinc-400 mb-1 font-bold tracking-wider">
                AIM
              </div>
              <div
                onTouchStart={handleAimTouchStart}
                className="w-24 h-24 rounded-full bg-black/50 border-2 border-white/20 relative flex items-center justify-center backdrop-blur-md touch-none active:border-cyan-400"
              >
                <div className="absolute w-full h-[1px] bg-white/10" />
                <div className="absolute h-full w-[1px] bg-white/10" />
                <div
                  className="w-10 h-10 rounded-full bg-cyan-500/70 border-2 border-cyan-300 flex items-center justify-center shadow-[0_0_12px_rgba(6,182,212,0.5)] transition-transform duration-75"
                  style={{
                    transform: `translate(${aimPos.x}px, ${aimPos.y}px)`,
                  }}
                >
                  <Crosshair className="w-4 h-4 text-white" />
                </div>
              </div>
            </div>
          )}

          {/* Large Fire Button */}
          <div className="flex flex-col items-center">
            <div className="text-[10px] font-mono text-red-400 mb-1 font-bold tracking-wider">
              {stats.isDriving ? 'RAM & SHOOT' : 'FIRE'}
            </div>
            <button
              onTouchStart={handleFireStart}
              onTouchEnd={handleFireEnd}
              onTouchCancel={handleFireEnd}
              onMouseDown={handleFireStart}
              onMouseUp={handleFireEnd}
              className="w-24 h-24 rounded-full bg-gradient-to-tr from-red-600 to-red-500 hover:from-red-500 hover:to-red-400 active:scale-95 active:shadow-[0_0_35px_rgba(255,0,0,0.9)] text-white border-4 border-red-300 shadow-[0_0_25px_rgba(239,68,68,0.6)] flex flex-col items-center justify-center touch-none select-none transition-transform"
            >
              <Target className="w-8 h-8 text-white animate-pulse" />
              <span className="text-[10px] font-syne font-black tracking-widest uppercase mt-0.5">
                FIRE
              </span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
