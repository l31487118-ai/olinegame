import React from 'react';
import { Play, Trophy, Crosshair, ChevronRight, Shield, Terminal, Car, Map, Compass } from 'lucide-react';
import { PlayerClass } from '../game/types';

interface StartMenuProps {
  highScore: number;
  selectedClass: PlayerClass;
  onSelectClass: (c: PlayerClass) => void;
  onStartGame: () => void;
  startLevel?: number;
  onSelectStartLevel?: (lvl: number) => void;
  onOpenMap?: () => void;
}

export const StartMenu: React.FC<StartMenuProps> = ({
  highScore,
  selectedClass,
  onSelectClass,
  onStartGame,
  startLevel = 1,
  onSelectStartLevel,
  onOpenMap,
}) => {
  const classes: {
    id: PlayerClass;
    name: string;
    title: string;
    desc: string;
    stats: string;
  }[] = [
    {
      id: 'commando',
      name: 'ASSAULT COMMANDO',
      title: 'SWAT Special Forces',
      desc: 'Balanced tactical operative equipped with ballistic plate carrier and tactical combat rifle.',
      stats: 'HP: 100 // SPEED: 10.5 // ARSENAL: RIFLE',
    },
    {
      id: 'ranger',
      name: 'DESERT RANGER',
      title: 'High-Mobility Scout',
      desc: 'Rapid reconnaissance marksman with high sprint velocity and combat shotgun spread.',
      stats: 'HP: 100 // SPEED: 11.5 (+10%) // ARSENAL: SHOTGUN',
    },
    {
      id: 'juggernaut',
      name: 'HEAVY JUGGERNAUT',
      title: 'Demolitions Breacher',
      desc: 'Reinforced explosive blast suit with heavy back shield and high durability RPG payload.',
      stats: 'HP: 130 (+30%) // SPEED: 9.5 // ARSENAL: RPG',
    },
  ];

  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center bg-[#0d0d0f]/90 backdrop-blur-md p-4 overflow-y-auto">
      <div className="w-full max-w-4xl stat-block border border-[var(--border)] p-6 md:p-8 relative overflow-hidden my-auto shadow-2xl">
        {/* Subtle accent glow in top right */}
        <div className="absolute -top-12 -right-12 w-48 h-48 bg-[var(--accent)]/10 rounded-full blur-3xl pointer-events-none" />

        {/* Top Header Badge */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/5 border border-[var(--border)] mb-3">
            <span className="w-2 h-2 rounded-full bg-[var(--accent)] animate-ping" />
            <span className="label text-[11px] text-zinc-300">
              TACTICAL HUD // 8 SECTORS // VEHICULAR COMBAT & ASPHALT ROADS
            </span>
          </div>

          <h1 className="text-4xl md:text-5xl font-extrabold uppercase font-syne tracking-tight text-white">
            ZOMBIE <span className="text-[var(--accent)]">DEFENSE 3D</span>
          </h1>

          <p className="text-xs md:text-sm text-zinc-400 mt-2 max-w-2xl mx-auto font-sans leading-relaxed">
            Eradicate the biological undead outbreak across sunlit farmlands, city avenues, neon skyscrapers, and bio-vaults. <strong className="text-sky-400">Enter and drive tactical vehicles</strong> (Sedans, Police Cruisers, Armored SUVs, Muscle Cars) to run over and splatter swarms of zombies!
          </p>
        </div>

        {/* High Score Telemetry */}
        {highScore > 0 && (
          <div className="flex items-center justify-center gap-3 mb-5 py-2 px-4 bg-white/5 border border-[var(--border)] max-w-xs mx-auto">
            <Trophy className="w-4 h-4 text-amber-400" />
            <span className="label">RECORD SCORE:</span>
            <span className="font-mono tabular-nums text-white font-bold">{highScore.toLocaleString()}</span>
          </div>
        )}

        {/* Operative Class Selection */}
        <div className="mb-6">
          <div className="label mb-2.5 flex items-center gap-1.5">
            <Shield className="w-3.5 h-3.5 text-[var(--accent)]" />
            <span>OPERATIVE SELECTION // DEPLOYMENT PROTOCOL</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {classes.map((c) => {
              const isSelected = selectedClass === c.id;
              return (
                <button
                  key={c.id}
                  onClick={() => onSelectClass(c.id)}
                  className={`p-3.5 border text-left transition-all cursor-pointer ${
                    isSelected
                      ? 'border-[var(--accent)] bg-[var(--accent)]/10 shadow-[0_0_15px_rgba(255,62,62,0.2)]'
                      : 'border-[var(--border)] bg-black/30 hover:border-zinc-500'
                  }`}
                >
                  <div className="label text-[9px] text-[var(--accent)] font-bold">SPEC // 0{c.id === 'commando' ? '1' : c.id === 'ranger' ? '2' : '3'}</div>
                  <div className="font-syne text-xs font-extrabold uppercase text-white mt-1">
                    {c.name}
                  </div>
                  <div className="text-[11px] text-zinc-400 mt-1 line-clamp-2 font-sans">
                    {c.desc}
                  </div>
                  <div className="font-mono text-[10px] text-zinc-300 mt-2.5 pt-2 border-t border-[var(--border)]">
                    {c.stats}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* 8 Area Sector Roadmap */}
        <div className="mb-6">
          <div className="label mb-2 flex items-center justify-between text-zinc-400">
            <div className="flex items-center gap-1.5">
              <Terminal className="w-3.5 h-3.5 text-zinc-400" />
              <span>CAMPAIGN SECTOR DIRECTORY // CHOOSE AREA TO DEPLOY</span>
            </div>
            {onOpenMap && (
              <button
                onClick={onOpenMap}
                className="text-[10px] font-mono text-amber-400 hover:text-amber-300 flex items-center gap-1 cursor-pointer underline"
              >
                <Map className="w-3 h-3" />
                <span>EXPAND TACTICAL AREA MAP (M)</span>
              </button>
            )}
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2 text-left">
            {[
              { num: 1, name: 'Farmland & Road', sub: 'Country road & sedan', border: 'border-emerald-500/40', tagColor: 'text-emerald-400' },
              { num: 2, name: 'Suburbs Avenue', sub: 'Houses & Sprinters', border: 'border-sky-500/40', tagColor: 'text-sky-400' },
              { num: 3, name: 'City Crossroads', sub: 'Skyscrapers & Police Car', border: 'border-blue-500/40', tagColor: 'text-blue-400' },
              { num: 4, name: 'Cyber Megacity', sub: 'Neon towers & Supercar', border: 'border-cyan-500/40', tagColor: 'text-cyan-400' },
              { num: 5, name: 'Financial Plaza', sub: 'High-Rises & Armored SUV', border: 'border-purple-500/40', tagColor: 'text-purple-400' },
              { num: 6, name: 'Neo Harbor City', sub: 'Oceanfront Docks & Highway', border: 'border-teal-500/40', tagColor: 'text-teal-400' },
              { num: 7, name: 'Freight Depot', sub: 'Toxic Mutants & Trucks', border: 'border-amber-500/40', tagColor: 'text-amber-400' },
              { num: 8, name: 'Airfield Runway', sub: 'Tarmac & Heavy Soldiers', border: 'border-slate-500/40', tagColor: 'text-slate-400' },
              { num: 9, name: 'Quarantine Avenues', sub: 'Barricades & Muscle Car', border: 'border-rose-500/40', tagColor: 'text-rose-400' },
              { num: 10, name: 'Omega Vault', sub: 'Colossal Armored Boss', border: 'border-[var(--accent)]', tagColor: 'text-[var(--accent)]' },
            ].map((area) => {
              const isSelected = startLevel === area.num;
              return (
                <button
                  key={area.num}
                  type="button"
                  onClick={() => onSelectStartLevel && onSelectStartLevel(area.num)}
                  className={`p-2.5 text-left border transition-all cursor-pointer relative ${
                    isSelected
                      ? 'border-[var(--accent)] bg-[var(--accent)]/15 shadow-[0_0_15px_rgba(255,62,62,0.3)] ring-1 ring-[var(--accent)]'
                      : `${area.border} bg-black/40 hover:border-zinc-400 hover:bg-white/5`
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className={`label text-[9px] ${area.tagColor}`}>AREA 0{area.num}</span>
                    {isSelected && (
                      <span className="w-1.5 h-1.5 rounded-full bg-[var(--accent)] animate-ping" />
                    )}
                  </div>
                  <div className="font-syne text-[11px] font-bold text-white uppercase mt-0.5 truncate">
                    {area.name}
                  </div>
                  <div className="font-mono text-[9px] text-zinc-400 mt-0.5 truncate">
                    {area.sub}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Telemetry & Controls Summary */}
        <div className="bg-black/40 border border-[var(--border)] p-3.5 mb-6">
          <div className="label mb-2 flex items-center justify-between text-zinc-300">
            <div className="flex items-center gap-1.5">
              <Crosshair className="w-3.5 h-3.5 text-[var(--accent)]" />
              <span>INPUT TELEMETRY // ENGAGEMENT & VEHICLE CONTROLS</span>
            </div>
            <div className="flex items-center gap-1 text-sky-400">
              <Car className="w-3.5 h-3.5" />
              <span className="text-[10px] font-bold">DRIVABLE VEHICLES</span>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div>
              <span className="label text-[9px] block">ON FOOT MOVE</span>
              <span className="font-mono text-white text-[11px]">WASD / ARROW KEYS</span>
            </div>
            <div>
              <span className="label text-[9px] block text-sky-400">ENTER / EXIT VEHICLE</span>
              <span className="font-mono text-sky-400 text-[11px] font-bold">KEY [E] / CLICK HUD</span>
            </div>
            <div>
              <span className="label text-[9px] block text-sky-400">DRIVE & HORN</span>
              <span className="font-mono text-sky-300 text-[11px]">W/S DRIVE // H HORN</span>
            </div>
            <div>
              <span className="label text-[9px] block">FIRE & ARSENAL</span>
              <span className="font-mono text-[var(--accent)] text-[11px]">CLICK // KEYS [1-5]</span>
            </div>
          </div>
        </div>

        {/* Start Game Action Button */}
        <button
          onClick={onStartGame}
          className="w-full py-4 px-6 bg-[var(--accent)] hover:bg-[#e03535] text-white font-syne font-extrabold tracking-wider uppercase text-sm md:text-base transition-all duration-150 shadow-[0_0_20px_rgba(255,62,62,0.4)] flex items-center justify-center gap-2 cursor-pointer transform hover:-translate-y-0.5 active:translate-y-0"
        >
          <Play className="w-5 h-5 fill-white" />
          <span>INITIATE COMBAT DROP // DEPLOY INTO AREA 0{startLevel}</span>
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};
