import React from 'react';
import { ShieldCheck, ChevronRight, MapPin, Zap } from 'lucide-react';
import { LEVELS } from '../game/types';

interface LevelTransitionModalProps {
  currentLevel: number;
  nextLevel: number;
  score: number;
  onContinue: () => void;
}

export const LevelTransitionModal: React.FC<LevelTransitionModalProps> = ({
  currentLevel,
  nextLevel,
  score,
  onContinue,
}) => {
  const currentConfig = LEVELS[currentLevel];
  const nextConfig = LEVELS[nextLevel];

  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center bg-[#0d0d0f]/90 backdrop-blur-md p-4">
      <div className="w-full max-w-lg stat-block border border-[var(--border)] p-6 md:p-8 text-center shadow-2xl relative">
        {/* Sector Clear Badge */}
        <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/5 border border-[var(--border)] mb-3">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span className="label text-emerald-400">SECTOR CLEAR // OUTCOME SECURED</span>
        </div>

        <h2 className="text-3xl font-extrabold text-white font-syne tracking-tight uppercase">
          AREA {currentLevel} LIBERATED
        </h2>
        <p className="text-xs text-zinc-400 mt-1 font-mono">
          SECTOR: {currentConfig?.name?.toUpperCase() || `AREA ${currentLevel}`} // THREAT ELIMINATED
        </p>

        {/* Resupply Field Report */}
        <div className="my-5 p-4 bg-black/40 border border-[var(--border)] text-left">
          <div className="label mb-2 flex items-center gap-1.5 text-zinc-300">
            <Zap className="w-3 h-3 text-[var(--accent)]" />
            <span>FIELD LOGISTICS // RESUPPLY PACKAGE</span>
          </div>

          <div className="flex items-center justify-between text-xs py-1 border-b border-white/5">
            <span className="font-sans text-zinc-400">Vitals Recovery</span>
            <span className="text-emerald-400 font-bold font-mono">+35 HP INJECTED</span>
          </div>
          <div className="flex items-center justify-between text-xs py-1 border-b border-white/5">
            <span className="font-sans text-zinc-400">Munitions Caches</span>
            <span className="text-sky-400 font-bold font-mono">+AMMUNITION STOCKS</span>
          </div>
          <div className="flex items-center justify-between text-xs py-1">
            <span className="font-sans text-zinc-400">Total Combat Score</span>
            <span className="text-white font-bold font-mono tabular-nums">{score.toLocaleString()} PTS</span>
          </div>
        </div>

        {/* Next sector briefing */}
        {nextConfig && (
          <div className="mb-6 p-4 bg-black/30 border border-white/10 text-left">
            <div className="flex items-center gap-2 mb-1">
              <MapPin className="w-3.5 h-3.5 text-[var(--accent)]" />
              <span className="label text-[var(--accent)]">
                UPCOMING AREA {nextLevel} // {nextConfig.name.toUpperCase()}
              </span>
            </div>
            <div className="text-[11px] text-zinc-400 font-mono italic mb-1.5">
              {nextConfig.subtitle}
            </div>
            <p className="text-xs text-zinc-300 font-sans leading-relaxed">
              {nextConfig.description}
            </p>
            <div className="mt-2.5 pt-2 border-t border-white/5 label text-[10px]">
              DIRECTIVE: NEUTRALIZE {nextConfig.targetKills} HOSTILES TO ADVANCE
            </div>
          </div>
        )}

        {/* Action Button */}
        <button
          onClick={onContinue}
          className="w-full py-4 px-6 bg-[var(--accent)] hover:bg-[#e03535] text-white font-syne font-extrabold tracking-wider uppercase text-sm transition-all duration-150 shadow-[0_0_20px_rgba(255,62,62,0.4)] flex items-center justify-center gap-2 cursor-pointer transform hover:-translate-y-0.5 active:translate-y-0"
        >
          <span>PROCEED TO AREA {nextLevel} // ENGAGE</span>
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};
