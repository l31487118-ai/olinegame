import React from 'react';
import { Play, RotateCcw, Volume2, VolumeX, Pause, Map } from 'lucide-react';

interface PauseModalProps {
  onResume: () => void;
  onRestart: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
  onOpenMap?: () => void;
}

export const PauseModal: React.FC<PauseModalProps> = ({
  onResume,
  onRestart,
  isMuted,
  onToggleMute,
  onOpenMap,
}) => {
  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center bg-[#0d0d0f]/90 backdrop-blur-md p-4">
      <div className="w-full max-w-sm stat-block border border-[var(--border)] p-6 shadow-2xl text-center">
        <div className="w-12 h-12 bg-white/5 border border-[var(--border)] flex items-center justify-center mx-auto mb-3 text-zinc-300">
          <Pause className="w-6 h-6 text-[var(--accent)]" />
        </div>

        <div className="label text-[var(--accent)] mb-1">OPERATION SUSPENDED</div>
        <h3 className="text-2xl font-extrabold font-syne uppercase tracking-tight text-white mb-1">
          TACTICAL PAUSE
        </h3>
        <p className="text-xs text-zinc-400 mb-6 font-mono">Press ESC or click Resume to return to combat.</p>

        <div className="flex flex-col gap-2.5">
          <button
            onClick={onResume}
            className="w-full py-3.5 px-4 bg-[var(--accent)] hover:bg-[#e03535] text-white font-syne font-extrabold uppercase tracking-wider text-xs flex items-center justify-center gap-2 cursor-pointer transition-all shadow-[0_0_15px_rgba(255,62,62,0.35)]"
          >
            <Play className="w-4 h-4 fill-white" />
            <span>RESUME MISSION</span>
          </button>

          {onOpenMap && (
            <button
              onClick={onOpenMap}
              className="w-full py-3 px-4 bg-sky-950/30 border border-sky-500/40 hover:border-sky-400 text-sky-200 font-syne font-bold uppercase tracking-wider text-xs flex items-center justify-center gap-2 cursor-pointer transition-all shadow-[0_0_12px_rgba(56,189,248,0.2)]"
            >
              <Map className="w-4 h-4 text-sky-400" />
              <span>TACTICAL AREA MAP // SECTORS (M)</span>
            </button>
          )}

          <button
            onClick={onRestart}
            className="w-full py-3 px-4 bg-black/40 border border-[var(--border)] hover:border-zinc-500 text-zinc-200 font-syne font-bold uppercase tracking-wider text-xs flex items-center justify-center gap-2 cursor-pointer transition-all"
          >
            <RotateCcw className="w-4 h-4" />
            <span>RESTART SECTOR</span>
          </button>

          <button
            onClick={onToggleMute}
            className="w-full py-2.5 px-4 border border-[var(--border)] bg-black/20 hover:bg-white/5 text-zinc-400 hover:text-white label flex items-center justify-center gap-2 cursor-pointer transition-colors"
          >
            {isMuted ? <VolumeX className="w-3.5 h-3.5 text-[var(--accent)]" /> : <Volume2 className="w-3.5 h-3.5 text-emerald-400" />}
            <span>{isMuted ? 'UNMUTE AUDIO' : 'MUTE AUDIO'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
