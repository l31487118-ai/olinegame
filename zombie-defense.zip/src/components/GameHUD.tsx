import React from 'react';
import {
  Volume2,
  VolumeX,
  Pause,
  Play,
  Trophy,
  Camera,
  Activity,
  Crosshair,
  Shield,
  Zap,
  Car,
  Gauge,
  LogOut,
  Bell,
  Map,
  Compass,
  Smartphone,
} from 'lucide-react';
import { HudStats, WeaponType } from '../game/types';
import { GameEngine3D } from '../game/GameEngine3D';
import { Minimap } from './Minimap';

interface GameHUDProps {
  stats: HudStats;
  engine: GameEngine3D | null;
  isPaused: boolean;
  onTogglePause: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
  onToggleCamera: () => void;
  onSelectWeapon: (weapon: WeaponType) => void;
  onOpenMap?: () => void;
  showTouchControls?: boolean;
  onToggleTouchControls?: () => void;
}

export const GameHUD: React.FC<GameHUDProps> = ({
  stats,
  engine,
  isPaused,
  onTogglePause,
  isMuted,
  onToggleMute,
  onToggleCamera,
  onSelectWeapon,
  onOpenMap,
  showTouchControls,
  onToggleTouchControls,
}) => {
  const healthPercent = Math.max(0, Math.min(100, (stats.health / stats.maxHealth) * 100));
  const isLowHealth = stats.health <= 30;
  const progressPercent = Math.min(100, (stats.levelKills / stats.targetKills) * 100);

  const carHealthPercent = stats.carHealth !== undefined && stats.carMaxHealth
    ? Math.max(0, Math.min(100, (stats.carHealth / stats.carMaxHealth) * 100))
    : 100;

  const weaponList: {
    id: WeaponType;
    name: string;
    key: string;
    type: string;
  }[] = [
    { id: 'pistol', name: '9MM PISTOL', key: '1', type: 'SIDEARM' },
    { id: 'shotgun', name: 'TACTICAL SHOTGUN', key: '2', type: 'SPREAD' },
    { id: 'rifle', name: 'ASSAULT RIFLE', key: '3', type: 'RAPID' },
    { id: 'plasma', name: 'PLASMA RAILGUN', key: '4', type: 'ENERGY' },
    { id: 'rpg', name: 'RPG LAUNCHER', key: '5', type: 'EXPLOSIVE' },
  ];

  return (
    <div className="absolute inset-0 pointer-events-none z-10 grid grid-cols-1 md:grid-cols-[300px_1fr_300px] grid-rows-[auto_1fr_auto] h-screen p-3 md:p-6 gap-3 md:gap-6 overflow-hidden">
      {/* TOP BAR: Full width spanning stats block */}
      <header className="col-span-1 md:col-span-full flex flex-col md:flex-row items-stretch md:items-start justify-between gap-3 pointer-events-auto">
        {/* Left: Health & Biometrics Module */}
        <div className="stat-block health-module flex-1 md:max-w-xs">
          <div className="w-full">
            <div className="flex items-center justify-between mb-1.5">
              <div className="flex items-center gap-1.5">
                <Activity
                  className={`w-3.5 h-3.5 ${
                    isLowHealth ? 'text-[var(--accent)] animate-pulse' : 'text-zinc-400'
                  }`}
                />
                <span className="label">STATUS // VITALS</span>
              </div>
              <span
                className={`font-mono text-xs tabular-nums font-bold ${
                  isLowHealth ? 'text-[var(--accent)] animate-pulse' : 'text-zinc-200'
                }`}
              >
                {stats.health} / {stats.maxHealth} HP
              </span>
            </div>

            {/* Health Bar with Tactical Accent Fill */}
            <div className="w-full h-1.5 bg-white/5 relative overflow-hidden">
              <div
                className={`h-full transition-all duration-150 ${
                  isLowHealth
                    ? 'bg-[var(--accent)] shadow-[0_0_15px_var(--accent)] animate-pulse'
                    : 'bg-[var(--accent)] shadow-[0_0_15px_var(--accent)]'
                }`}
                style={{ width: `${healthPercent}%` }}
              />
            </div>

            <div className="flex justify-between items-center mt-1.5 text-[10px] font-mono text-zinc-500">
              <span>{isLowHealth ? 'CRITICAL DAMAGE' : 'OPERATIONAL'}</span>
              <span className="capitalize">{stats.playerClass} SPEC</span>
            </div>
          </div>
        </div>

        {/* Center: Map & Sector Progression Info */}
        <div className="stat-block map-info flex-1 text-center md:max-w-md">
          <div className="flex items-center justify-center gap-2">
            <span className="label">TACTICAL SECTOR // AREA {stats.level} OF 10</span>
            {onOpenMap && (
              <button
                onClick={onOpenMap}
                className="text-[9px] font-mono text-[var(--accent)] hover:underline flex items-center gap-1 cursor-pointer"
                title="Open Tactical Area Map (M)"
              >
                <Compass className="w-2.5 h-2.5" />
                <span>[AREA MAP (M)]</span>
              </button>
            )}
          </div>
          <div className="font-syne text-sm md:text-base font-extrabold uppercase tracking-tight text-white mb-1">
            {stats.levelName}
          </div>

          <div className="flex items-center justify-center gap-3">
            <div className="w-32 md:w-48 h-1.5 bg-white/5 relative overflow-hidden">
              <div
                className="h-full bg-[var(--accent)] shadow-[0_0_10px_var(--accent)] transition-all duration-200"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
            <div className="font-mono text-[11px] text-zinc-300 tabular-nums">
              <span className="text-[var(--accent)] font-bold">{stats.levelKills}</span>
              <span className="text-zinc-500">/{stats.targetKills} KILLS</span>
            </div>
          </div>
        </div>

        {/* Right: Score, Telemetry & Action Controls */}
        <div className="stat-block flex items-center justify-between md:justify-end gap-4 md:max-w-xs">
          {/* Combo Indicator */}
          {stats.combo > 1 && (
            <div className="font-mono text-xs font-bold text-[var(--accent)] border border-[var(--accent)] px-2 py-0.5 shadow-[0_0_10px_rgba(255,62,62,0.3)] animate-pulse">
              x{stats.combo}
            </div>
          )}

          {/* Score Counter */}
          <div className="text-right">
            <div className="label">DEFENSE SCORE</div>
            <div className="font-mono text-sm md:text-base font-bold text-white tabular-nums">
              {stats.score.toLocaleString()}
            </div>
          </div>

          {/* High Score */}
          <div className="hidden sm:block text-right border-l border-[var(--border)] pl-3">
            <div className="label flex items-center gap-1">
              <Trophy className="w-2.5 h-2.5 text-amber-400" />
              <span>HIGH</span>
            </div>
            <div className="font-mono text-xs md:text-sm text-zinc-300 tabular-nums font-bold">
              {stats.highScore.toLocaleString()}
            </div>
          </div>

          {/* Interactive Controls Buttons */}
          <div className="flex items-center gap-1 border-l border-[var(--border)] pl-2">
            {onToggleTouchControls && (
              <button
                onClick={onToggleTouchControls}
                className={`p-1.5 border transition-colors cursor-pointer ${
                  showTouchControls
                    ? 'text-emerald-400 border-emerald-500/50 bg-emerald-950/40'
                    : 'text-zinc-500 border-transparent hover:border-[var(--border)] hover:bg-white/5'
                }`}
                title={`Touch Controls: ${showTouchControls ? 'ACTIVE' : 'OFF'} [Tap to Toggle]`}
              >
                <Smartphone className="w-4 h-4" />
              </button>
            )}
            {onOpenMap && (
              <button
                onClick={onOpenMap}
                className="p-1.5 text-zinc-400 hover:text-white border border-transparent hover:border-[var(--border)] hover:bg-white/5 cursor-pointer transition-colors"
                title="Tactical Area Map (M)"
              >
                <Map className="w-4 h-4 text-amber-400" />
              </button>
            )}
            <button
              onClick={onToggleCamera}
              className="p-1.5 text-zinc-400 hover:text-white border border-transparent hover:border-[var(--border)] hover:bg-white/5 cursor-pointer transition-colors"
              title={`Toggle Camera (C) [Current: ${stats.cameraMode}]`}
            >
              <Camera className="w-4 h-4 text-sky-400" />
            </button>
            <button
              onClick={onToggleMute}
              className="p-1.5 text-zinc-400 hover:text-white border border-transparent hover:border-[var(--border)] hover:bg-white/5 cursor-pointer transition-colors"
              title={isMuted ? 'Unmute Audio' : 'Mute Audio'}
            >
              {isMuted ? (
                <VolumeX className="w-4 h-4 text-[var(--accent)]" />
              ) : (
                <Volume2 className="w-4 h-4 text-emerald-400" />
              )}
            </button>
            <button
              onClick={onTogglePause}
              className="p-1.5 text-zinc-400 hover:text-white border border-transparent hover:border-[var(--border)] hover:bg-white/5 cursor-pointer transition-colors"
              title={isPaused ? 'Resume Mission' : 'Pause Mission (ESC/P)'}
            >
              {isPaused ? (
                <Play className="w-4 h-4 text-amber-400 fill-amber-400" />
              ) : (
                <Pause className="w-4 h-4" />
              )}
            </button>
          </div>
        </div>
      </header>

      {/* CENTER ROW: Tactical Alerts (Boss), Vehicle Telemetry & Side Radar */}
      {/* Column 1: Operator Status Brief (Desktop) */}
      <div className="hidden md:flex flex-col justify-center items-start">
        <div className="stat-block max-w-[220px]">
          <div className="label mb-1">OPERATIVE // SPEC</div>
          <div className="font-syne text-xs font-bold uppercase text-white tracking-wide">
            {stats.playerClass === 'commando' && 'SWAT Commando'}
            {stats.playerClass === 'ranger' && 'Desert Ranger'}
            {stats.playerClass === 'juggernaut' && 'Heavy Juggernaut'}
          </div>
          <div className="font-mono text-[10px] text-zinc-400 mt-1 space-y-0.5">
            <div>CAM: {stats.cameraMode.toUpperCase()}</div>
            <div>STATUS: {stats.isDriving ? 'DRIVING VEHICLE' : 'ON FOOT'}</div>
          </div>
        </div>
      </div>

      {/* Column 2: Center Banner (Boss / Vehicle Cockpit / Enter Vehicle Prompt) */}
      <div className="flex flex-col items-center justify-start gap-3 pointer-events-auto">
        {/* Boss Alert Banner (Area 8) */}
        {stats.bossHp !== undefined && stats.bossMaxHp !== undefined && (
          <div className="w-full max-w-lg stat-block border-2 border-[var(--accent)] shadow-[0_0_25px_rgba(255,62,62,0.35)] animate-bounce-short">
            <div className="flex items-center justify-between mb-1.5">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[var(--accent)] animate-ping" />
                <span className="font-syne text-xs md:text-sm font-extrabold uppercase text-[var(--accent)] tracking-wider">
                  COLOSSAL TANK BOSS ZOMBIE
                </span>
              </div>
              <span className="font-mono text-xs text-white font-bold tabular-nums">
                {stats.bossHp} / {stats.bossMaxHp} HP
              </span>
            </div>

            <div className="w-full h-2 bg-white/5 relative overflow-hidden">
              <div
                className="h-full bg-[var(--accent)] shadow-[0_0_15px_var(--accent)] transition-all duration-150"
                style={{ width: `${Math.max(0, (stats.bossHp / stats.bossMaxHp) * 100)}%` }}
              />
            </div>
          </div>
        )}

        {/* DRIVING VEHICLE HUD TELEMETRY PANEL */}
        {stats.isDriving && (
          <div className="w-full max-w-md stat-block border border-sky-500/50 bg-[#0d0d0f]/95 shadow-[0_0_25px_rgba(56,189,248,0.25)] p-3">
            <div className="flex items-center justify-between border-b border-[var(--border)] pb-2 mb-2">
              <div className="flex items-center gap-2">
                <Car className="w-4 h-4 text-sky-400 animate-pulse" />
                <div>
                  <div className="label text-[9px] text-sky-400">VEHICLE COCKPIT TELEMETRY</div>
                  <div className="font-syne text-xs font-bold text-white uppercase tracking-wide">
                    {stats.carName || 'COMBAT VEHICLE'}
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="label text-[9px]">SPEEDOMETER</div>
                <div className="font-mono text-sm font-extrabold text-sky-300 tabular-nums">
                  {stats.carSpeedMph || 0} <span className="text-[10px] text-zinc-500">MPH</span>
                </div>
              </div>
            </div>

            {/* Vehicle Armor Durability Bar */}
            <div className="mb-2">
              <div className="flex justify-between items-center text-[10px] font-mono mb-1">
                <span className="text-zinc-400">HULL ARMOR INTEGRITY</span>
                <span className="text-sky-300 font-bold tabular-nums">
                  {stats.carHealth} / {stats.carMaxHealth} HP
                </span>
              </div>
              <div className="w-full h-1.5 bg-white/10 relative overflow-hidden">
                <div
                  className="h-full bg-sky-400 shadow-[0_0_10px_rgba(56,189,248,0.6)] transition-all duration-100"
                  style={{ width: `${carHealthPercent}%` }}
                />
              </div>
            </div>

            {/* Vehicle Action Buttons & Guidance */}
            <div className="flex items-center justify-between gap-2 pt-1 border-t border-[var(--border)]">
              <div className="text-[10px] font-mono text-zinc-400">
                <span className="text-sky-400 font-bold">[W/S]</span> ACCEL/REVERSE // <span className="text-sky-400 font-bold">[A/D]</span> STEER
              </div>
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => engine?.toggleCarHorn()}
                  className="px-2 py-1 bg-white/5 hover:bg-white/10 border border-white/10 hover:border-amber-400/50 text-[10px] font-mono text-amber-300 flex items-center gap-1 cursor-pointer transition-all"
                  title="Honk Car Horn [H]"
                >
                  <Bell className="w-3 h-3" />
                  <span>HORN [H]</span>
                </button>
                <button
                  onClick={() => engine?.exitCar()}
                  className="px-2.5 py-1 bg-red-950/40 hover:bg-red-900/60 border border-[var(--accent)] text-[10px] font-mono text-white font-bold flex items-center gap-1 cursor-pointer transition-all shadow-[0_0_10px_rgba(255,62,62,0.3)]"
                  title="Exit Vehicle [E]"
                >
                  <LogOut className="w-3 h-3 text-[var(--accent)]" />
                  <span>EXIT [E]</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ENTER VEHICLE PROMPT (When player is near a parked vehicle on foot) */}
        {!stats.isDriving && stats.nearCarId && (
          <div className="stat-block border-2 border-emerald-400/80 bg-[#0d0d0f]/95 shadow-[0_0_20px_rgba(52,211,153,0.35)] py-2.5 px-4 animate-bounce-short">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded bg-emerald-500/20 border border-emerald-400 flex items-center justify-center text-emerald-400">
                <Car className="w-4 h-4 animate-pulse" />
              </div>
              <div>
                <div className="label text-[9px] text-emerald-400">DRIVABLE VEHICLE IN PROXIMITY</div>
                <div className="font-syne text-xs font-bold text-white uppercase tracking-tight">
                  {stats.nearCarName || 'COMBAT VEHICLE'} AVAILABLE
                </div>
              </div>
              <button
                onClick={() => {
                  if (engine && engine.nearCar) {
                    engine.enterCar(engine.nearCar);
                  }
                }}
                className="ml-2 py-1.5 px-3 bg-emerald-500 hover:bg-emerald-400 text-black font-syne font-extrabold text-[11px] uppercase tracking-wider flex items-center gap-1.5 cursor-pointer transition-all shadow-[0_0_15px_rgba(52,211,153,0.5)]"
              >
                <span>ENTER CAR</span>
                <span className="font-mono bg-black/30 text-white px-1.5 py-0.5 rounded text-[10px]">[E]</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Column 3: Side Radar Panel */}
      <div className="flex flex-col items-end justify-center pointer-events-auto">
        <Minimap engine={engine} hostileCount={engine?.zombies.length} />
      </div>

      {/* BOTTOM ROW: Center Weapon Dock */}
      <footer className="col-span-1 md:col-span-full flex justify-center items-end pb-2 pointer-events-auto">
        <div className="weapon-dock flex-wrap gap-2">
          {weaponList.map((w) => {
            const isActive = stats.activeWeapon === w.id;
            const ammoCount = w.id === 'pistol' ? '∞' : stats.ammo[w.id];
            const isOutOfAmmo = w.id !== 'pistol' && stats.ammo[w.id] <= 0;

            return (
              <div
                key={w.id}
                onClick={() => !isOutOfAmmo && onSelectWeapon(w.id)}
                className={`weapon-card flex flex-col justify-between ${
                  isActive ? 'active' : ''
                } ${isOutOfAmmo ? 'opacity-40 cursor-not-allowed' : ''}`}
                title={`Select ${w.name} [Key: ${w.key}]`}
              >
                <div className="flex items-center justify-between gap-3">
                  <span className="label text-[10px]">[{w.key}] {w.type}</span>
                  <span
                    className={`font-mono text-xs tabular-nums font-bold ${
                      isActive ? 'text-[var(--accent)]' : 'text-zinc-400'
                    }`}
                  >
                    {ammoCount}
                  </span>
                </div>

                <div
                  className={`font-syne text-xs font-bold tracking-tight uppercase mt-1 ${
                    isActive ? 'text-white' : 'text-zinc-300'
                  }`}
                >
                  {w.name}
                </div>
              </div>
            );
          })}
        </div>
      </footer>
    </div>
  );
};
