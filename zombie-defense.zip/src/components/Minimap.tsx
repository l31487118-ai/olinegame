import React, { useEffect, useRef, useState } from 'react';
import { Maximize2, Minimize2, Radio } from 'lucide-react';
import { GameEngine3D } from '../game/GameEngine3D';

interface MinimapProps {
  engine: GameEngine3D | null;
  hostileCount?: number;
}

export const Minimap: React.FC<MinimapProps> = React.memo(({ engine, hostileCount = 0 }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isExpanded, setIsExpanded] = useState<boolean>(false);

  useEffect(() => {
    let animId: number;
    let lastRenderTime = 0;

    const render = (time: number) => {
      animId = requestAnimationFrame(render);
      if (time - lastRenderTime < 33) return; // ~30 FPS for tactical radar saves canvas draw calls
      lastRenderTime = time;

      const canvas = canvasRef.current;
      if (!canvas || !engine) return;

      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const size = canvas.width;
      const center = size / 2;
      const arenaHalf = engine.arenaSize / 2;
      const scale = (size * 0.44) / arenaHalf;

      ctx.clearRect(0, 0, size, size);

      // Radar Circular Background with tactical red glow
      const bgGrad = ctx.createRadialGradient(center, center, 0, center, center, size * 0.48);
      bgGrad.addColorStop(0, 'rgba(255, 62, 62, 0.08)');
      bgGrad.addColorStop(0.7, 'rgba(20, 20, 24, 0.85)');
      bgGrad.addColorStop(1, 'rgba(13, 13, 15, 0.95)');
      ctx.fillStyle = bgGrad;
      ctx.beginPath();
      ctx.arc(center, center, size * 0.47, 0, Math.PI * 2);
      ctx.fill();

      // Outer Radar Ring in var(--accent) (#ff3e3e)
      ctx.strokeStyle = '#ff3e3e';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(center, center, size * 0.47, 0, Math.PI * 2);
      ctx.stroke();

      // Range Rings in subtle accent
      ctx.strokeStyle = 'rgba(255, 62, 62, 0.15)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(center, center, size * 0.32, 0, Math.PI * 2);
      ctx.arc(center, center, size * 0.16, 0, Math.PI * 2);
      ctx.stroke();

      // Tactical Crosshairs
      ctx.strokeStyle = 'rgba(228, 228, 231, 0.15)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(center, size * 0.05);
      ctx.lineTo(center, size * 0.95);
      ctx.moveTo(size * 0.05, center);
      ctx.lineTo(size * 0.95, center);
      ctx.stroke();

      // Arena Boundary Box
      const boxSize = engine.arenaSize * scale;
      ctx.strokeStyle = 'rgba(228, 228, 231, 0.2)';
      ctx.lineWidth = 1;
      ctx.strokeRect(center - boxSize / 2, center - boxSize / 2, boxSize, boxSize);

      // Render 3D Roads on the Radar
      for (const road of engine.roads) {
        const rx = center + road.x * scale;
        const rz = center + road.z * scale;
        const rw = road.width * scale;
        const rl = road.length * scale;

        ctx.save();
        ctx.translate(rx, rz);
        ctx.rotate(road.angle);

        // Asphalt Corridor
        ctx.fillStyle = 'rgba(39, 45, 56, 0.9)';
        ctx.fillRect(-rw / 2, -rl / 2, rw, rl);

        // Yellow Dashed Centerline
        ctx.strokeStyle = '#facc15';
        ctx.lineWidth = 1;
        ctx.setLineDash([3, 3]);
        ctx.beginPath();
        ctx.moveTo(0, -rl / 2);
        ctx.lineTo(0, rl / 2);
        ctx.stroke();
        ctx.setLineDash([]);

        ctx.restore();
      }

      // Radar Sweep Line in accent red
      const now = performance.now();
      const sweepAngle = (now * 0.0022) % (Math.PI * 2);
      const sweepX = center + Math.cos(sweepAngle) * (size * 0.47);
      const sweepY = center + Math.sin(sweepAngle) * (size * 0.47);

      ctx.strokeStyle = 'rgba(255, 62, 62, 0.55)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(center, center);
      ctx.lineTo(sweepX, sweepY);
      ctx.stroke();

      // Sweep Cone Trail
      ctx.fillStyle = 'rgba(255, 62, 62, 0.08)';
      ctx.beginPath();
      ctx.moveTo(center, center);
      ctx.arc(center, center, size * 0.47, sweepAngle - 0.35, sweepAngle);
      ctx.closePath();
      ctx.fill();

      // Render Obstacles, Skyscrapers, Storefronts & Houses (Footprints)
      for (const ob of engine.obstacles) {
        const mx = center + ob.x * scale;
        const my = center + ob.z * scale;
        const ow = Math.max(3, ob.width * scale);
        const od = Math.max(3, ob.depth * scale);

        if (ob.type === 'skyscraper') {
          ctx.fillStyle = 'rgba(37, 99, 235, 0.75)'; // deep city blue
          ctx.fillRect(mx - ow / 2, my - od / 2, ow, od);
          ctx.strokeStyle = '#60a5fa';
          ctx.lineWidth = 0.8;
          ctx.strokeRect(mx - ow / 2, my - od / 2, ow, od);
        } else if (ob.type === 'storefront') {
          ctx.fillStyle = 'rgba(225, 29, 72, 0.75)'; // vibrant retail red
          ctx.fillRect(mx - ow / 2, my - od / 2, ow, od);
          ctx.strokeStyle = '#f43f5e';
          ctx.lineWidth = 0.8;
          ctx.strokeRect(mx - ow / 2, my - od / 2, ow, od);
        } else if (ob.type === 'house' || ob.type === 'barn' || ob.type === 'cabin') {
          ctx.fillStyle = 'rgba(217, 119, 6, 0.7)';
          ctx.fillRect(mx - ow / 2, my - od / 2, ow, od);
          ctx.strokeStyle = '#f59e0b';
          ctx.lineWidth = 0.8;
          ctx.strokeRect(mx - ow / 2, my - od / 2, ow, od);
        } else {
          ctx.fillStyle = 'rgba(113, 113, 122, 0.55)';
          ctx.fillRect(mx - ow / 2, my - od / 2, ow, od);
        }
      }

      // Render Drivable Cars (Gold for parked, Cyan for driving)
      for (const car of engine.cars) {
        if (car.health <= 0) continue;
        const cx = center + car.x * scale;
        const cy = center + car.z * scale;
        const cw = Math.max(3.5, car.width * scale);
        const cl = Math.max(5.5, car.depth * scale);

        ctx.save();
        ctx.translate(cx, cy);
        ctx.rotate(car.angle);

        if (car.isDriven) {
          ctx.fillStyle = '#38bdf8';
          ctx.strokeStyle = '#ffffff';
          ctx.lineWidth = 1.2;
          ctx.fillRect(-cw / 2, -cl / 2, cw, cl);
          ctx.strokeRect(-cw / 2, -cl / 2, cw, cl);

          // Headlight FOV beam
          ctx.fillStyle = 'rgba(254, 240, 138, 0.35)';
          ctx.beginPath();
          ctx.moveTo(-cw / 2, cl / 2);
          ctx.lineTo(-cw * 1.5, cl / 2 + 16);
          ctx.lineTo(cw * 1.5, cl / 2 + 16);
          ctx.lineTo(cw / 2, cl / 2);
          ctx.closePath();
          ctx.fill();
        } else {
          // Parked enterable vehicle (Glowing Amber)
          ctx.fillStyle = '#f59e0b';
          ctx.strokeStyle = '#fef08a';
          ctx.lineWidth = 1;
          ctx.fillRect(-cw / 2, -cl / 2, cw, cl);
          ctx.strokeRect(-cw / 2, -cl / 2, cw, cl);
        }

        ctx.restore();
      }

      // Render Power-Ups (Cyan/Green Glowing Diamonds)
      for (const p of engine.powerUps) {
        const px = center + p.x * scale;
        const py = center + p.z * scale;
        ctx.fillStyle = p.type === 'health' ? '#10b981' : '#38bdf8';
        ctx.beginPath();
        ctx.arc(px, py, 2.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 0.5;
        ctx.stroke();
      }

      // Render Zombies (Bright Red / Toxic Green Blips)
      for (const z of engine.zombies) {
        const zx = center + z.x * scale;
        const zy = center + z.z * scale;

        if (z.type === 'boss') {
          // Boss: Large pulsing skull/red blip
          const pulse = Math.sin(now * 0.01) * 2;
          ctx.fillStyle = '#ff3e3e';
          ctx.beginPath();
          ctx.arc(zx, zy, 5.5 + pulse, 0, Math.PI * 2);
          ctx.fill();
          ctx.strokeStyle = '#ffffff';
          ctx.lineWidth = 1.5;
          ctx.stroke();
        } else if (z.type === 'runner') {
          ctx.fillStyle = '#f87171';
          ctx.beginPath();
          ctx.arc(zx, zy, 2.2, 0, Math.PI * 2);
          ctx.fill();
        } else if (z.type === 'toxic') {
          ctx.fillStyle = '#22c55e';
          ctx.beginPath();
          ctx.arc(zx, zy, 2.5, 0, Math.PI * 2);
          ctx.fill();
        } else {
          ctx.fillStyle = '#ff3e3e';
          ctx.beginPath();
          ctx.arc(zx, zy, 2.0, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      // Render Player (Cyan dot + Direction FOV cone) if not driving (when driving, car is rendered)
      if (!engine.isDriving) {
        const player = engine.playerStats;
        const pX = center + player.x * scale;
        const pY = center + player.z * scale;

        // FOV Cone
        ctx.fillStyle = 'rgba(56, 189, 248, 0.25)';
        ctx.beginPath();
        ctx.moveTo(pX, pY);
        ctx.arc(pX, pY, 18, player.angle - 0.45, player.angle + 0.45);
        ctx.closePath();
        ctx.fill();

        // Player Blip
        ctx.fillStyle = '#38bdf8';
        ctx.beginPath();
        ctx.arc(pX, pY, 3.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 1;
        ctx.stroke();
      }

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, [engine]);

  const pX = Math.round(engine?.playerStats.x || 0);
  const pZ = Math.round(engine?.playerStats.z || 0);
  const zCount = engine?.zombies.length ?? hostileCount;
  const carCount = engine?.cars.filter((c) => c.health > 0).length || 0;

  return (
    <div className="radar-panel pointer-events-auto rounded-none transition-all duration-200">
      {/* Top Header Label */}
      <div className="flex items-center justify-between gap-2 border-b border-[var(--border)] pb-2 mb-2">
        <div className="flex items-center gap-1.5">
          <Radio className="w-3.5 h-3.5 text-[var(--accent)] animate-pulse" />
          <span className="label">TACTICAL RADAR</span>
        </div>
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="text-zinc-500 hover:text-white p-0.5 rounded cursor-pointer transition-colors"
          title={isExpanded ? 'Collapse Radar' : 'Expand Radar'}
        >
          {isExpanded ? <Minimize2 className="w-3 h-3" /> : <Maximize2 className="w-3 h-3" />}
        </button>
      </div>

      {/* Radar Canvas with tactical frame */}
      <div className="relative mx-auto flex items-center justify-center py-1">
        <canvas
          ref={canvasRef}
          width={isExpanded ? 180 : 130}
          height={isExpanded ? 180 : 130}
          className="block rounded-full shadow-[0_0_20px_rgba(255,62,62,0.15)]"
        />
      </div>

      {/* Telemetry info in JetBrains Mono */}
      <div className="grid grid-cols-2 gap-2 text-left pt-2.5 mt-2 border-t border-[var(--border)]">
        <div>
          <div className="label">HOSTILES</div>
          <div className="font-mono text-xs font-bold text-[var(--accent)] tabular-nums">
            {zCount} DETECTED
          </div>
        </div>
        <div>
          <div className="label">VEHICLES</div>
          <div className="font-mono text-xs text-amber-400 tabular-nums font-bold">
            {carCount} IN SECTOR
          </div>
        </div>
      </div>
    </div>
  );
});
