import React from 'react';
import { RotateCcw, Skull, Trophy } from 'lucide-react';

interface GameOverModalProps {
  score: number;
  highScore: number;
  totalKills: number;
  level: number;
  onRestart: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  score,
  highScore,
  totalKills,
  level,
  onRestart,
}) => {
  const isNewHighScore = score > 0 && score >= highScore;

  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center bg-[#0d0d0f]/90 backdrop-blur-md p-4">
      <div className="w-full max-w-md stat-block border-2 border-[var(--accent)] p-6 md:p-8 text-center shadow-[0_0_30px_rgba(255,62,62,0.3)] relative">
        {/* Skull Icon */}
        <div className="w-14 h-14 bg-red-950/40 border border-[var(--accent)] flex items-center justify-center mx-auto mb-3 text-[var(--accent)]">
          <Skull className="w-7 h-7" />
        </div>

        <div className="label text-[var(--accent)] mb-1">CRITICAL SYSTEM FAILURE // CASUALTY REPORT</div>
        <h2 className="text-3xl md:text-4xl font-extrabold text-[var(--accent)] font-syne tracking-tight uppercase">
          MISSION FAILED
        </h2>
        <p className="text-xs text-zinc-400 mt-1 font-mono">
          OPERATIVE NEUTRALIZED IN SECTOR AREA 0{level}.
        </p>

        {/* High score callout */}
        {isNewHighScore && (
          <div className="my-3 py-1.5 px-3 bg-amber-500/10 border border-amber-500/40 flex items-center justify-center gap-2 text-amber-300 text-xs font-bold font-mono">
            <Trophy className="w-3.5 h-3.5 text-amber-400" />
            <span>NEW CAMPAIGN HIGH SCORE RECORD!</span>
          </div>
        )}

        {/* Telemetry Stats Grid */}
        <div className="grid grid-cols-2 gap-2.5 my-5 text-left">
          <div className="bg-black/40 border border-[var(--border)] p-3">
            <div className="label text-[9px]">FINAL SCORE</div>
            <div className="text-lg font-bold font-mono text-white tabular-nums">
              {score.toLocaleString()}
            </div>
          </div>
          <div className="bg-black/40 border border-[var(--border)] p-3">
            <div className="label text-[9px]">RECORD SCORE</div>
            <div className="text-lg font-bold font-mono text-amber-400 tabular-nums">
              {highScore.toLocaleString()}
            </div>
          </div>
          <div className="bg-black/40 border border-[var(--border)] p-3">
            <div className="label text-[9px]">HOSTILES PURGED</div>
            <div className="text-lg font-bold font-mono text-emerald-400 tabular-nums">
              {totalKills}
            </div>
          </div>
          <div className="bg-black/40 border border-[var(--border)] p-3">
            <div className="label text-[9px]">SECTOR REACHED</div>
            <div className="text-lg font-bold font-mono text-zinc-200">
              AREA 0{level}
            </div>
          </div>
        </div>

        {/* Restart Action */}
        <button
          onClick={onRestart}
          className="w-full py-4 px-6 bg-[var(--accent)] hover:bg-[#e03535] text-white font-syne font-extrabold tracking-wider uppercase text-sm transition-all duration-150 shadow-[0_0_20px_rgba(255,62,62,0.4)] flex items-center justify-center gap-2 cursor-pointer transform hover:-translate-y-0.5 active:translate-y-0"
        >
          <RotateCcw className="w-4 h-4" />
          <span>REBOOT SIMULATION // DEPLOY AGAIN</span>
        </button>
      </div>
    </div>
  );
};
