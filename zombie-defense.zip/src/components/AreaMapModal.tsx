import React, { useState } from 'react';
import {
  X,
  MapPin,
  Car,
  ShieldAlert,
  ChevronRight,
  Crosshair,
  Compass,
  Building2,
  Navigation,
  Activity,
  Layers,
  Sparkles,
} from 'lucide-react';
import { LEVELS } from '../game/types';

interface AreaMapModalProps {
  currentLevel: number;
  onSelectLevel: (levelNum: number) => void;
  onClose: () => void;
}

export const AreaMapModal: React.FC<AreaMapModalProps> = ({
  currentLevel,
  onSelectLevel,
  onClose,
}) => {
  const [selectedSector, setSelectedSector] = useState<number>(currentLevel);
  const activeConfig = LEVELS[selectedSector] || LEVELS[1];

  const levelList = Object.values(LEVELS);

  // Sector Theme Badge & Visual Accents
  const getSectorBadge = (num: number) => {
    switch (num) {
      case 1:
        return { label: 'FARMLAND', color: 'text-emerald-400', border: 'border-emerald-500/40', bg: 'bg-emerald-950/20' };
      case 2:
        return { label: 'SUBURBAN', color: 'text-sky-400', border: 'border-sky-500/40', bg: 'bg-sky-950/20' };
      case 3:
        return { label: 'METROPOLIS CITY', color: 'text-blue-400', border: 'border-blue-500/40', bg: 'bg-blue-950/20' };
      case 4:
        return { label: 'CYBER MEGACITY', color: 'text-cyan-400', border: 'border-cyan-500/40', bg: 'bg-cyan-950/20' };
      case 5:
        return { label: 'NEON FINANCIAL', color: 'text-purple-400', border: 'border-purple-500/40', bg: 'bg-purple-950/20' };
      case 6:
        return { label: 'HARBOR COASTAL CITY', color: 'text-teal-400', border: 'border-teal-500/40', bg: 'bg-teal-950/20' };
      case 7:
        return { label: 'INDUSTRIAL', color: 'text-amber-400', border: 'border-amber-500/40', bg: 'bg-amber-950/20' };
      case 8:
        return { label: 'MILITARY AIRBASE', color: 'text-slate-300', border: 'border-slate-500/40', bg: 'bg-slate-900/30' };
      case 9:
        return { label: 'CITY RUINS', color: 'text-rose-400', border: 'border-rose-500/40', bg: 'bg-rose-950/20' };
      case 10:
        return { label: 'BIO-LAB VAULT', color: 'text-[var(--accent)]', border: 'border-[var(--accent)]', bg: 'bg-red-950/30' };
      default:
        return { label: 'ZONE', color: 'text-zinc-400', border: 'border-zinc-700', bg: 'bg-zinc-900/30' };
    }
  };

  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center bg-[#0d0d0f]/95 backdrop-blur-lg p-3 md:p-6 overflow-y-auto animate-fade-in">
      <div className="w-full max-w-6xl stat-block border border-[var(--border)] p-4 md:p-6 relative flex flex-col max-h-[92vh] shadow-2xl overflow-hidden my-auto">
        {/* Subtle accent glow */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-[var(--accent)]/10 rounded-full blur-3xl pointer-events-none" />

        {/* Modal Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[var(--border)] mb-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded bg-[var(--accent)]/15 border border-[var(--accent)]/60 flex items-center justify-center text-[var(--accent)]">
              <Compass className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="label text-[10px] text-[var(--accent)] flex items-center gap-1.5 font-bold">
                <span className="w-2 h-2 rounded-full bg-[var(--accent)] animate-ping" />
                TACTICAL THEATER OVERVIEW // 10 EXPANSIVE SECTORS &amp; MULTIPLE METROPOLIS CITIES
              </div>
              <h2 className="font-syne text-lg md:text-2xl font-black uppercase text-white tracking-wide">
                OPERATIONAL AREA MAP
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="hidden sm:flex items-center gap-2 px-3 py-1 bg-white/5 border border-[var(--border)] text-xs font-mono">
              <span className="text-zinc-400">ACTIVE:</span>
              <span className="text-white font-bold">AREA 0{currentLevel}</span>
            </div>

            <button
              onClick={onClose}
              className="p-2 text-zinc-400 hover:text-white hover:bg-white/10 border border-transparent hover:border-[var(--border)] transition-colors cursor-pointer"
              title="Close Map (ESC / M)"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Main Content: Split Grid (Left: 8 Area Cards, Right: Tactical Blueprint & Deployment) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 flex-1 overflow-y-auto pr-1">
          {/* Left Column: 8 Sector Cards */}
          <div className="lg:col-span-7 flex flex-col gap-2.5 overflow-y-auto">
            <div className="label text-[10px] text-zinc-400 flex items-center justify-between">
              <span>SELECT A SECTOR MAP TO INSPECT OR DEPLOY:</span>
              <span className="font-mono text-zinc-500">8 REGISTERED ZONES</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {levelList.map((lvl) => {
                const isSelected = selectedSector === lvl.number;
                const isCurrent = currentLevel === lvl.number;
                const badge = getSectorBadge(lvl.number);
                const hasCar = (lvl.environment.drivableCarTypes?.length || 0) > 0;
                const roadType = lvl.environment.roadPattern;

                return (
                  <button
                    key={lvl.number}
                    onClick={() => setSelectedSector(lvl.number)}
                    className={`p-3 text-left border transition-all cursor-pointer relative overflow-hidden flex flex-col justify-between ${
                      isSelected
                        ? 'border-[var(--accent)] bg-[var(--accent)]/15 shadow-[0_0_20px_rgba(255,62,62,0.25)]'
                        : isCurrent
                        ? 'border-emerald-500/80 bg-emerald-950/20'
                        : 'border-[var(--border)] bg-[#141416]/80 hover:border-zinc-500 hover:bg-[#18181b]'
                    }`}
                  >
                    {/* Top Row: Area Tag & Active Indicator */}
                    <div className="flex items-center justify-between gap-1 mb-1">
                      <span className={`label text-[9px] font-bold ${badge.color}`}>
                        AREA 0{lvl.number} // {badge.label}
                      </span>
                      {isCurrent && (
                        <span className="px-1.5 py-0.2 bg-emerald-500/20 text-emerald-400 text-[9px] font-mono border border-emerald-500/40">
                          CURRENT
                        </span>
                      )}
                    </div>

                    {/* Sector Title */}
                    <div className="font-syne text-xs md:text-sm font-extrabold uppercase text-white tracking-wide">
                      {lvl.name}
                    </div>

                    {/* Subtitle / Landmarks */}
                    <div className="text-[10px] font-mono text-zinc-400 mt-0.5 line-clamp-1">
                      {lvl.subtitle}
                    </div>

                    {/* Road & Vehicle Badges */}
                    <div className="flex items-center gap-1.5 mt-2.5 pt-2 border-t border-[var(--border)] text-[9px] font-mono">
                      <span className="px-1.5 py-0.5 bg-black/40 border border-white/10 text-zinc-300 flex items-center gap-1">
                        <Navigation className="w-2.5 h-2.5 text-amber-400" />
                        <span>{roadType?.replace('_', ' ').toUpperCase() || 'ROAD'}</span>
                      </span>

                      {hasCar && (
                        <span className="px-1.5 py-0.5 bg-sky-950/40 border border-sky-500/30 text-sky-300 flex items-center gap-1">
                          <Car className="w-2.5 h-2.5 text-sky-400" />
                          <span>DRIVABLE CAR</span>
                        </span>
                      )}

                      <span className="ml-auto font-mono text-zinc-500 text-[10px]">
                        {lvl.targetKills} KILLS
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Right Column: Tactical Schematic, Vehicle Dossier & Deploy Action */}
          <div className="lg:col-span-5 flex flex-col gap-3">
            <div className="stat-block border border-[var(--border)] p-4 flex-1 flex flex-col justify-between bg-black/40">
              <div>
                {/* Sector Header */}
                <div className="flex items-center justify-between border-b border-[var(--border)] pb-2 mb-3">
                  <div>
                    <div className="label text-[10px] text-[var(--accent)] font-bold">
                      TACTICAL DOSSIER // AREA 0{activeConfig.number}
                    </div>
                    <div className="font-syne text-base md:text-lg font-black uppercase text-white tracking-wide">
                      {activeConfig.name}
                    </div>
                    <div className="text-[11px] font-mono text-zinc-400">
                      {activeConfig.subtitle}
                    </div>
                  </div>
                </div>

                {/* Briefing Text */}
                <p className="text-xs text-zinc-300 font-sans leading-relaxed mb-3">
                  {activeConfig.description}
                </p>

                {/* Road Architecture & City Features */}
                <div className="mb-3 p-3 bg-white/5 border border-white/10">
                  <div className="label text-[9px] text-zinc-300 mb-1.5 flex items-center gap-1.5">
                    <Building2 className="w-3.5 h-3.5 text-blue-400" />
                    <span>SURFACE INFRASTRUCTURE & URBAN ARCHITECTURE</span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-[10px] font-mono">
                    <div className="p-1.5 bg-black/30 border border-white/5">
                      <span className="text-zinc-500 block text-[9px]">ROADWAY PATTERN</span>
                      <span className="text-amber-300 font-bold uppercase">
                        {activeConfig.environment.roadPattern.replace('_', ' ')}
                      </span>
                    </div>

                    <div className="p-1.5 bg-black/30 border border-white/5">
                      <span className="text-zinc-500 block text-[9px]">ENVIRONMENT THEME</span>
                      <span className="text-white font-bold uppercase">
                        {activeConfig.environment.theme}
                      </span>
                    </div>
                  </div>

                  <div className="mt-2 text-[10px] font-mono text-zinc-400">
                    <span className="text-zinc-500">OBSTACLES: </span>
                    {activeConfig.environment.obstacleTypeDistribution?.join(', ').toUpperCase()}
                  </div>
                </div>

                {/* Drivable Combat Vehicles in this Area */}
                <div className="mb-3 p-3 bg-sky-950/20 border border-sky-500/30">
                  <div className="label text-[9px] text-sky-400 mb-1.5 flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <Car className="w-3.5 h-3.5 text-sky-400" />
                      <span>DEPLOYED VEHICLES IN SECTOR ({activeConfig.environment.carCount || 0} UNITS)</span>
                    </div>
                    <span className="text-[9px] text-sky-300 font-mono">ENTER WITH [E]</span>
                  </div>

                  <div className="space-y-1.5">
                    {activeConfig.environment.drivableCarTypes?.map((cType, idx) => (
                      <div
                        key={idx}
                        className="flex items-center justify-between p-1.5 bg-black/40 border border-sky-500/20 text-xs font-mono"
                      >
                        <div className="flex items-center gap-2">
                          <span className="w-2 h-2 rounded-full bg-sky-400 animate-pulse" />
                          <span className="text-white font-bold uppercase">
                            {cType === 'police' && 'Tactical Police Cruiser (Strobe Lightbar)'}
                            {cType === 'sedan' && 'Civilian 4-Door Sedan (Swift Transit)'}
                            {cType === 'suv' && 'Heavy Armored SUV (High Hull Armor)'}
                            {cType === 'muscle' && 'V8 Turbo Muscle Car (Extreme Ram Power)'}
                            {cType === 'cyber' && 'Cyber Interceptor Supercar (Underglow & V12 Turbo)'}
                          </span>
                        </div>
                        <span className="text-sky-300 text-[10px]">
                          {cType === 'cyber' ? '34 MPH // 280 HP' : cType === 'police' ? '26 MPH // 260 HP' : cType === 'suv' ? '20 MPH // 320 HP' : cType === 'muscle' ? '30 MPH // 240 HP' : '22 MPH // 220 HP'}
                        </span>
                      </div>
                    ))}
                  </div>

                  <div className="text-[10px] font-mono text-zinc-400 mt-2">
                    Controls: <strong className="text-white">[W/S]</strong> Drive/Reverse // <strong className="text-white">[A/D]</strong> Steer // <strong className="text-white">[H]</strong> Horn Honk // <strong className="text-white">[E]</strong> Exit
                  </div>
                </div>

                {/* Hostiles Breakdown */}
                <div className="p-3 bg-red-950/20 border border-[var(--accent)]/30">
                  <div className="label text-[9px] text-[var(--accent)] mb-1 flex items-center gap-1.5">
                    <ShieldAlert className="w-3.5 h-3.5 text-[var(--accent)]" />
                    <span>THREAT ASSESSMENT & HOSTILE DENSITY</span>
                  </div>

                  <div className="flex items-center gap-2 text-[10px] font-mono text-zinc-300">
                    <span>WALKERS: {Math.round(activeConfig.walkerProb * 100)}%</span>
                    <span>//</span>
                    <span>RUNNERS: {Math.round(activeConfig.runnerProb * 100)}%</span>
                    <span>//</span>
                    <span>TOXIC: {Math.round(activeConfig.toxicProb * 100)}%</span>
                    <span>//</span>
                    <span>ARMORED: {Math.round(activeConfig.armoredProb * 100)}%</span>
                  </div>
                  {activeConfig.bossSpawnsAtKills && (
                    <div className="mt-1 font-mono text-[10px] text-[var(--accent)] font-bold">
                      WARNING: COLOSSAL TANK BOSS SPAWNS AT {activeConfig.bossSpawnsAtKills} KILLS!
                    </div>
                  )}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="mt-4 pt-3 border-t border-[var(--border)] flex flex-col sm:flex-row gap-2">
                <button
                  onClick={() => {
                    onSelectLevel(selectedSector);
                    onClose();
                  }}
                  className="flex-1 py-3 px-4 bg-[var(--accent)] hover:bg-[#e03535] text-white font-syne font-extrabold uppercase text-xs md:text-sm tracking-wider flex items-center justify-center gap-2 cursor-pointer transition-all shadow-[0_0_20px_rgba(255,62,62,0.4)]"
                >
                  <Crosshair className="w-4 h-4" />
                  <span>
                    {selectedSector === currentLevel
                      ? `RESUME AREA 0${selectedSector}`
                      : `DEPLOY INTO AREA 0${selectedSector}`}
                  </span>
                  <ChevronRight className="w-4 h-4" />
                </button>

                <button
                  onClick={onClose}
                  className="py-3 px-4 bg-white/5 hover:bg-white/10 border border-[var(--border)] text-zinc-300 font-mono text-xs uppercase tracking-wider cursor-pointer transition-all"
                >
                  CLOSE MAP [M]
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
