import React from 'react';
import { Trophy, RotateCcw, Sparkles } from 'lucide-react';

interface VictoryModalProps {
  score: number;
  highScore: number;
  totalKills: number;
  healthRemaining: number;
  onPlayAgain: () => void;
}

export const VictoryModal: React.FC<VictoryModalProps> = ({
  score,
  highScore,
  totalKills,
  healthRemaining,
  onPlayAgain,
}) => {
  const isNewRecord = score >= highScore && score > 0;

  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center bg-[#0d0d0f]/90 backdrop-blur-md p-4">
      <div className="w-full max-w-lg stat-block border-2 border-emerald-500/80 p-6 md:p-8 text-center shadow-[0_0_35px_rgba(16,185,129,0.25)] relative">
        {/* Celebration icon */}
        <div className="w-16 h-16 bg-emerald-950/40 border border-emerald-500/80 flex items-center justify-center mx-auto mb-3 text-emerald-400">
          <Trophy className="w-8 h-8 text-amber-400 animate-pulse" />
        </div>

        <div className="label text-emerald-400 mb-1">
          TACTICAL VICTORY // ALL 8 SECTORS SECURED
        </div>

        <h2 className="text-3xl md:text-4xl font-extrabold text-white font-syne tracking-tight uppercase">
          OUTBREAK CONTAINED
        </h2>

        <p className="text-xs text-zinc-400 mt-2 max-w-sm mx-auto font-sans leading-relaxed">
          From the rural green homestead to the bustling downtown metropolis and the subterranean bio-vault, all 8 sectors have been liberated and the Colossal Tank Boss neutralized!
        </p>

        {isNewRecord && (
          <div className="my-3 py-1.5 px-3 bg-amber-500/15 border border-amber-500/50 flex items-center justify-center gap-2 text-amber-300 text-xs font-bold font-mono">
            <Trophy className="w-3.5 h-3.5 text-amber-400" />
            <span>NEW CAMPAIGN ALL-TIME HIGH SCORE RECORD!</span>
          </div>
        )}

        {/* Telemetry Stats Grid */}
        <div className="grid grid-cols-2 gap-2.5 my-5 text-left">
          <div className="bg-black/40 border border-[var(--border)] p-3">
            <div className="label text-[9px]">FINAL SCORE</div>
            <div className="text-lg font-bold font-mono text-amber-400 tabular-nums">
              {score.toLocaleString()}
            </div>
          </div>
          <div className="bg-black/40 border border-[var(--border)] p-3">
            <div className="label text-[9px]">RECORD SCORE</div>
            <div className="text-lg font-bold font-mono text-zinc-200 tabular-nums">
              {highScore.toLocaleString()}
            </div>
          </div>
          <div className="bg-black/40 border border-[var(--border)] p-3">
            <div className="label text-[9px]">PURGED HOSTILES</div>
            <div className="text-lg font-bold font-mono text-emerald-400 tabular-nums">
              {totalKills}
            </div>
          </div>
          <div className="bg-black/40 border border-[var(--border)] p-3">
            <div className="label text-[9px]">VITALS REMAINING</div>
            <div className="text-lg font-bold font-mono text-teal-400 tabular-nums">
              {healthRemaining} HP
            </div>
          </div>
        </div>

        {/* Play Again Button */}
        <button
          onClick={onPlayAgain}
          className="w-full py-4 px-6 bg-[var(--accent)] hover:bg-[#e03535] text-white font-syne font-extrabold tracking-wider uppercase text-sm transition-all duration-150 shadow-[0_0_20px_rgba(255,62,62,0.4)] flex items-center justify-center gap-2 cursor-pointer transform hover:-translate-y-0.5 active:translate-y-0"
        >
          <RotateCcw className="w-4 h-4" />
          <span>INITIALIZE NEW OPERATION // REPLAY</span>
        </button>
      </div>
    </div>
  );
};
