export type GameState =
  | 'START_MENU'
  | 'PLAYING'
  | 'PAUSED'
  | 'LEVEL_TRANSITION'
  | 'GAME_OVER'
  | 'VICTORY';

export type ZombieType = 'walker' | 'runner' | 'toxic' | 'armored' | 'boss';

export type WeaponType = 'pistol' | 'shotgun' | 'rifle' | 'plasma' | 'rpg';

export type PlayerClass = 'commando' | 'ranger' | 'juggernaut';

export type CarType = 'sedan' | 'police' | 'suv' | 'muscle' | 'cyber';

export type ObstacleType =
  | 'house'
  | 'barn'
  | 'cabin'
  | 'car'
  | 'crate'
  | 'container'
  | 'sandbag'
  | 'pod'
  | 'tree'
  | 'streetlight'
  | 'fence'
  | 'skyscraper'
  | 'storefront'
  | 'billboard'
  | 'traffic_light'
  | 'barrier';

export interface AreaEnvironment {
  skyColor: number;
  groundColor: number;
  gridColor: number;
  fogColor: number;
  fogNear: number;
  fogFar: number;
  ambientColor: number;
  ambientIntensity: number;
  sunColor: number;
  sunIntensity: number;
  accentLightColor: number;
  hasClouds: boolean;
  theme: 'farmland' | 'suburbs' | 'city' | 'cyber_megacity' | 'downtown' | 'industrial' | 'military' | 'ruins' | 'biolab';
  roadPattern: 'none' | 'country_road' | 'suburban_street' | 'city_crossroads' | 'highway_grid' | 'megacity_boulevard' | 'airbase_tarmac';
  obstacleTypeDistribution: ObstacleType[];
  drivableCarTypes: CarType[];
  carCount: number;
}

export interface LevelConfig {
  number: number;
  name: string;
  subtitle: string;
  targetKills: number;
  description: string;
  spawnInterval: number; // in ms
  walkerProb: number;
  runnerProb: number;
  toxicProb: number;
  armoredProb: number;
  bossSpawnsAtKills?: number;
  environment: AreaEnvironment;
}

export const LEVELS: Record<number, LevelConfig> = {
  1: {
    number: 1,
    name: 'Green Valley Homestead',
    subtitle: 'Sunlit Farmlands, Country Road & Cottages',
    targetKills: 12,
    description: 'Bright blue skies and country asphalt roads cutting through farmlands. A drivable farm vehicle is parked nearby. Clear 12 to advance.',
    spawnInterval: 1200,
    walkerProb: 1.0,
    runnerProb: 0.0,
    toxicProb: 0.0,
    armoredProb: 0.0,
    environment: {
      skyColor: 0x38bdf8,
      groundColor: 0x2f855a,
      gridColor: 0x38a169,
      fogColor: 0x7dd3fc,
      fogNear: 45,
      fogFar: 110,
      ambientColor: 0xffffff,
      ambientIntensity: 0.85,
      sunColor: 0xfffaed,
      sunIntensity: 1.1,
      accentLightColor: 0xfef08a,
      hasClouds: true,
      theme: 'farmland',
      roadPattern: 'country_road',
      obstacleTypeDistribution: ['house', 'barn', 'tree', 'fence', 'crate'],
      drivableCarTypes: ['sedan'],
      carCount: 2,
    },
  },
  2: {
    number: 2,
    name: 'Sunny Suburbs Avenue',
    subtitle: 'Residential Boulevard & Driveways',
    targetKills: 18,
    description: 'Paved suburban street flanked by houses and streetlights. Fast runner sprinters are closing in. Get in the car and run them over!',
    spawnInterval: 950,
    walkerProb: 0.65,
    runnerProb: 0.35,
    toxicProb: 0.0,
    armoredProb: 0.0,
    environment: {
      skyColor: 0x60a5fa,
      groundColor: 0x3b7a57,
      gridColor: 0x489467,
      fogColor: 0x93c5fd,
      fogNear: 40,
      fogFar: 105,
      ambientColor: 0xf8fafc,
      ambientIntensity: 0.8,
      sunColor: 0xfff7ed,
      sunIntensity: 1.0,
      accentLightColor: 0x38bdf8,
      hasClouds: true,
      theme: 'suburbs',
      roadPattern: 'suburban_street',
      obstacleTypeDistribution: ['house', 'car', 'tree', 'streetlight', 'crate', 'fence'],
      drivableCarTypes: ['sedan', 'suv'],
      carCount: 3,
    },
  },
  3: {
    number: 3,
    name: 'Downtown Metropolis City',
    subtitle: 'City Skyscraper District & 4-Way Crossroad',
    targetKills: 22,
    description: 'Towering multi-story skyscrapers, storefronts, pedestrian crosswalks, traffic signals, and a high-speed Tactical Police Interceptor cruiser.',
    spawnInterval: 800,
    walkerProb: 0.45,
    runnerProb: 0.55,
    toxicProb: 0.0,
    armoredProb: 0.0,
    environment: {
      skyColor: 0x1d4ed8,
      groundColor: 0x18181b,
      gridColor: 0x3f3f46,
      fogColor: 0x1e3a8a,
      fogNear: 32,
      fogFar: 95,
      ambientColor: 0x60a5fa,
      ambientIntensity: 0.75,
      sunColor: 0xbfdbfe,
      sunIntensity: 0.9,
      accentLightColor: 0x38bdf8,
      hasClouds: false,
      theme: 'city',
      roadPattern: 'city_crossroads',
      obstacleTypeDistribution: ['skyscraper', 'storefront', 'traffic_light', 'streetlight', 'barrier', 'crate'],
      drivableCarTypes: ['police', 'sedan'],
      carCount: 3,
    },
  },
  4: {
    number: 4,
    name: 'Cyber Megacity Boulevard',
    subtitle: 'Holographic Skyline, Neon Overpass & Cyber Interceptor',
    targetKills: 25,
    description: 'Futuristic metropolis with towering glass megaliths, neon-cyan digital billboards, elevated expressways, and a high-performance Cyber Interceptor Supercar!',
    spawnInterval: 750,
    walkerProb: 0.35,
    runnerProb: 0.45,
    toxicProb: 0.2,
    armoredProb: 0.0,
    environment: {
      skyColor: 0x09090b,
      groundColor: 0x0f172a,
      gridColor: 0x06b6d4,
      fogColor: 0x020617,
      fogNear: 28,
      fogFar: 92,
      ambientColor: 0x38bdf8,
      ambientIntensity: 0.8,
      sunColor: 0x38bdf8,
      sunIntensity: 0.85,
      accentLightColor: 0xf43f5e,
      hasClouds: false,
      theme: 'cyber_megacity',
      roadPattern: 'megacity_boulevard',
      obstacleTypeDistribution: ['skyscraper', 'billboard', 'storefront', 'traffic_light', 'barrier', 'streetlight'],
      drivableCarTypes: ['cyber', 'police'],
      carCount: 3,
    },
  },
  5: {
    number: 5,
    name: 'Neon Financial Plaza',
    subtitle: 'Towering Glass High-Rises & Multi-Lane Expressway',
    targetKills: 28,
    description: 'Vibrant neon city center with corporate skyscrapers, glowing neon advertising billboards, wide asphalt boulevards, and heavy armored SUVs.',
    spawnInterval: 720,
    walkerProb: 0.35,
    runnerProb: 0.4,
    toxicProb: 0.25,
    armoredProb: 0.0,
    environment: {
      skyColor: 0x311042, // Neon twilight purple
      groundColor: 0x13131a,
      gridColor: 0xa855f7,
      fogColor: 0x2e1065,
      fogNear: 30,
      fogFar: 90,
      ambientColor: 0xc084fc,
      ambientIntensity: 0.7,
      sunColor: 0xe879f9,
      sunIntensity: 0.85,
      accentLightColor: 0x06b6d4,
      hasClouds: false,
      theme: 'downtown',
      roadPattern: 'highway_grid',
      obstacleTypeDistribution: ['skyscraper', 'billboard', 'storefront', 'traffic_light', 'barrier', 'streetlight'],
      drivableCarTypes: ['suv', 'muscle'],
      carCount: 3,
    },
  },
  6: {
    number: 6,
    name: 'Neo Harbor Coastal City',
    subtitle: 'Waterfront Boulevard, Shipping Docks & Ocean Highway',
    targetKills: 30,
    description: 'Vast coastal city with oceanfront skyscrapers, illuminated harbor shipping piers, wide asphalt coastal expressways, and high-performance Cyber Interceptor & Muscle Cars!',
    spawnInterval: 670,
    walkerProb: 0.3,
    runnerProb: 0.4,
    toxicProb: 0.2,
    armoredProb: 0.1,
    environment: {
      skyColor: 0x0c4a6e,
      groundColor: 0x0f172a,
      gridColor: 0x0284c7,
      fogColor: 0x082f49,
      fogNear: 26,
      fogFar: 88,
      ambientColor: 0x38bdf8,
      ambientIntensity: 0.75,
      sunColor: 0x7dd3fc,
      sunIntensity: 0.85,
      accentLightColor: 0x06b6d4,
      hasClouds: true,
      theme: 'city',
      roadPattern: 'highway_grid',
      obstacleTypeDistribution: ['skyscraper', 'container', 'billboard', 'storefront', 'traffic_light', 'barrier'],
      drivableCarTypes: ['cyber', 'muscle'],
      carCount: 3,
    },
  },
  7: {
    number: 7,
    name: 'Industrial Scrap Yard',
    subtitle: 'Freight Cargo Depot & Highway Overpass',
    targetKills: 32,
    description: 'Multi-colored shipping container stacks, chemical waste tanks, service roads, and venomous acid-spitting mutants.',
    spawnInterval: 650,
    walkerProb: 0.3,
    runnerProb: 0.35,
    toxicProb: 0.35,
    armoredProb: 0.0,
    environment: {
      skyColor: 0x7c2d12,
      groundColor: 0x27272a,
      gridColor: 0x3f3f46,
      fogColor: 0x451a03,
      fogNear: 22,
      fogFar: 80,
      ambientColor: 0xfb923c,
      ambientIntensity: 0.65,
      sunColor: 0xfed7aa,
      sunIntensity: 0.75,
      accentLightColor: 0x22c55e,
      hasClouds: false,
      theme: 'industrial',
      roadPattern: 'country_road',
      obstacleTypeDistribution: ['container', 'cabin', 'crate', 'sandbag', 'streetlight', 'barrier'],
      drivableCarTypes: ['suv'],
      carCount: 2,
    },
  },
  8: {
    number: 8,
    name: 'Military Airbase Fortress',
    subtitle: 'Tarmac Runway, Perimeter Road & Fortified Bunkers',
    targetKills: 35,
    description: 'Wide concrete airfield tarmac with tactical barriers, sandbag nests, and heavily armored soldier zombies with ballistic vests.',
    spawnInterval: 580,
    walkerProb: 0.25,
    runnerProb: 0.3,
    toxicProb: 0.2,
    armoredProb: 0.25,
    environment: {
      skyColor: 0x0f172a,
      groundColor: 0x181a17,
      gridColor: 0x27272a,
      fogColor: 0x090d16,
      fogNear: 24,
      fogFar: 85,
      ambientColor: 0x38bdf8,
      ambientIntensity: 0.6,
      sunColor: 0xa5f3fc,
      sunIntensity: 0.75,
      accentLightColor: 0xef4444,
      hasClouds: false,
      theme: 'military',
      roadPattern: 'airbase_tarmac',
      obstacleTypeDistribution: ['cabin', 'sandbag', 'container', 'barrier', 'crate', 'streetlight'],
      drivableCarTypes: ['suv', 'police'],
      carCount: 3,
    },
  },
  9: {
    number: 9,
    name: 'Metro Quarantine Ruins',
    subtitle: 'Wrecked City Crossroads & Abandoned High-Rises',
    targetKills: 38,
    description: 'Shattered skyscrapers, burning street lamps, barricaded city avenues, and a high-power V8 muscle car ready to plow through swarms.',
    spawnInterval: 520,
    walkerProb: 0.2,
    runnerProb: 0.35,
    toxicProb: 0.25,
    armoredProb: 0.2,
    environment: {
      skyColor: 0x1e1b4b,
      groundColor: 0x111827,
      gridColor: 0x475569,
      fogColor: 0x0f172a,
      fogNear: 22,
      fogFar: 80,
      ambientColor: 0x818cf8,
      ambientIntensity: 0.65,
      sunColor: 0xc7d2fe,
      sunIntensity: 0.75,
      accentLightColor: 0xf43f5e,
      hasClouds: false,
      theme: 'ruins',
      roadPattern: 'city_crossroads',
      obstacleTypeDistribution: ['skyscraper', 'storefront', 'traffic_light', 'barrier', 'container', 'crate'],
      drivableCarTypes: ['muscle', 'police'],
      carCount: 3,
    },
  },
  10: {
    number: 10,
    name: 'Bio-Lab Omega Vault',
    subtitle: 'Subterranean Containment & Colossal Boss Chamber',
    targetKills: 42,
    description: 'Underground bio-containment facility with bio-pods, containment roads, and the terrifying Colossal Armored Tank Boss!',
    spawnInterval: 460,
    walkerProb: 0.2,
    runnerProb: 0.35,
    toxicProb: 0.25,
    armoredProb: 0.2,
    bossSpawnsAtKills: 15,
    environment: {
      skyColor: 0x052e16,
      groundColor: 0x0a0f0d,
      gridColor: 0x14532d,
      fogColor: 0x022c22,
      fogNear: 18,
      fogFar: 75,
      ambientColor: 0x22c55e,
      ambientIntensity: 0.65,
      sunColor: 0x4ade80,
      sunIntensity: 0.7,
      accentLightColor: 0x10b981,
      hasClouds: false,
      theme: 'biolab',
      roadPattern: 'none',
      obstacleTypeDistribution: ['pod', 'container', 'sandbag', 'crate'],
      drivableCarTypes: ['suv', 'cyber'],
      carCount: 2,
    },
  },
};

export interface CarEntity {
  id: number;
  type: CarType;
  name: string;
  x: number;
  z: number;
  angle: number;
  speed: number;
  maxSpeed: number;
  reverseSpeed: number;
  turnSpeed: number;
  acceleration: number;
  health: number;
  maxHealth: number;
  color: number;
  width: number;
  depth: number;
  height: number;
  radius: number;
  isDriven: boolean;
  hornTimer?: number;
  lastHitTime?: number;
}

export interface RoadSegment {
  x: number;
  z: number;
  width: number;
  length: number;
  angle: number; // 0: along Z-axis, Math.PI/2: along X-axis
  isCrosswalk?: boolean;
}

export interface PlayerStats {
  x: number;
  z: number;
  radius: number;
  speed: number;
  angle: number;
  health: number;
  maxHealth: number;
  lastHurtTime: number;
  isInvulnerable: boolean;
  score: number;
  killsInLevel: number;
  totalKills: number;
  shotsFired: number;
  shotsHit: number;
  playerClass: PlayerClass;
  activeWeapon: WeaponType;
  unlockedWeapons: Record<WeaponType, boolean>;
  ammo: Record<WeaponType, number>; // infinite for pistol, count for others
  lastFireTime: number;
  // Vehicle interaction state
  isDriving: boolean;
  currentCarId: number | null;
}

export interface Bullet3D {
  id: number;
  x: number;
  y: number;
  z: number;
  vx: number;
  vz: number;
  damage: number;
  radius: number;
  color: number;
  life: number;
  weaponType: WeaponType;
  pierceCount?: number;
  isRocket?: boolean;
}

export interface ZombieEntity {
  id: number;
  type: ZombieType;
  x: number;
  z: number;
  vx: number;
  vz: number;
  speed: number;
  baseSpeed: number;
  radius: number;
  health: number;
  maxHealth: number;
  damage: number;
  scoreValue: number;
  angle: number;
  walkCycle: number;
  lastAttackTime: number;
  isHitFlash: number;
  // Tank boss specific
  chargeCooldown?: number;
  isCharging?: boolean;
  chargeTime?: number;
}

export interface Obstacle3D {
  id: number;
  x: number;
  z: number;
  width: number;
  depth: number;
  height: number;
  radius: number; // for circular collision check
  type: ObstacleType;
}

export interface PowerUp3D {
  id: number;
  x: number;
  z: number;
  type: 'health' | 'shotgun_ammo' | 'rifle_ammo' | 'plasma_ammo' | 'rpg_ammo' | 'nuke';
  createdAt: number;
  duration: number;
}

export interface MinimapEntity {
  x: number;
  z: number;
  type: 'player' | 'zombie' | 'boss' | 'obstacle' | 'powerup' | 'car';
  angle?: number;
  radius?: number;
  color?: string;
  width?: number;
  depth?: number;
}

export interface HudStats {
  health: number;
  maxHealth: number;
  score: number;
  highScore: number;
  level: number;
  levelName: string;
  levelSubtitle: string;
  levelKills: number;
  targetKills: number;
  activeWeapon: WeaponType;
  ammo: Record<WeaponType, number>;
  unlockedWeapons: Record<WeaponType, boolean>;
  playerClass: PlayerClass;
  bossHp?: number;
  bossMaxHp?: number;
  combo: number;
  cameraMode: 'isometric' | 'action';
  // Vehicle telemetry
  isDriving: boolean;
  carHealth?: number;
  carMaxHealth?: number;
  carSpeedMph?: number;
  carName?: string;
  nearCarId?: number | null;
  nearCarName?: string;
}
