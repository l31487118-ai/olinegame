import * as THREE from 'three';
import { sounds } from './audio';
import { ModelFactory } from './ModelFactory';
import {
  Bullet3D,
  CarEntity,
  CarType,
  GameState,
  HudStats,
  LEVELS,
  Obstacle3D,
  PlayerClass,
  PlayerStats,
  PowerUp3D,
  RoadSegment,
  WeaponType,
  ZombieEntity,
  ZombieType,
} from './types';

export class GameEngine3D {
  public container: HTMLElement;
  public scene: THREE.Scene;
  public camera: THREE.PerspectiveCamera;
  public renderer: THREE.WebGLRenderer;

  public state: GameState = 'START_MENU';
  public currentLevel = 1;
  public highScore = 0;
  public cameraMode: 'isometric' | 'action' = 'isometric';
  public selectedClass: PlayerClass = 'commando';

  // Arena bounds (in 3D units, X and Z)
  public arenaSize = 85;

  // 3D Objects
  public groundMesh!: THREE.Mesh;
  public gridHelper!: THREE.GridHelper;
  public playerMesh!: THREE.Group;
  public playerStats!: PlayerStats;
  public clouds: { mesh: THREE.Group; speed: number }[] = [];

  // Roads & Drivable Vehicles
  public roads: RoadSegment[] = [];
  public roadMeshes: THREE.Group[] = [];
  public cars: CarEntity[] = [];
  public carMeshes = new Map<number, THREE.Group>();
  public isDriving = false;
  public currentCar: CarEntity | null = null;
  public nearCar: CarEntity | null = null;
  public nextCarId = 1;

  // Lights
  public ambientLight!: THREE.AmbientLight;
  public dirLight!: THREE.DirectionalLight;
  public accentLight!: THREE.PointLight;

  // Entities & Collections
  public zombies: ZombieEntity[] = [];
  public zombieMeshes = new Map<number, THREE.Group>();

  public bullets: Bullet3D[] = [];
  public bulletMeshes = new Map<number, THREE.Mesh>();

  public obstacles: Obstacle3D[] = [];
  public obstacleMeshes = new Map<number, THREE.Group>();

  public powerUps: PowerUp3D[] = [];
  public powerUpMeshes = new Map<number, THREE.Group>();

  public bloodStains: { x: number; z: number; mesh: THREE.Mesh }[] = [];

  // 3D Particles
  public particles: {
    mesh: THREE.Mesh;
    vx: number;
    vy: number;
    vz: number;
    life: number;
    maxLife: number;
  }[] = [];

  // Boss tracking
  public bossZombie: ZombieEntity | null = null;
  public bossSpawned = false;

  // Spawning & progression
  public levelKills = 0;
  public lastSpawnTime = 0;
  public nextZombieId = 1;
  public nextBulletId = 1;
  public nextPowerUpId = 1;

  // Input
  public keys: Record<string, boolean> = {};
  public mouseScreen = new THREE.Vector2(0, 0);
  public mouseWorld = new THREE.Vector3(0, 0, 0);
  public isMouseDown = false;
  private raycaster = new THREE.Raycaster();
  private groundPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);

  // Mobile Touch Controls
  public virtualMove = { x: 0, y: 0 };
  public virtualAimAngle: number | null = null;
  public isMobileTouchActive = false;

  // Performance & Memory Leak Prevention: Shared Static Geometries & Cached Materials
  private static bulletSphereGeo = new THREE.SphereGeometry(0.12, 6, 6);
  private static rocketConeGeo = (() => {
    const g = new THREE.ConeGeometry(0.18, 0.55, 6);
    g.rotateX(Math.PI / 2);
    return g;
  })();
  private static plasmaCylinderGeo = (() => {
    const g = new THREE.CylinderGeometry(0.08, 0.08, 0.8, 6);
    g.rotateX(Math.PI / 2);
    return g;
  })();
  private static particleGeo = new THREE.SphereGeometry(0.12, 4, 4);
  private static sparkGeo = new THREE.SphereGeometry(0.06, 4, 4);
  private static bloodPlaneGeo = (() => {
    const g = new THREE.PlaneGeometry(1, 1);
    g.rotateX(-Math.PI / 2);
    return g;
  })();

  private static materialCache = new Map<string, THREE.MeshBasicMaterial>();

  public static getSharedMaterial(colorHex: number, opacity = 1.0): THREE.MeshBasicMaterial {
    const key = `${colorHex}_${opacity}`;
    let mat = GameEngine3D.materialCache.get(key);
    if (!mat) {
      mat = new THREE.MeshBasicMaterial({
        color: colorHex,
        transparent: opacity < 1.0,
        opacity,
        depthWrite: opacity >= 1.0,
      });
      GameEngine3D.materialCache.set(key, mat);
    }
    return mat;
  }

  public static disposeHierarchy(obj: THREE.Object3D) {
    obj.traverse((child) => {
      if ((child as THREE.Mesh).isMesh) {
        const m = child as THREE.Mesh;
        if (
          m.geometry &&
          m.geometry !== GameEngine3D.bulletSphereGeo &&
          m.geometry !== GameEngine3D.rocketConeGeo &&
          m.geometry !== GameEngine3D.plasmaCylinderGeo &&
          m.geometry !== GameEngine3D.particleGeo &&
          m.geometry !== GameEngine3D.sparkGeo &&
          m.geometry !== GameEngine3D.bloodPlaneGeo
        ) {
          m.geometry.dispose();
        }
        if (m.material) {
          const mats = Array.isArray(m.material) ? m.material : [m.material];
          mats.forEach((mat) => {
            if (![...GameEngine3D.materialCache.values()].includes(mat as THREE.MeshBasicMaterial)) {
              mat.dispose();
            }
          });
        }
      }
    });
  }

  // Camera tracking smoothing
  private cameraLookTarget = new THREE.Vector3();

  // HUD sync throttling to avoid React 60fps render churn
  private lastHudSyncTime = 0;

  // Juice & Feedback
  public screenShake = 0;
  public comboCount = 0;
  public lastKillTime = 0;

  // Callbacks
  public onStateChange?: (state: GameState) => void;
  public onHudUpdate?: (stats: HudStats) => void;
  public onToggleMap?: () => void;

  private animationFrameId: number | null = null;
  private lastTime = 0;

  constructor(container: HTMLElement) {
    this.container = container;

    // Load High score
    try {
      const saved = localStorage.getItem('zombie_defense_highscore');
      if (saved) this.highScore = parseInt(saved, 10) || 0;
    } catch {
      this.highScore = 0;
    }

    // Init Three.js Scene
    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(
      45,
      container.clientWidth / container.clientHeight,
      0.1,
      250
    );

    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.container.appendChild(this.renderer.domElement);

    this.initPlayer();
    this.initSceneLightingAndGround();
    this.setupListeners();
    this.buildArea(1);
  }

  public setPlayerClass(playerClass: PlayerClass) {
    this.selectedClass = playerClass;
    if (this.playerStats) {
      this.playerStats.playerClass = playerClass;
      if (playerClass === 'juggernaut') {
        this.playerStats.maxHealth = 130;
        this.playerStats.health = 130;
        this.playerStats.speed = 9.5;
      } else if (playerClass === 'ranger') {
        this.playerStats.maxHealth = 100;
        this.playerStats.health = 100;
        this.playerStats.speed = 11.5;
      } else {
        this.playerStats.maxHealth = 100;
        this.playerStats.health = 100;
        this.playerStats.speed = 10.5;
      }
      this.refreshPlayerMesh();
      this.syncHud();
    }
  }

  private initPlayer() {
    this.playerStats = {
      x: 0,
      z: 0,
      radius: 0.7,
      speed: 10.5,
      angle: 0,
      health: 100,
      maxHealth: 100,
      lastHurtTime: 0,
      isInvulnerable: false,
      score: 0,
      killsInLevel: 0,
      totalKills: 0,
      shotsFired: 0,
      shotsHit: 0,
      playerClass: this.selectedClass,
      activeWeapon: 'pistol',
      unlockedWeapons: {
        pistol: true,
        shotgun: true,
        rifle: true,
        plasma: true,
        rpg: true,
      },
      ammo: {
        pistol: 99999, // infinite
        shotgun: 35,
        rifle: 140,
        plasma: 25,
        rpg: 8,
      },
      lastFireTime: 0,
      isDriving: false,
      currentCarId: null,
    };

    this.playerMesh = ModelFactory.createPlayerModel(this.selectedClass, 'pistol');
    this.playerMesh.position.set(0, 0, 0);
    this.scene.add(this.playerMesh);
  }

  public refreshPlayerMesh() {
    if (this.playerMesh) {
      this.scene.remove(this.playerMesh);
    }
    this.playerMesh = ModelFactory.createPlayerModel(this.playerStats.playerClass, this.playerStats.activeWeapon);
    this.playerMesh.position.set(this.playerStats.x, 0, this.playerStats.z);
    this.playerMesh.rotation.y = this.playerStats.angle;
    this.scene.add(this.playerMesh);
  }

  private initSceneLightingAndGround() {
    // Ground
    const groundGeo = new THREE.PlaneGeometry(this.arenaSize * 1.6, this.arenaSize * 1.6);
    groundGeo.rotateX(-Math.PI / 2);
    const groundMat = new THREE.MeshStandardMaterial({
      color: 0x2f855a, // lush green grass
      roughness: 0.85,
      metalness: 0.08,
    });
    this.groundMesh = new THREE.Mesh(groundGeo, groundMat);
    this.groundMesh.receiveShadow = true;
    this.scene.add(this.groundMesh);

    // Subtle grid helper
    this.gridHelper = new THREE.GridHelper(this.arenaSize, 50, 0x38a169, 0x276749);
    this.gridHelper.position.y = 0.02;
    this.scene.add(this.gridHelper);

    // Ambient light
    this.ambientLight = new THREE.AmbientLight(0xffffff, 0.85);
    this.scene.add(this.ambientLight);

    // Directional Sun with real shadows
    this.dirLight = new THREE.DirectionalLight(0xfffaed, 1.1);
    this.dirLight.position.set(35, 55, 30);
    this.dirLight.castShadow = true;
    this.dirLight.shadow.mapSize.width = 2048;
    this.dirLight.shadow.mapSize.height = 2048;
    this.dirLight.shadow.camera.near = 10;
    this.dirLight.shadow.camera.far = 140;
    const d = 45;
    this.dirLight.shadow.camera.left = -d;
    this.dirLight.shadow.camera.right = d;
    this.dirLight.shadow.camera.top = d;
    this.dirLight.shadow.camera.bottom = -d;
    this.scene.add(this.dirLight);

    // Accent Point Light
    this.accentLight = new THREE.PointLight(0xfef08a, 1.5, 60);
    this.accentLight.position.set(0, 18, 0);
    this.scene.add(this.accentLight);

    // Initial camera position
    this.camera.position.set(0, 28, 22);
    this.camera.lookAt(0, 0, 0);
  }

  public setCameraMode(mode: 'isometric' | 'action') {
    this.cameraMode = mode;
    this.syncHud();
  }

  public toggleCameraMode() {
    this.setCameraMode(this.cameraMode === 'isometric' ? 'action' : 'isometric');
  }

  public selectWeapon(weapon: WeaponType) {
    if (this.playerStats.activeWeapon === weapon) return;
    this.playerStats.activeWeapon = weapon;
    sounds.playWeaponSwitch();
    this.refreshPlayerMesh();
    this.syncHud();
  }

  public buildArea(levelNum: number) {
    const config = LEVELS[levelNum] || LEVELS[1];

    // Sky & Atmosphere
    this.scene.background = new THREE.Color(config.environment.skyColor);
    this.scene.fog = new THREE.Fog(
      config.environment.fogColor,
      config.environment.fogNear,
      config.environment.fogFar
    );

    // Ground & Grid
    (this.groundMesh.material as THREE.MeshStandardMaterial).color.setHex(config.environment.groundColor);
    this.scene.remove(this.gridHelper);
    this.gridHelper = new THREE.GridHelper(this.arenaSize, 50, config.environment.gridColor, config.environment.gridColor);
    this.gridHelper.position.y = 0.02;
    this.scene.add(this.gridHelper);

    // Lights
    this.ambientLight.color.setHex(config.environment.ambientColor);
    this.ambientLight.intensity = config.environment.ambientIntensity;
    this.dirLight.color.setHex(config.environment.sunColor);
    this.dirLight.intensity = config.environment.sunIntensity;
    this.accentLight.color.setHex(config.environment.accentLightColor);

    // Remove existing clouds
    this.clouds.forEach((c) => {
      this.scene.remove(c.mesh);
      GameEngine3D.disposeHierarchy(c.mesh);
    });
    this.clouds = [];

    // Procedural Floating Clouds for blue sky areas
    if (config.environment.hasClouds) {
      for (let i = 0; i < 20; i++) {
        const cloudMesh = ModelFactory.createCloudModel();
        const cx = (Math.random() - 0.5) * (this.arenaSize * 1.8);
        const cz = (Math.random() - 0.5) * (this.arenaSize * 1.8);
        const cy = 34 + Math.random() * 12;
        cloudMesh.position.set(cx, cy, cz);
        const scale = 0.8 + Math.random() * 0.8;
        cloudMesh.scale.set(scale, scale, scale);
        this.scene.add(cloudMesh);
        this.clouds.push({ mesh: cloudMesh, speed: 0.8 + Math.random() * 1.2 });
      }
    }

    // 1. Remove existing roads & build new road network
    this.roadMeshes.forEach((r) => {
      this.scene.remove(r);
      GameEngine3D.disposeHierarchy(r);
    });
    this.roadMeshes = [];
    this.roads = [];

    const pattern = config.environment.roadPattern;
    const roadLen = this.arenaSize * 1.05;

    if (pattern === 'country_road') {
      const roadW = 8.5;
      const rMesh = ModelFactory.createRoadMesh(roadW, roadLen, 0, false);
      rMesh.position.set(0, 0, 0);
      this.scene.add(rMesh);
      this.roadMeshes.push(rMesh);
      this.roads.push({ x: 0, z: 0, width: roadW, length: roadLen, angle: 0 });
    } else if (pattern === 'suburban_street') {
      const roadW = 8.5;
      const rMesh = ModelFactory.createRoadMesh(roadW, roadLen, Math.PI / 2, true);
      rMesh.position.set(0, 0, 0);
      this.scene.add(rMesh);
      this.roadMeshes.push(rMesh);
      this.roads.push({ x: 0, z: 0, width: roadW, length: roadLen, angle: Math.PI / 2, isCrosswalk: true });
    } else if (pattern === 'city_crossroads') {
      // 4-Way Metropolis Crossroad Intersection
      const roadW = 10.0;
      const r1 = ModelFactory.createRoadMesh(roadW, roadLen, 0, true);
      r1.position.set(0, 0, 0);
      this.scene.add(r1);
      this.roadMeshes.push(r1);
      this.roads.push({ x: 0, z: 0, width: roadW, length: roadLen, angle: 0, isCrosswalk: true });

      const r2 = ModelFactory.createRoadMesh(roadW, roadLen, Math.PI / 2, true);
      r2.position.set(0, 0, 0);
      this.scene.add(r2);
      this.roadMeshes.push(r2);
      this.roads.push({ x: 0, z: 0, width: roadW, length: roadLen, angle: Math.PI / 2, isCrosswalk: true });
    } else if (pattern === 'highway_grid') {
      const roadW = 9.0;
      const r1 = ModelFactory.createRoadMesh(roadW, roadLen, Math.PI / 2, true);
      r1.position.set(0, 0, -18);
      this.scene.add(r1);
      this.roadMeshes.push(r1);
      this.roads.push({ x: 0, z: -18, width: roadW, length: roadLen, angle: Math.PI / 2, isCrosswalk: true });

      const r2 = ModelFactory.createRoadMesh(roadW, roadLen, Math.PI / 2, true);
      r2.position.set(0, 0, 18);
      this.scene.add(r2);
      this.roadMeshes.push(r2);
      this.roads.push({ x: 0, z: 18, width: roadW, length: roadLen, angle: Math.PI / 2, isCrosswalk: true });

      const r3 = ModelFactory.createRoadMesh(roadW, roadLen, 0, true);
      r3.position.set(0, 0, 0);
      this.scene.add(r3);
      this.roadMeshes.push(r3);
      this.roads.push({ x: 0, z: 0, width: roadW, length: roadLen, angle: 0, isCrosswalk: true });
    } else if (pattern === 'megacity_boulevard') {
      const roadW = 12.0;
      const r1 = ModelFactory.createRoadMesh(roadW, roadLen, 0, true);
      r1.position.set(0, 0, 0);
      this.scene.add(r1);
      this.roadMeshes.push(r1);
      this.roads.push({ x: 0, z: 0, width: roadW, length: roadLen, angle: 0, isCrosswalk: true });

      const crossW = 9.0;
      const r2 = ModelFactory.createRoadMesh(crossW, roadLen, Math.PI / 2, true);
      r2.position.set(0, 0, -14);
      this.scene.add(r2);
      this.roadMeshes.push(r2);
      this.roads.push({ x: 0, z: -14, width: crossW, length: roadLen, angle: Math.PI / 2, isCrosswalk: true });

      const r3 = ModelFactory.createRoadMesh(crossW, roadLen, Math.PI / 2, true);
      r3.position.set(0, 0, 16);
      this.scene.add(r3);
      this.roadMeshes.push(r3);
      this.roads.push({ x: 0, z: 16, width: crossW, length: roadLen, angle: Math.PI / 2, isCrosswalk: true });
    } else if (pattern === 'airbase_tarmac') {
      const roadW = 16.0;
      const rMesh = ModelFactory.createRoadMesh(roadW, roadLen, 0, false);
      rMesh.position.set(0, 0, 0);
      this.scene.add(rMesh);
      this.roadMeshes.push(rMesh);
      this.roads.push({ x: 0, z: 0, width: roadW, length: roadLen, angle: 0 });
    }

    // 2. Remove existing drivable cars & spawn area cars
    this.cars.forEach((c) => {
      const m = this.carMeshes.get(c.id);
      if (m) {
        this.scene.remove(m);
        GameEngine3D.disposeHierarchy(m);
      }
    });
    this.cars = [];
    this.carMeshes.clear();
    this.isDriving = false;
    this.currentCar = null;
    this.nearCar = null;

    const carTypes = config.environment.drivableCarTypes || ['sedan'];
    const carCount = config.environment.carCount || 2;

    for (let c = 0; c < carCount; c++) {
      const type = carTypes[c % carTypes.length];
      let cx = 0;
      let cz = 0;
      let cAngle = 0;

      if (c === 0) {
        // Place primary car right near player start (easy access!)
        cx = 6.0;
        cz = 4.5;
        cAngle = Math.PI / 2;
      } else if (c === 1) {
        cx = -16.0;
        cz = -14.0;
        cAngle = 0;
      } else {
        cx = 18.0;
        cz = -16.0;
        cAngle = Math.PI;
      }

      const id = this.nextCarId++;
      let name = 'Civilian 4-Door Sedan';
      let maxSpeed = 22;
      let hp = 220;
      if (type === 'police') {
        name = 'Tactical Police Cruiser';
        maxSpeed = 26;
        hp = 260;
      } else if (type === 'suv') {
        name = 'Armored Tactical SUV';
        maxSpeed = 20;
        hp = 320;
      } else if (type === 'muscle') {
        name = 'V8 Turbo Muscle Car';
        maxSpeed = 30;
        hp = 240;
      } else if (type === 'cyber') {
        name = 'Cyber Interceptor Supercar';
        maxSpeed = 34;
        hp = 280;
      }

      const car: CarEntity = {
        id,
        type,
        name,
        x: cx,
        z: cz,
        angle: cAngle,
        speed: 0,
        maxSpeed,
        reverseSpeed: -10,
        turnSpeed: type === 'cyber' ? 3.2 : 2.8,
        acceleration: type === 'cyber' ? 32 : 28,
        health: hp,
        maxHealth: hp,
        color: type === 'cyber' ? 0x06b6d4 : 0x2563eb,
        width: type === 'suv' ? 2.4 : type === 'cyber' ? 2.25 : 2.1,
        depth: type === 'suv' ? 4.8 : type === 'cyber' ? 4.7 : 4.5,
        height: 1.5,
        radius: 2.4,
        isDriven: false,
      };

      this.cars.push(car);
      const cMesh = ModelFactory.createDrivableCarModel(type, false);
      cMesh.position.set(cx, 0, cz);
      cMesh.rotation.y = cAngle;
      this.carMeshes.set(id, cMesh);
      this.scene.add(cMesh);
    }

    // 3. Remove existing obstacles & blood stains
    this.obstacles.forEach((ob) => {
      const mesh = this.obstacleMeshes.get(ob.id);
      if (mesh) {
        this.scene.remove(mesh);
        GameEngine3D.disposeHierarchy(mesh);
      }
    });
    this.obstacles = [];
    this.obstacleMeshes.clear();

    this.bloodStains.forEach((b) => this.scene.remove(b.mesh));
    this.bloodStains = [];

    // 4. Generate balanced 3D Houses, City Skyscraper High-Rises & Obstacles
    const obstacleCount = 14 + levelNum * 2;
    const types = config.environment.obstacleTypeDistribution;

    for (let i = 0; i < obstacleCount; i++) {
      let ox = 0;
      let oz = 0;
      let safe = false;
      let attempts = 0;
      const type = types[Math.floor(Math.random() * types.length)];

      let radius = 1.3;
      let w = 1.4;
      let d = 1.4;
      let h = 1.4;

      if (type === 'skyscraper') {
        w = 6.4;
        d = 6.4;
        h = 20.0;
        radius = 4.2;
      } else if (type === 'storefront') {
        w = 5.6;
        d = 5.0;
        h = 3.8;
        radius = 3.5;
      } else if (type === 'billboard') {
        w = 5.2;
        d = 1.0;
        h = 6.2;
        radius = 2.4;
      } else if (type === 'traffic_light') {
        w = 0.6;
        d = 0.6;
        h = 5.0;
        radius = 0.8;
      } else if (type === 'barrier') {
        w = 3.2;
        d = 0.8;
        h = 1.0;
        radius = 1.6;
      } else if (type === 'house') {
        w = 6.0;
        d = 5.5;
        h = 4.2;
        radius = 3.8;
      } else if (type === 'barn') {
        w = 7.0;
        d = 6.0;
        h = 4.8;
        radius = 4.4;
      } else if (type === 'cabin') {
        w = 5.2;
        d = 4.5;
        h = 3.4;
        radius = 3.2;
      } else if (type === 'fence') {
        w = 3.0;
        d = 0.6;
        h = 1.2;
        radius = 1.6;
      } else if (type === 'car') {
        w = 2.0;
        d = 4.0;
        h = 1.5;
        radius = 2.2;
      } else if (type === 'container') {
        w = 2.4;
        d = 5.0;
        h = 2.4;
        radius = 2.8;
      } else if (type === 'sandbag') {
        w = 3.6;
        d = 1.2;
        h = 0.9;
        radius = 1.9;
      } else if (type === 'tree') {
        w = 2.0;
        d = 2.0;
        h = 4.5;
        radius = 1.4;
      } else if (type === 'pod') {
        w = 2.0;
        d = 2.0;
        h = 3.0;
        radius = 1.3;
      } else if (type === 'streetlight') {
        w = 0.5;
        d = 0.5;
        h = 4.5;
        radius = 0.6;
      }

      while (!safe && attempts < 40) {
        attempts++;
        ox = (Math.random() - 0.5) * (this.arenaSize - 16);
        oz = (Math.random() - 0.5) * (this.arenaSize - 16);

        // Don't spawn on top of player center spawn
        if (Math.hypot(ox, oz) > radius + 6) {
          safe = true;

          // Don't block road driving lanes!
          for (const r of this.roads) {
            if (r.angle === 0) {
              if (Math.abs(ox - r.x) < r.width / 2 + radius * 0.4) {
                // If it's a building or large obstacle, keep road clear
                if (type !== 'traffic_light' && type !== 'barrier') {
                  safe = false;
                  break;
                }
              }
            } else {
              if (Math.abs(oz - r.z) < r.width / 2 + radius * 0.4) {
                if (type !== 'traffic_light' && type !== 'barrier') {
                  safe = false;
                  break;
                }
              }
            }
          }

          // Don't spawn on top of cars
          if (safe) {
            for (const c of this.cars) {
              if (Math.hypot(ox - c.x, oz - c.z) < radius + c.radius + 1.5) {
                safe = false;
                break;
              }
            }
          }

          // Don't overlap other obstacles
          if (safe) {
            for (const other of this.obstacles) {
              if (Math.hypot(ox - other.x, oz - other.z) < radius + other.radius + 1.8) {
                safe = false;
                break;
              }
            }
          }
        }
      }

      const id = i + 1;
      const ob: Obstacle3D = { id, x: ox, z: oz, width: w, depth: d, height: h, radius, type };
      this.obstacles.push(ob);

      const mesh = ModelFactory.createObstacleModel(type);
      mesh.position.set(ox, 0, oz);
      mesh.rotation.y = (Math.floor(Math.random() * 4) * Math.PI) / 2;
      this.obstacleMeshes.set(id, mesh);
      this.scene.add(mesh);
    }
  }

  public enterCar(car: CarEntity) {
    if (this.isDriving || car.health <= 0) return;
    this.isDriving = true;
    this.currentCar = car;
    car.isDriven = true;
    this.playerStats.isDriving = true;
    this.playerStats.currentCarId = car.id;
    this.playerMesh.visible = false;
    sounds.playCarEnter();
    this.syncHud();
  }

  public exitCar() {
    if (!this.isDriving || !this.currentCar) return;
    const car = this.currentCar;
    car.isDriven = false;
    car.speed = 0;
    this.isDriving = false;
    this.currentCar = null;
    this.playerStats.isDriving = false;
    this.playerStats.currentCarId = null;

    // Place player beside car driver side
    const exitAngle = car.angle - Math.PI / 2;
    this.playerStats.x = car.x + Math.sin(exitAngle) * 2.2;
    this.playerStats.z = car.z + Math.cos(exitAngle) * 2.2;
    this.playerMesh.position.set(this.playerStats.x, 0, this.playerStats.z);
    this.playerMesh.visible = true;
    sounds.playCarExit();
    this.syncHud();
  }

  public toggleCarHorn() {
    if (!this.isDriving) return;
    sounds.playCarHonk();
    this.screenShake = 0.25;
    // Horn attracts nearby zombies
    for (const z of this.zombies) {
      const d = Math.hypot(z.x - this.playerStats.x, z.z - this.playerStats.z);
      if (d < 35) {
        z.speed = z.baseSpeed * 1.35;
      }
    }
  }

  public startGame() {
    this.currentLevel = 1;
    this.playerStats.x = 0;
    this.playerStats.z = 0;
    this.playerStats.health = this.playerStats.maxHealth;
    this.playerStats.score = 0;
    this.playerStats.killsInLevel = 0;
    this.playerStats.totalKills = 0;
    this.playerStats.activeWeapon = 'pistol';
    this.playerMesh.position.set(0, 0, 0);

    this.clearEnemiesAndBullets();
    this.buildArea(1);

    this.setState('PLAYING');
    this.lastTime = performance.now();
    if (!this.animationFrameId) {
      this.loop(this.lastTime);
    }
  }

  public startLevel(levelNum: number) {
    this.currentLevel = levelNum;
    this.playerStats.killsInLevel = 0;
    this.playerStats.x = 0;
    this.playerStats.z = 0;
    this.playerMesh.position.set(0, 0, 0);

    // Award bonus health on advance
    this.playerStats.health = Math.min(this.playerStats.maxHealth, this.playerStats.health + 35);

    // Bonus ammo resupply
    this.playerStats.ammo.shotgun += 15;
    this.playerStats.ammo.rifle += 60;
    this.playerStats.ammo.plasma += 10;
    this.playerStats.ammo.rpg += 3;

    this.clearEnemiesAndBullets();
    this.buildArea(levelNum);

    this.setState('PLAYING');
  }

  private clearEnemiesAndBullets() {
    this.zombies.forEach((z) => {
      const mesh = this.zombieMeshes.get(z.id);
      if (mesh) {
        this.scene.remove(mesh);
        GameEngine3D.disposeHierarchy(mesh);
      }
    });
    this.zombies = [];
    this.zombieMeshes.clear();

    this.bullets.forEach((b) => {
      const mesh = this.bulletMeshes.get(b.id);
      if (mesh) this.scene.remove(mesh);
    });
    this.bullets = [];
    this.bulletMeshes.clear();

    this.powerUps.forEach((p) => {
      const mesh = this.powerUpMeshes.get(p.id);
      if (mesh) {
        this.scene.remove(mesh);
        GameEngine3D.disposeHierarchy(mesh);
      }
    });
    this.powerUps = [];
    this.powerUpMeshes.clear();

    this.particles.forEach((p) => this.scene.remove(p.mesh));
    this.particles = [];

    this.bossZombie = null;
    this.bossSpawned = false;
    this.levelKills = 0;
  }

  public pauseGame() {
    if (this.state === 'PLAYING') {
      this.setState('PAUSED');
    }
  }

  public resumeGame() {
    if (this.state === 'PAUSED') {
      this.setState('PLAYING');
      this.lastTime = performance.now();
    }
  }

  public restartGame() {
    this.startGame();
  }

  private setState(newState: GameState) {
    this.state = newState;
    if (this.onStateChange) {
      this.onStateChange(newState);
    }
    this.syncHud();
  }

  private updateHighScore(score: number) {
    if (score > this.highScore) {
      this.highScore = score;
      try {
        localStorage.setItem('zombie_defense_highscore', score.toString());
      } catch {
        // Ignore
      }
    }
  }

  public syncHud() {
    if (this.onHudUpdate) {
      const config = LEVELS[this.currentLevel] || LEVELS[1];
      this.onHudUpdate({
        health: Math.max(0, Math.round(this.playerStats.health)),
        maxHealth: this.playerStats.maxHealth,
        score: this.playerStats.score,
        highScore: this.highScore,
        level: this.currentLevel,
        levelName: config.name,
        levelSubtitle: config.subtitle,
        levelKills: this.levelKills,
        targetKills: config.targetKills,
        activeWeapon: this.playerStats.activeWeapon,
        ammo: this.playerStats.ammo,
        unlockedWeapons: this.playerStats.unlockedWeapons,
        playerClass: this.playerStats.playerClass,
        bossHp: this.bossZombie ? Math.max(0, this.bossZombie.health) : undefined,
        bossMaxHp: this.bossZombie ? this.bossZombie.maxHealth : undefined,
        combo: this.comboCount,
        cameraMode: this.cameraMode,
        // Vehicle telemetry
        isDriving: this.isDriving,
        carHealth: this.currentCar ? Math.max(0, Math.round(this.currentCar.health)) : undefined,
        carMaxHealth: this.currentCar?.maxHealth,
        carSpeedMph: this.currentCar ? Math.round(Math.abs(this.currentCar.speed) * 2.5) : 0,
        carName: this.currentCar?.name,
        nearCarId: this.nearCar?.id,
        nearCarName: this.nearCar?.name,
      });
    }
  }

  // Mobile Touch Control Helpers
  public setVirtualMove(x: number, y: number) {
    this.virtualMove.x = Math.max(-1, Math.min(1, x));
    this.virtualMove.y = Math.max(-1, Math.min(1, y));
    if (Math.abs(x) > 0.05 || Math.abs(y) > 0.05) {
      this.isMobileTouchActive = true;
    }
  }

  public setVirtualAim(angle: number | null) {
    this.virtualAimAngle = angle;
    if (angle !== null) {
      this.isMobileTouchActive = true;
      if (!this.isDriving) {
        this.playerStats.angle = angle;
        if (this.playerMesh) {
          this.playerMesh.rotation.y = angle;
        }
      }
    }
  }

  public setVirtualFire(firing: boolean) {
    this.isMouseDown = firing;
    if (firing) {
      this.isMobileTouchActive = true;
      if (this.state === 'PLAYING') {
        this.fireWeapon();
      }
    }
  }

  public enterNearestCar() {
    if (this.nearCar && !this.isDriving) {
      this.enterCar(this.nearCar);
    }
  }

  public getNearestZombie(maxDist = 35): ZombieEntity | null {
    let nearest: ZombieEntity | null = null;
    let minDist = maxDist;
    for (const z of this.zombies) {
      const d = Math.hypot(z.x - this.playerStats.x, z.z - this.playerStats.z);
      if (d < minDist) {
        minDist = d;
        nearest = z;
      }
    }
    return nearest;
  }

  private setupListeners() {
    window.addEventListener('keydown', (e) => {
      this.keys[e.key.toLowerCase()] = true;
      if (e.key === 'p' || e.key === 'P' || e.key === 'Escape') {
        if (this.state === 'PLAYING') {
          this.pauseGame();
        } else if (this.state === 'PAUSED') {
          this.resumeGame();
        }
      } else if (e.key === 'c' || e.key === 'C') {
        this.toggleCameraMode();
      } else if (e.key === 'm' || e.key === 'M') {
        if (this.onToggleMap) {
          this.onToggleMap();
        }
      } else if (e.key === 'e' || e.key === 'E') {
        if (this.state === 'PLAYING') {
          if (this.isDriving) {
            this.exitCar();
          } else if (this.nearCar) {
            this.enterCar(this.nearCar);
          }
        }
      } else if (e.key === 'h' || e.key === 'H') {
        if (this.state === 'PLAYING' && this.isDriving) {
          this.toggleCarHorn();
        }
      } else if (e.key === '1') {
        this.selectWeapon('pistol');
      } else if (e.key === '2') {
        this.selectWeapon('shotgun');
      } else if (e.key === '3') {
        this.selectWeapon('rifle');
      } else if (e.key === '4') {
        this.selectWeapon('plasma');
      } else if (e.key === '5') {
        this.selectWeapon('rpg');
      }
    });

    window.addEventListener('keyup', (e) => {
      this.keys[e.key.toLowerCase()] = false;
    });

    // Weapon scroll cycle
    window.addEventListener('wheel', (e) => {
      if (this.state !== 'PLAYING') return;
      const weapons: WeaponType[] = ['pistol', 'shotgun', 'rifle', 'plasma', 'rpg'];
      const currentIndex = weapons.indexOf(this.playerStats.activeWeapon);
      if (e.deltaY > 0) {
        const nextIndex = (currentIndex + 1) % weapons.length;
        this.selectWeapon(weapons[nextIndex]);
      } else if (e.deltaY < 0) {
        const prevIndex = (currentIndex - 1 + weapons.length) % weapons.length;
        this.selectWeapon(weapons[prevIndex]);
      }
    });

    this.container.addEventListener('mousemove', (e) => {
      const rect = this.container.getBoundingClientRect();
      this.mouseScreen.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      this.mouseScreen.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      this.updateMouseWorld();
    });

    this.container.addEventListener('mousedown', (e) => {
      if (e.button === 0) {
        this.isMouseDown = true;
        if (this.state === 'PLAYING') {
          this.fireWeapon();
        }
      }
    });

    window.addEventListener('mouseup', (e) => {
      if (e.button === 0) {
        this.isMouseDown = false;
      }
    });

    // Touch support
    this.container.addEventListener('touchstart', (e) => {
      if (e.touches.length > 0) {
        const rect = this.container.getBoundingClientRect();
        this.mouseScreen.x = ((e.touches[0].clientX - rect.left) / rect.width) * 2 - 1;
        this.mouseScreen.y = -((e.touches[0].clientY - rect.top) / rect.height) * 2 + 1;
        this.updateMouseWorld();
        this.isMouseDown = true;
        if (this.state === 'PLAYING') {
          this.fireWeapon();
        }
      }
    });

    this.container.addEventListener('touchmove', (e) => {
      if (e.touches.length > 0) {
        const rect = this.container.getBoundingClientRect();
        this.mouseScreen.x = ((e.touches[0].clientX - rect.left) / rect.width) * 2 - 1;
        this.mouseScreen.y = -((e.touches[0].clientY - rect.top) / rect.height) * 2 + 1;
        this.updateMouseWorld();
      }
    });

    window.addEventListener('touchend', () => {
      this.isMouseDown = false;
    });

    window.addEventListener('resize', () => {
      this.resize();
    });
  }

  public resize() {
    if (!this.container) return;
    const w = this.container.clientWidth;
    const h = this.container.clientHeight;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  }

  private updateMouseWorld() {
    this.raycaster.setFromCamera(this.mouseScreen, this.camera);
    const hit = new THREE.Vector3();
    if (this.raycaster.ray.intersectPlane(this.groundPlane, hit)) {
      this.mouseWorld.copy(hit);
    }
  }

  private fireWeapon() {
    if (this.state !== 'PLAYING') return;
    const now = performance.now();
    const weapon = this.playerStats.activeWeapon;

    let cooldown = 180;
    if (weapon === 'rifle') cooldown = 95;
    if (weapon === 'shotgun') cooldown = 420;
    if (weapon === 'plasma') cooldown = 340;
    if (weapon === 'rpg') cooldown = 750;

    if (now - this.playerStats.lastFireTime < cooldown) return;

    // Check ammo (pistol is infinite)
    if (weapon !== 'pistol') {
      if (this.playerStats.ammo[weapon] <= 0) {
        // Fallback to pistol
        this.selectWeapon('pistol');
        return;
      }
      this.playerStats.ammo[weapon]--;
    }

    this.playerStats.lastFireTime = now;
    this.playerStats.shotsFired++;

    let baseAngle = Math.atan2(this.mouseWorld.x - this.playerStats.x, this.mouseWorld.z - this.playerStats.z);
    if (this.isDriving && this.currentCar) {
      // Fire forward along car trajectory without snapping player/camera angle
      baseAngle = this.currentCar.angle;
    } else {
      if (this.virtualAimAngle !== null) {
        baseAngle = this.virtualAimAngle;
      } else if (this.isMobileTouchActive) {
        // Mobile auto-target closest zombie if available
        const nearest = this.getNearestZombie(35);
        if (nearest) {
          baseAngle = Math.atan2(nearest.x - this.playerStats.x, nearest.z - this.playerStats.z);
        } else {
          baseAngle = this.playerStats.angle;
        }
      }
      this.playerStats.angle = baseAngle;
      if (this.playerMesh) {
        this.playerMesh.rotation.y = baseAngle;
      }
    }

    const forwardOffset = this.isDriving && this.currentCar ? this.currentCar.depth * 0.55 : 0.95;
    const startX = this.playerStats.x + Math.sin(baseAngle) * forwardOffset;
    const startZ = this.playerStats.z + Math.cos(baseAngle) * forwardOffset;
    const startY = this.isDriving ? 0.85 : 1.15;

    sounds.playShoot(weapon);

    if (weapon === 'shotgun') {
      this.screenShake = 0.38;
      const spreadCount = 6;
      const spreadArc = 0.4;
      for (let i = 0; i < spreadCount; i++) {
        const offset = -spreadArc / 2 + (spreadArc / (spreadCount - 1)) * i + (Math.random() - 0.5) * 0.06;
        const angle = baseAngle + offset;
        const speed = 42 + Math.random() * 5;
        this.createBullet(startX, startY, startZ, Math.sin(angle) * speed, Math.cos(angle) * speed, 1.5, 0xf59e0b, 0.45, 'shotgun');
      }
      this.createMuzzleSparks(startX, startY, startZ, 0xf59e0b, 10);
    } else if (weapon === 'rifle') {
      this.screenShake = 0.12;
      const spread = (Math.random() - 0.5) * 0.08;
      const angle = baseAngle + spread;
      const speed = 52;
      this.createBullet(startX, startY, startZ, Math.sin(angle) * speed, Math.cos(angle) * speed, 1.25, 0x60a5fa, 0.75, 'rifle');
      this.createMuzzleSparks(startX, startY, startZ, 0x60a5fa, 5);
    } else if (weapon === 'plasma') {
      this.screenShake = 0.25;
      const speed = 65;
      this.createBullet(startX, startY, startZ, Math.sin(baseAngle) * speed, Math.cos(baseAngle) * speed, 3.8, 0x00f0ff, 0.9, 'plasma', 3);
      this.createMuzzleSparks(startX, startY, startZ, 0x00f0ff, 8);
    } else if (weapon === 'rpg') {
      this.screenShake = 0.65;
      const speed = 32;
      this.createBullet(startX, startY, startZ, Math.sin(baseAngle) * speed, Math.cos(baseAngle) * speed, 10.0, 0xf97316, 1.8, 'rpg', 0, true);
      this.createMuzzleSparks(startX, startY, startZ, 0xf97316, 12);
    } else {
      // Pistol
      this.screenShake = 0.1;
      const spread = (Math.random() - 0.5) * 0.04;
      const angle = baseAngle + spread;
      const speed = 44;
      this.createBullet(startX, startY, startZ, Math.sin(angle) * speed, Math.cos(angle) * speed, 1.6, 0xfbbf24, 0.85, 'pistol');
      this.createMuzzleSparks(startX, startY, startZ, 0xfbbf24, 6);
    }

    this.syncHud();
  }

  private createBullet(
    x: number,
    y: number,
    z: number,
    vx: number,
    vz: number,
    damage: number,
    colorHex: number,
    life: number,
    weaponType: WeaponType,
    pierceCount = 0,
    isRocket = false
  ) {
    const id = this.nextBulletId++;
    const bullet: Bullet3D = {
      id,
      x,
      y,
      z,
      vx,
      vz,
      damage,
      radius: isRocket ? 0.35 : weaponType === 'plasma' ? 0.25 : 0.16,
      color: colorHex,
      life,
      weaponType,
      pierceCount,
      isRocket,
    };
    this.bullets.push(bullet);

    // Glowing 3D Mesh (Shared Static Geometries to Prevent Leaks)
    let geo = GameEngine3D.bulletSphereGeo;
    if (isRocket) {
      geo = GameEngine3D.rocketConeGeo;
    } else if (weaponType === 'plasma') {
      geo = GameEngine3D.plasmaCylinderGeo;
    }

    const mat = GameEngine3D.getSharedMaterial(colorHex, 0.95);
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(x, y, z);
    this.bulletMeshes.set(id, mesh);
    this.scene.add(mesh);
  }

  private createMuzzleSparks(x: number, y: number, z: number, colorHex: number, count: number) {
    const safeCount = Math.min(count, 5);
    const mat = GameEngine3D.getSharedMaterial(colorHex);
    for (let i = 0; i < safeCount; i++) {
      const mesh = new THREE.Mesh(GameEngine3D.sparkGeo, mat);
      mesh.position.set(x, y, z);
      this.scene.add(mesh);

      const angle = Math.random() * Math.PI * 2;
      const speed = 3 + Math.random() * 8;
      this.particles.push({
        mesh,
        vx: Math.cos(angle) * speed,
        vy: 1 + Math.random() * 4,
        vz: Math.sin(angle) * speed,
        life: 0,
        maxLife: 0.15 + Math.random() * 0.1,
      });
    }
  }

  private triggerRocketExplosion(x: number, z: number) {
    sounds.playExplosion();
    this.screenShake = 1.6;

    // Fiery shockwave blast
    this.createGoreExplosion(x, 1.2, z, 30);

    // AOE Damage radius
    const aoeRadius = 5.5;
    for (let j = this.zombies.length - 1; j >= 0; j--) {
      const zEntity = this.zombies[j];
      const dist = Math.hypot(zEntity.x - x, zEntity.z - z);
      if (dist < aoeRadius + zEntity.radius) {
        const falloff = 1 - dist / (aoeRadius + zEntity.radius);
        zEntity.health -= 12 * Math.max(0.3, falloff);
        this.addBloodDecal(zEntity.x, zEntity.z, zEntity.type === 'boss');

        // Knockback from blast center
        const angle = Math.atan2(zEntity.x - x, zEntity.z - z);
        zEntity.x += Math.sin(angle) * 2.2;
        zEntity.z += Math.cos(angle) * 2.2;

        if (zEntity.health <= 0) {
          this.killZombie(zEntity, j);
        }
      }
    }
  }

  private spawnZombie(type: ZombieType, isBoss = false) {
    const side = Math.floor(Math.random() * 4);
    const half = this.arenaSize / 2 + 4;
    let x = 0;
    let z = 0;

    if (side === 0) {
      x = (Math.random() - 0.5) * this.arenaSize;
      z = -half;
    } else if (side === 1) {
      x = half;
      z = (Math.random() - 0.5) * this.arenaSize;
    } else if (side === 2) {
      x = (Math.random() - 0.5) * this.arenaSize;
      z = half;
    } else {
      x = -half;
      z = (Math.random() - 0.5) * this.arenaSize;
    }

    let speed = 4.2;
    let radius = 0.65;
    let health = 3;
    let damage = 10;
    let scoreValue = 100;

    if (type === 'runner') {
      speed = 7.5;
      radius = 0.58;
      health = 2;
      damage = 8;
      scoreValue = 150;
    } else if (type === 'toxic') {
      speed = 5.2;
      radius = 0.7;
      health = 4.5;
      damage = 14;
      scoreValue = 200;
    } else if (type === 'armored') {
      speed = 3.8;
      radius = 0.75;
      health = 6.5;
      damage = 16;
      scoreValue = 250;
    } else if (type === 'boss') {
      speed = 3.6;
      radius = 2.0;
      health = 85;
      damage = 25;
      scoreValue = 2500;
    }

    const id = this.nextZombieId++;
    const zombie: ZombieEntity = {
      id,
      type,
      x,
      z,
      vx: 0,
      vz: 0,
      speed,
      baseSpeed: speed,
      radius,
      health,
      maxHealth: health,
      damage,
      scoreValue,
      angle: 0,
      walkCycle: Math.random() * 10,
      lastAttackTime: 0,
      isHitFlash: 0,
      chargeCooldown: isBoss ? 5 : undefined,
      isCharging: false,
    };

    if (isBoss) {
      this.bossZombie = zombie;
      sounds.playBossAlarm();
      this.screenShake = 1.4;
    }

    this.zombies.push(zombie);

    const mesh = ModelFactory.createZombieModel(type);
    mesh.position.set(x, 0, z);
    this.zombieMeshes.set(id, mesh);
    this.scene.add(mesh);
  }

  private addBloodDecal(x: number, z: number, isBoss = false) {
    const scale = isBoss ? 2.6 : 1.3 + Math.random() * 0.5;
    const mat = GameEngine3D.getSharedMaterial(isBoss ? 0x450a0a : 0x7f1d1d, 0.75);
    const mesh = new THREE.Mesh(GameEngine3D.bloodPlaneGeo, mat);
    mesh.position.set(x, 0.03, z);
    mesh.scale.set(scale, 1, scale);
    this.scene.add(mesh);

    this.bloodStains.push({ x, z, mesh });
    if (this.bloodStains.length > 25) {
      const old = this.bloodStains.shift();
      if (old) {
        this.scene.remove(old.mesh);
      }
    }
  }

  private spawnPowerUp(x: number, z: number) {
    const roll = Math.random();
    let type: 'health' | 'shotgun_ammo' | 'rifle_ammo' | 'plasma_ammo' | 'rpg_ammo' | 'nuke' = 'health';
    if (roll < 0.28) type = 'health';
    else if (roll < 0.46) type = 'rifle_ammo';
    else if (roll < 0.64) type = 'shotgun_ammo';
    else if (roll < 0.8) type = 'plasma_ammo';
    else if (roll < 0.92) type = 'rpg_ammo';
    else type = 'nuke';

    const id = this.nextPowerUpId++;
    const p: PowerUp3D = {
      id,
      x,
      z,
      type,
      createdAt: performance.now(),
      duration: 16,
    };
    this.powerUps.push(p);

    const mesh = ModelFactory.createPowerUpModel(type);
    mesh.position.set(x, 0.6, z);
    this.powerUpMeshes.set(id, mesh);
    this.scene.add(mesh);
  }

  private triggerNuke() {
    this.screenShake = 2.2;
    sounds.playZombieDeath(true);

    for (let i = this.zombies.length - 1; i >= 0; i--) {
      const z = this.zombies[i];
      if (z.type === 'boss') {
        z.health -= 40;
        this.addBloodDecal(z.x, z.z, true);
        if (z.health <= 0) {
          this.killZombie(z, i);
        }
      } else {
        this.killZombie(z, i);
      }
    }
  }

  private killZombie(z: ZombieEntity, index: number) {
    const isBoss = z.type === 'boss';
    sounds.playZombieDeath(isBoss);

    const now = performance.now();
    if (now - this.lastKillTime < 2500) {
      this.comboCount = Math.min(this.comboCount + 1, 5);
    } else {
      this.comboCount = 1;
    }
    this.lastKillTime = now;

    const multiplier = 1 + (this.comboCount - 1) * 0.25;
    const earnedScore = Math.round(z.scoreValue * multiplier);
    this.playerStats.score += earnedScore;
    this.updateHighScore(this.playerStats.score);

    this.playerStats.totalKills++;
    this.levelKills++;
    this.playerStats.killsInLevel++;

    this.addBloodDecal(z.x, z.z, isBoss);
    this.createGoreExplosion(z.x, 1.0, z.z, isBoss ? 35 : 14);

    const mesh = this.zombieMeshes.get(z.id);
    if (mesh) {
      this.scene.remove(mesh);
      GameEngine3D.disposeHierarchy(mesh);
      this.zombieMeshes.delete(z.id);
    }

    if (isBoss || Math.random() < 0.24) {
      this.spawnPowerUp(z.x, z.z);
    }

    if (isBoss) {
      this.bossZombie = null;
    }

    this.zombies.splice(index, 1);

    const config = LEVELS[this.currentLevel];
    const totalLevels = Object.keys(LEVELS).length;
    if (this.currentLevel === totalLevels) {
      if (this.levelKills >= config.targetKills && this.bossSpawned && !this.bossZombie) {
        this.handleVictory();
      }
    } else {
      if (this.levelKills >= config.targetKills) {
        this.handleLevelClear();
      }
    }
  }

  private handleLevelClear() {
    sounds.playLevelClear();
    this.setState('LEVEL_TRANSITION');
  }

  private handleVictory() {
    sounds.playVictory();
    this.setState('VICTORY');
  }

  private handleGameOver() {
    sounds.playGameOver();
    this.updateHighScore(this.playerStats.score);
    this.setState('GAME_OVER');
  }

  private createGoreExplosion(x: number, y: number, z: number, count: number) {
    const safeCount = Math.min(count, 14);
    for (let i = 0; i < safeCount; i++) {
      const isDark = Math.random() > 0.4;
      const mat = GameEngine3D.getSharedMaterial(isDark ? 0x991b1b : 0x450a0a);
      const mesh = new THREE.Mesh(GameEngine3D.particleGeo, mat);
      mesh.position.set(x, y, z);
      this.scene.add(mesh);

      const angle = Math.random() * Math.PI * 2;
      const speed = 4 + Math.random() * 8;
      this.particles.push({
        mesh,
        vx: Math.cos(angle) * speed,
        vy: 2 + Math.random() * 6,
        vz: Math.sin(angle) * speed,
        life: 0,
        maxLife: 0.35 + Math.random() * 0.25,
      });
    }
  }

  public loop(timestamp: number) {
    const dt = Math.min((timestamp - this.lastTime) / 1000, 0.1);
    this.lastTime = timestamp;

    if (this.state === 'PLAYING') {
      this.update(dt, timestamp);
    }

    // Drift clouds
    for (const cloud of this.clouds) {
      cloud.mesh.position.x += cloud.speed * dt;
      if (cloud.mesh.position.x > this.arenaSize) {
        cloud.mesh.position.x = -this.arenaSize;
      }
    }

    this.updateCamera(dt);
    this.renderer.render(this.scene, this.camera);
    this.animationFrameId = requestAnimationFrame((t) => this.loop(t));
  }

  public stop() {
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }
  }

  private update(dt: number, now: number) {
    if (this.isMouseDown) {
      this.fireWeapon();
    }

    if (this.screenShake > 0) {
      this.screenShake -= dt * 2.5;
      if (this.screenShake < 0) this.screenShake = 0;
    }

    if (this.isDriving && this.currentCar) {
      const car = this.currentCar;

      // Smooth Automotive Steering (Keyboard or Touch Virtual Joystick / Steer Buttons)
      const isReversing = car.speed < -0.3;
      const steerDir = isReversing ? -1 : 1;
      const speedScale = Math.min(1.0, Math.max(0.35, Math.abs(car.speed) / 4.5));
      const steerLeft = this.keys['a'] || this.keys['arrowleft'] || this.virtualMove.x < -0.15;
      const steerRight = this.keys['d'] || this.keys['arrowright'] || this.virtualMove.x > 0.15;
      const steerIntensity = Math.abs(this.virtualMove.x) > 0.15 ? Math.abs(this.virtualMove.x) : 1;

      if (steerLeft) {
        car.angle += car.turnSpeed * dt * steerDir * speedScale * steerIntensity;
      }
      if (steerRight) {
        car.angle -= car.turnSpeed * dt * steerDir * speedScale * steerIntensity;
      }

      // Acceleration & Braking (Keyboard or Touch Virtual Joystick / Pedals)
      const throttle = this.keys['w'] || this.keys['arrowup'] || this.virtualMove.y < -0.15;
      const brake = this.keys['s'] || this.keys['arrowdown'] || this.virtualMove.y > 0.15;
      const throttleIntensity = this.virtualMove.y < -0.15 ? Math.abs(this.virtualMove.y) : 1;
      const brakeIntensity = this.virtualMove.y > 0.15 ? Math.abs(this.virtualMove.y) : 1;

      if (throttle) {
        car.speed = Math.min(car.maxSpeed, car.speed + car.acceleration * dt * throttleIntensity);
        if (Math.random() < 0.12) sounds.playEngineThrottle();
      } else if (brake) {
        car.speed = Math.max(car.reverseSpeed, car.speed - car.acceleration * 1.2 * dt * brakeIntensity);
      } else {
        // Natural friction coasting
        car.speed *= Math.pow(0.88, dt * 60);
        if (Math.abs(car.speed) < 0.2) car.speed = 0;
      }

      let nextCarX = car.x + Math.sin(car.angle) * car.speed * dt;
      let nextCarZ = car.z + Math.cos(car.angle) * car.speed * dt;

      // Obstacle collision resolution: clean tangential sliding prevents bucking/jittering inside obstacles
      for (const ob of this.obstacles) {
        const minD = car.radius + ob.radius;
        const d = Math.hypot(nextCarX - ob.x, nextCarZ - ob.z);
        if (d < minD && d > 0.001) {
          const overlap = minD - d;
          const nx = (nextCarX - ob.x) / d;
          const nz = (nextCarZ - ob.z) / d;

          // Push out smoothly along collision normal
          nextCarX += nx * (overlap + 0.06);
          nextCarZ += nz * (overlap + 0.06);

          // Project velocity along tangent to allow smooth gliding instead of oscillating bounce
          const headingX = Math.sin(car.angle) * car.speed;
          const headingZ = Math.cos(car.angle) * car.speed;
          const dot = headingX * nx + headingZ * nz;
          if (dot < 0) {
            const slideX = headingX - dot * nx;
            const slideZ = headingZ - dot * nz;
            const slideSpeed = Math.hypot(slideX, slideZ);
            car.speed = Math.sign(car.speed || 1) * Math.max(0, slideSpeed * 0.8);
            if (Math.abs(car.speed) < 0.4) car.speed = 0;
          }

          if (Math.abs(car.speed) > 3.5 && (!car.lastHitTime || now - car.lastHitTime > 450)) {
            car.lastHitTime = now;
            sounds.playCarRam();
            this.screenShake = 0.2;
            car.health -= 4;
            this.createMuzzleSparks(car.x, 0.6, car.z, 0xfacc15, 6);
          }
          break;
        }
      }

      const halfA = this.arenaSize / 2 - 2.5;
      if (nextCarX <= -halfA || nextCarX >= halfA || nextCarZ <= -halfA || nextCarZ >= halfA) {
        car.speed *= 0.5;
        if (Math.abs(car.speed) < 0.5) car.speed = 0;
      }
      car.x = Math.max(-halfA, Math.min(halfA, nextCarX));
      car.z = Math.max(-halfA, Math.min(halfA, nextCarZ));

      // Sync player coordinates with car
      this.playerStats.x = car.x;
      this.playerStats.z = car.z;
      this.playerStats.angle = car.angle;

      // Update car mesh in scene
      const cMesh = this.carMeshes.get(car.id);
      if (cMesh) {
        cMesh.position.set(car.x, 0, car.z);
        cMesh.rotation.y = car.angle;

        // Animate police lightbar strobes
        if (car.type === 'police') {
          const strobeLight = cMesh.getObjectByName('strobeLight') as THREE.PointLight;
          const blueStrobe = cMesh.getObjectByName('blueStrobe') as THREE.Mesh;
          const redStrobe = cMesh.getObjectByName('redStrobe') as THREE.Mesh;
          if (strobeLight && blueStrobe && redStrobe) {
            const isBlue = Math.floor(now * 0.008) % 2 === 0;
            strobeLight.color.setHex(isBlue ? 0x0066ff : 0xff0033);
            (blueStrobe.material as THREE.MeshBasicMaterial).color.setHex(isBlue ? 0x00ffff : 0x002266);
            (redStrobe.material as THREE.MeshBasicMaterial).color.setHex(!isBlue ? 0xff3333 : 0x660000);
          }
        }
      }

      // RAMMING / RUNNING OVER ZOMBIES
      const carSpeedAbs = Math.abs(car.speed);
      if (carSpeedAbs > 3.0) {
        for (let j = this.zombies.length - 1; j >= 0; j--) {
          const z = this.zombies[j];
          const dist = Math.hypot(car.x - z.x, car.z - z.z);
          if (dist < car.radius + z.radius + 0.4) {
            const ramDmg = carSpeedAbs * 2.8;
            z.health -= ramDmg;
            z.lastAttackTime = now + 400; // prevents immediate counter-attack on same frame
            sounds.playCarRam();
            this.screenShake = Math.max(this.screenShake, 0.35);
            this.addBloodDecal(z.x, z.z, z.type === 'boss');
            this.createGoreExplosion(z.x, 0.7, z.z, 14);

            // Shove zombie in driving trajectory
            z.x += Math.sin(car.angle) * 4.2;
            z.z += Math.cos(car.angle) * 4.2;

            if (z.health <= 0) {
              this.killZombie(z, j);
            }
          }
        }
      }

      // If car is destroyed, trigger explosion and eject player
      if (car.health <= 0) {
        this.triggerRocketExplosion(car.x, car.z);
        this.exitCar();
        car.health = 0;
      }
    } else {
      // On-foot Player Movement (Keyboard or Virtual Thumbstick)
      let mx = 0;
      let mz = 0;
      if (this.keys['w'] || this.keys['arrowup']) mz -= 1;
      if (this.keys['s'] || this.keys['arrowdown']) mz += 1;
      if (this.keys['a'] || this.keys['arrowleft']) mx -= 1;
      if (this.keys['d'] || this.keys['arrowright']) mx += 1;

      // Virtual joystick input from mobile touch
      if (Math.abs(this.virtualMove.x) > 0.05) mx += this.virtualMove.x;
      if (Math.abs(this.virtualMove.y) > 0.05) mz += this.virtualMove.y;

      const isMoving = mx !== 0 || mz !== 0;

      if (isMoving) {
        const len = Math.hypot(mx, mz);
        if (len > 1) {
          mx /= len;
          mz /= len;
        }
      }

      let nextX = this.playerStats.x + mx * this.playerStats.speed * dt;
      let nextZ = this.playerStats.z + mz * this.playerStats.speed * dt;

      // Obstacle collision detection
      for (const ob of this.obstacles) {
        const dist = Math.hypot(nextX - ob.x, nextZ - ob.z);
        if (dist < this.playerStats.radius + ob.radius) {
          nextX = this.playerStats.x;
          nextZ = this.playerStats.z;
          break;
        }
      }

      const halfArena = this.arenaSize / 2 - 1.5;
      this.playerStats.x = Math.max(-halfArena, Math.min(halfArena, nextX));
      this.playerStats.z = Math.max(-halfArena, Math.min(halfArena, nextZ));

      let aimAngle = Math.atan2(this.mouseWorld.x - this.playerStats.x, this.mouseWorld.z - this.playerStats.z);
      if (this.virtualAimAngle !== null) {
        aimAngle = this.virtualAimAngle;
      } else if (this.isMobileTouchActive && isMoving && !this.isMouseDown) {
        aimAngle = Math.atan2(mx, mz);
      }
      this.playerStats.angle = aimAngle;

      this.playerMesh.position.set(this.playerStats.x, 0, this.playerStats.z);
      this.playerMesh.rotation.y = aimAngle;

      // Player walk animation
      const leftLeg = this.playerMesh.getObjectByName('leftLeg');
      const rightLeg = this.playerMesh.getObjectByName('rightLeg');
      if (leftLeg && rightLeg) {
        if (isMoving) {
          const legSwing = Math.sin(now * 0.015) * 0.35;
          leftLeg.rotation.x = legSwing;
          rightLeg.rotation.x = -legSwing;
        } else {
          leftLeg.rotation.x = 0;
          rightLeg.rotation.x = 0;
        }
      }

      // Check proximity to enterable vehicles
      this.nearCar = null;
      for (const car of this.cars) {
        if (car.health > 0) {
          const d = Math.hypot(this.playerStats.x - car.x, this.playerStats.z - car.z);
          if (d < car.radius + 2.6) {
            this.nearCar = car;
            break;
          }
        }
      }
    }

    // Invulnerability reset
    if (this.playerStats.isInvulnerable && now - this.playerStats.lastHurtTime > 650) {
      this.playerStats.isInvulnerable = false;
      if (!this.isDriving) this.playerMesh.visible = true;
    } else if (this.playerStats.isInvulnerable && !this.isDriving) {
      this.playerMesh.visible = Math.floor((now - this.playerStats.lastHurtTime) / 80) % 2 === 0;
    }

    // Spawning logic
    const config = LEVELS[this.currentLevel];
    if (config) {
      if (
        this.currentLevel === Object.keys(LEVELS).length &&
        !this.bossSpawned &&
        config.bossSpawnsAtKills !== undefined &&
        this.levelKills >= config.bossSpawnsAtKills
      ) {
        this.bossSpawned = true;
        this.spawnZombie('boss', true);
      }

      if (this.levelKills + this.zombies.length < config.targetKills + (this.bossZombie ? 1 : 0)) {
        if (now - this.lastSpawnTime > config.spawnInterval) {
          this.lastSpawnTime = now;
          const roll = Math.random();
          let type: ZombieType = 'walker';
          if (roll < config.walkerProb) {
            type = 'walker';
          } else if (roll < config.walkerProb + config.runnerProb) {
            type = 'runner';
          } else if (roll < config.walkerProb + config.runnerProb + config.toxicProb) {
            type = 'toxic';
          } else {
            type = 'armored';
          }
          this.spawnZombie(type);
        }
      }
    }

    // Update Bullets
    for (let i = this.bullets.length - 1; i >= 0; i--) {
      const b = this.bullets[i];
      b.x += b.vx * dt;
      b.z += b.vz * dt;
      b.life -= dt;

      const mesh = this.bulletMeshes.get(b.id);
      if (mesh) {
        mesh.position.set(b.x, b.y, b.z);
        if (b.isRocket) {
          // Rocket trail particle
          if (Math.random() < 0.4) {
            this.createMuzzleSparks(b.x, b.y, b.z, 0x64748b, 1);
          }
        }
      }

      // Check obstacle hit
      let hitObstacle = false;
      for (const ob of this.obstacles) {
        if (Math.abs(b.x - ob.x) > ob.radius + b.radius || Math.abs(b.z - ob.z) > ob.radius + b.radius) continue;
        if (Math.hypot(b.x - ob.x, b.z - ob.z) < ob.radius + b.radius) {
          hitObstacle = true;
          if (b.isRocket) {
            this.triggerRocketExplosion(b.x, b.z);
          } else {
            this.createMuzzleSparks(b.x, b.y, b.z, 0x94a3b8, 3);
          }
          break;
        }
      }

      // Check zombie hit
      let shouldRemove = hitObstacle;
      if (!hitObstacle) {
        for (let j = this.zombies.length - 1; j >= 0; j--) {
          const z = this.zombies[j];
          if (Math.abs(b.x - z.x) > z.radius + b.radius || Math.abs(b.z - z.z) > z.radius + b.radius) continue;
          const dist = Math.hypot(b.x - z.x, b.z - z.z);
          if (dist < z.radius + b.radius) {
            this.playerStats.shotsHit++;
            sounds.playZombieHit();

            if (b.isRocket) {
              this.triggerRocketExplosion(b.x, b.z);
              shouldRemove = true;
              break;
            } else {
              z.health -= b.damage;
              const knockAngle = Math.atan2(b.vx, b.vz);
              const knockMag = z.type === 'boss' ? 0.08 : 0.45;
              z.x += Math.sin(knockAngle) * knockMag;
              z.z += Math.cos(knockAngle) * knockMag;

              this.createMuzzleSparks(b.x, b.y, b.z, 0xef4444, 4);

              if (z.health <= 0) {
                this.killZombie(z, j);
              }

              // Check penetration for plasma
              if (b.pierceCount && b.pierceCount > 0) {
                b.pierceCount--;
              } else {
                shouldRemove = true;
                break;
              }
            }
          }
        }
      }

      const halfA = this.arenaSize / 2;
      if (shouldRemove || b.life <= 0 || Math.abs(b.x) > halfA + 5 || Math.abs(b.z) > halfA + 5) {
        if (mesh) {
          this.scene.remove(mesh);
          this.bulletMeshes.delete(b.id);
        }
        this.bullets.splice(i, 1);
      }
    }

    // Update Zombies
    for (let i = this.zombies.length - 1; i >= 0; i--) {
      const z = this.zombies[i];
      z.walkCycle += dt * 8;

      if (z.type === 'boss') {
        if (!z.isCharging) {
          z.chargeCooldown = (z.chargeCooldown || 5) - dt;
          if (z.chargeCooldown <= 0) {
            z.isCharging = true;
            z.chargeTime = 1.3;
            z.speed = z.baseSpeed * 2.6;
            this.screenShake = 0.6;
            sounds.playBossAlarm();
          }
        } else {
          z.chargeTime = (z.chargeTime || 1.3) - dt;
          if (z.chargeTime <= 0) {
            z.isCharging = false;
            z.speed = z.baseSpeed;
            z.chargeCooldown = 4.5 + Math.random() * 2;
          }
        }
      }

      const dx = this.playerStats.x - z.x;
      const dz = this.playerStats.z - z.z;
      const distToPlayer = Math.hypot(dx, dz);
      z.angle = Math.atan2(dx, dz);

      let sepX = 0;
      let sepZ = 0;
      for (const other of this.zombies) {
        if (other.id !== z.id) {
          const odx = z.x - other.x;
          if (Math.abs(odx) > 1.8) continue;
          const odz = z.z - other.z;
          if (Math.abs(odz) > 1.8) continue;
          const odist = Math.hypot(odx, odz);
          const minSep = z.radius + other.radius + 0.3;
          if (odist < minSep && odist > 0.01) {
            sepX += (odx / odist) * (minSep - odist) * 0.4;
            sepZ += (odz / odist) * (minSep - odist) * 0.4;
          }
        }
      }

      let avoidX = 0;
      let avoidZ = 0;
      for (const ob of this.obstacles) {
        const odx = z.x - ob.x;
        if (Math.abs(odx) > ob.radius + 1.2) continue;
        const odz = z.z - ob.z;
        if (Math.abs(odz) > ob.radius + 1.2) continue;
        const odist = Math.hypot(odx, odz);
        if (odist < z.radius + ob.radius + 0.4) {
          avoidX += odx * 0.5;
          avoidZ += odz * 0.5;
        }
      }

      const normX = dx / (distToPlayer || 1);
      const normZ = dz / (distToPlayer || 1);

      z.vx = normX * z.speed + sepX + avoidX;
      z.vz = normZ * z.speed + sepZ + avoidZ;

      z.x += z.vx * dt;
      z.z += z.vz * dt;

      const zMesh = this.zombieMeshes.get(z.id);
      if (zMesh) {
        zMesh.position.set(z.x, 0, z.z);
        zMesh.rotation.y = z.angle;

        const leftArm = zMesh.getObjectByName('leftArm');
        const rightArm = zMesh.getObjectByName('rightArm');
        const zLeftLeg = zMesh.getObjectByName('leftLeg');
        const zRightLeg = zMesh.getObjectByName('rightLeg');

        const swing = Math.sin(z.walkCycle) * 0.35;
        if (leftArm) leftArm.rotation.x = Math.PI / 2.2 + swing;
        if (rightArm) rightArm.rotation.x = Math.PI / 2.2 - swing;
        if (zLeftLeg) zLeftLeg.rotation.x = -swing;
        if (zRightLeg) zRightLeg.rotation.x = swing;
      }

      const hitRadius = this.isDriving && this.currentCar ? this.currentCar.radius : this.playerStats.radius;
      if (distToPlayer < z.radius + hitRadius) {
        if (this.isDriving && this.currentCar) {
          // Zombie attacks the car armor with attack cooldown to prevent 60fps rapid damage/bucking
          if (!z.lastAttackTime || now - z.lastAttackTime > 800) {
            z.lastAttackTime = now;
            this.currentCar.health -= z.damage * 0.6;
            this.screenShake = Math.max(this.screenShake, 0.1);
            if (this.currentCar.health <= 0) {
              this.triggerRocketExplosion(this.currentCar.x, this.currentCar.z);
              this.exitCar();
              this.playerStats.health -= 15;
              if (this.playerStats.health <= 0) {
                this.handleGameOver();
                return;
              }
            }
          }
        } else if (!this.playerStats.isInvulnerable) {
          this.playerStats.health -= z.damage;
          this.playerStats.lastHurtTime = now;
          this.playerStats.isInvulnerable = true;
          this.screenShake = Math.max(this.screenShake, z.type === 'boss' ? 1.4 : 0.6);
          sounds.playPlayerHurt();

          const knockAngle = Math.atan2(this.playerStats.x - z.x, this.playerStats.z - z.z);
          this.playerStats.x += Math.sin(knockAngle) * (z.type === 'boss' ? 3.5 : 1.4);
          this.playerStats.z += Math.cos(knockAngle) * (z.type === 'boss' ? 3.5 : 1.4);

          if (this.playerStats.health <= 0) {
            this.playerStats.health = 0;
            this.handleGameOver();
            return;
          }
        }
      }
    }

    // Update Power-ups
    for (let i = this.powerUps.length - 1; i >= 0; i--) {
      const p = this.powerUps[i];
      const pMesh = this.powerUpMeshes.get(p.id);
      if (pMesh) {
        pMesh.rotation.y += dt * 2.5;
        pMesh.position.y = 0.6 + Math.sin(now * 0.005) * 0.15;
      }

      const dist = Math.hypot(this.playerStats.x - p.x, this.playerStats.z - p.z);
      if (dist < this.playerStats.radius + 1.2) {
        sounds.playPowerUp();
        if (p.type === 'health') {
          this.playerStats.health = Math.min(this.playerStats.maxHealth, this.playerStats.health + 30);
        } else if (p.type === 'shotgun_ammo') {
          this.playerStats.ammo.shotgun += 15;
        } else if (p.type === 'rifle_ammo') {
          this.playerStats.ammo.rifle += 60;
        } else if (p.type === 'plasma_ammo') {
          this.playerStats.ammo.plasma += 12;
        } else if (p.type === 'rpg_ammo') {
          this.playerStats.ammo.rpg += 4;
        } else if (p.type === 'nuke') {
          this.triggerNuke();
        }

        if (pMesh) {
          this.scene.remove(pMesh);
          this.powerUpMeshes.delete(p.id);
        }
        this.powerUps.splice(i, 1);
        continue;
      }

      if ((now - p.createdAt) / 1000 > p.duration) {
        if (pMesh) {
          this.scene.remove(pMesh);
          this.powerUpMeshes.delete(p.id);
        }
        this.powerUps.splice(i, 1);
      }
    }

    // Update 3D Particles
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const pt = this.particles[i];
      pt.mesh.position.x += pt.vx * dt;
      pt.mesh.position.y += pt.vy * dt;
      pt.mesh.position.z += pt.vz * dt;
      pt.vy -= 18 * dt;
      pt.life += dt;

      if (pt.mesh.position.y < 0.05) {
        pt.mesh.position.y = 0.05;
        pt.vx *= 0.5;
        pt.vz *= 0.5;
      }

      if (pt.life >= pt.maxLife) {
        this.scene.remove(pt.mesh);
        this.particles.splice(i, 1);
      }
    }

    // Throttle routine HUD updates to ~15fps (every 66ms) to eliminate React 60fps render churn
    if (now - this.lastHudSyncTime > 66) {
      this.lastHudSyncTime = now;
      this.syncHud();
    }
  }

  private updateCamera(dt: number) {
    const shakeOffsetX = (Math.random() - 0.5) * this.screenShake;
    const shakeOffsetZ = (Math.random() - 0.5) * this.screenShake;

    if (this.cameraMode === 'isometric') {
      const targetCamX = this.playerStats.x + shakeOffsetX;
      const targetCamY = 27;
      const targetCamZ = this.playerStats.z + 19 + shakeOffsetZ;

      this.camera.position.x = THREE.MathUtils.lerp(this.camera.position.x, targetCamX, 0.1);
      this.camera.position.y = THREE.MathUtils.lerp(this.camera.position.y, targetCamY, 0.1);
      this.camera.position.z = THREE.MathUtils.lerp(this.camera.position.z, targetCamZ, 0.1);

      this.camera.lookAt(this.playerStats.x, 0.5, this.playerStats.z);
    } else {
      const behindDist = 9.5;
      const targetCamX = this.playerStats.x - Math.sin(this.playerStats.angle) * behindDist + shakeOffsetX;
      const targetCamY = 6.8;
      const targetCamZ = this.playerStats.z - Math.cos(this.playerStats.angle) * behindDist + shakeOffsetZ;

      this.camera.position.x = THREE.MathUtils.lerp(this.camera.position.x, targetCamX, 0.12);
      this.camera.position.y = THREE.MathUtils.lerp(this.camera.position.y, targetCamY, 0.12);
      this.camera.position.z = THREE.MathUtils.lerp(this.camera.position.z, targetCamZ, 0.12);

      const lookAheadX = this.playerStats.x + Math.sin(this.playerStats.angle) * 8;
      const lookAheadZ = this.playerStats.z + Math.cos(this.playerStats.angle) * 8;
      this.cameraLookTarget.x = THREE.MathUtils.lerp(this.cameraLookTarget.x || lookAheadX, lookAheadX, 0.15);
      this.cameraLookTarget.y = THREE.MathUtils.lerp(this.cameraLookTarget.y || 1.2, 1.2, 0.15);
      this.cameraLookTarget.z = THREE.MathUtils.lerp(this.cameraLookTarget.z || lookAheadZ, lookAheadZ, 0.15);
      this.camera.lookAt(this.cameraLookTarget);
    }
  }
}
