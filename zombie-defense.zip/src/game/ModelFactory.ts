import * as THREE from 'three';
import { CarType, ObstacleType, PlayerClass, WeaponType, ZombieType } from './types';

/**
 * Procedural 3D model generator for characters, weapons, houses, vehicles, and environmental props.
 * Highly optimized, uses clean geometric composition and shared materials.
 */
export class ModelFactory {
  // Shared materials for performance
  public static redEyeMat = new THREE.MeshBasicMaterial({ color: 0xff2222 });
  public static greenToxicMat = new THREE.MeshBasicMaterial({ color: 0x22c55e });
  public static blueVisorMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
  public static amberVisorMat = new THREE.MeshBasicMaterial({ color: 0xf59e0b });
  public static greenVisorMat = new THREE.MeshBasicMaterial({ color: 0x10b981 });
  public static glassMat = new THREE.MeshStandardMaterial({
    color: 0x93c5fd,
    transparent: true,
    opacity: 0.45,
    roughness: 0.1,
    metalness: 0.8,
  });

  /**
   * Create the tactical player 3D model based on class & weapon.
   */
  public static createPlayerModel(playerClass: PlayerClass = 'commando', weaponType: WeaponType = 'pistol'): THREE.Group {
    const group = new THREE.Group();

    let bodyColor = 0x1e293b;
    let armorColor = 0x334155;
    let helmetColor = 0x0f172a;
    let visorMat = this.blueVisorMat;

    if (playerClass === 'ranger') {
      bodyColor = 0x574a38; // desert tan
      armorColor = 0x78674f;
      helmetColor = 0x3f3527;
      visorMat = this.greenVisorMat;
    } else if (playerClass === 'juggernaut') {
      bodyColor = 0x18181b; // heavy charcoal
      armorColor = 0x27272a;
      helmetColor = 0x111827;
      visorMat = this.amberVisorMat;
    }

    const playerMat = new THREE.MeshStandardMaterial({ color: bodyColor, roughness: 0.6, metalness: 0.2 });
    const armorMat = new THREE.MeshStandardMaterial({ color: armorColor, roughness: 0.5, metalness: 0.3 });
    const skinMat = new THREE.MeshStandardMaterial({ color: 0xe2b29f, roughness: 0.8 });
    const helmetMat = new THREE.MeshStandardMaterial({ color: helmetColor, roughness: 0.4, metalness: 0.4 });

    // Torso / Body
    const torsoGeo = new THREE.CylinderGeometry(0.42, 0.36, 0.9, 8);
    const torso = new THREE.Mesh(torsoGeo, armorMat);
    torso.position.y = 0.95;
    torso.castShadow = true;
    torso.receiveShadow = true;
    group.add(torso);

    // Tactical Vest Plates
    const vestGeo = new THREE.BoxGeometry(0.68, 0.55, 0.58);
    const vest = new THREE.Mesh(vestGeo, playerMat);
    vest.position.set(0, 0.98, 0);
    vest.castShadow = true;
    group.add(vest);

    // Head
    const headGeo = new THREE.SphereGeometry(0.28, 8, 8);
    const head = new THREE.Mesh(headGeo, skinMat);
    head.position.set(0, 1.62, 0);
    head.castShadow = true;
    group.add(head);

    // Helmet
    const helmetGeo = new THREE.SphereGeometry(0.32, 8, 8);
    const helmet = new THREE.Mesh(helmetGeo, helmetMat);
    helmet.position.set(0, 1.68, -0.02);
    helmet.scale.set(1.05, 0.95, 1.05);
    helmet.castShadow = true;
    group.add(helmet);

    // Visor / Goggles
    const visorGeo = new THREE.BoxGeometry(0.38, 0.12, 0.18);
    const visor = new THREE.Mesh(visorGeo, visorMat);
    visor.position.set(0, 1.66, 0.24);
    group.add(visor);

    // Tactical Backpack or Blast Shield
    if (playerClass === 'juggernaut') {
      // Heavy shield on back
      const shieldGeo = new THREE.BoxGeometry(0.8, 1.1, 0.12);
      const shieldMat = new THREE.MeshStandardMaterial({ color: 0x09090b, metalness: 0.8, roughness: 0.3 });
      const shield = new THREE.Mesh(shieldGeo, shieldMat);
      shield.position.set(0, 1.15, -0.38);
      shield.castShadow = true;
      group.add(shield);
    } else {
      const packGeo = new THREE.BoxGeometry(0.48, 0.6, 0.28);
      const pack = new THREE.Mesh(packGeo, helmetMat);
      pack.position.set(0, 1.05, -0.38);
      pack.castShadow = true;
      group.add(pack);

      // Radio Antenna
      const antGeo = new THREE.CylinderGeometry(0.015, 0.015, 0.6, 4);
      const antMat = new THREE.MeshStandardMaterial({ color: 0x64748b, metalness: 0.8 });
      const ant = new THREE.Mesh(antGeo, antMat);
      ant.position.set(0.18, 1.5, -0.42);
      group.add(ant);
    }

    // Legs
    const legGeo = new THREE.CylinderGeometry(0.14, 0.12, 0.75, 6);
    const leftLeg = new THREE.Mesh(legGeo, playerMat);
    leftLeg.name = 'leftLeg';
    leftLeg.position.set(-0.2, 0.4, 0);
    leftLeg.castShadow = true;
    group.add(leftLeg);

    const rightLeg = new THREE.Mesh(legGeo, playerMat);
    rightLeg.name = 'rightLeg';
    rightLeg.position.set(0.2, 0.4, 0);
    rightLeg.castShadow = true;
    group.add(rightLeg);

    // Arms & Weapon Pivot
    const weaponPivot = new THREE.Group();
    weaponPivot.name = 'weaponPivot';
    weaponPivot.position.set(0, 1.15, 0);

    const armGeo = new THREE.CylinderGeometry(0.1, 0.09, 0.6, 6);
    const rightArm = new THREE.Mesh(armGeo, armorMat);
    rightArm.name = 'rightArm';
    rightArm.position.set(0.38, -0.05, 0.22);
    rightArm.rotation.x = Math.PI / 2.4;
    rightArm.rotation.z = -0.2;
    rightArm.castShadow = true;
    weaponPivot.add(rightArm);

    const leftArm = new THREE.Mesh(armGeo, armorMat);
    leftArm.name = 'leftArm';
    leftArm.position.set(-0.28, -0.05, 0.26);
    leftArm.rotation.x = Math.PI / 2.2;
    leftArm.rotation.y = -0.35;
    leftArm.castShadow = true;
    weaponPivot.add(leftArm);

    // Mount 3D Gun Model
    const gunModel = this.createGunModel(weaponType);
    gunModel.name = 'gunModel';
    gunModel.position.set(0.18, -0.02, 0.45);
    weaponPivot.add(gunModel);

    // Laser Sight Beam
    const laserMat = new THREE.LineBasicMaterial({ color: 0xef4444, transparent: true, opacity: 0.65 });
    const laserGeo = new THREE.BufferGeometry().setFromPoints([
      new THREE.Vector3(0.18, -0.02, 0.8),
      new THREE.Vector3(0.18, -0.02, 14.0),
    ]);
    const laserLine = new THREE.Line(laserGeo, laserMat);
    laserLine.name = 'laserSight';
    weaponPivot.add(laserLine);

    group.add(weaponPivot);

    // Tactical Flashlight
    const flashlight = new THREE.SpotLight(0xfff8e7, 3.0, 42, Math.PI / 6, 0.45, 1.2);
    flashlight.position.set(0, 1.15, 0.5);
    flashlight.name = 'flashlight';
    flashlight.castShadow = true;
    flashlight.shadow.mapSize.width = 1024;
    flashlight.shadow.mapSize.height = 1024;
    flashlight.shadow.camera.near = 0.5;
    flashlight.shadow.camera.far = 40;

    const flashTarget = new THREE.Object3D();
    flashTarget.position.set(0, 0.8, 14);
    flashTarget.name = 'flashlightTarget';
    group.add(flashTarget);
    flashlight.target = flashTarget;
    group.add(flashlight);

    return group;
  }

  /**
   * Create realistic 3D Gun Models.
   */
  public static createGunModel(type: WeaponType): THREE.Group {
    const group = new THREE.Group();
    const gunDarkMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.3, metalness: 0.85 });
    const gunSteelMat = new THREE.MeshStandardMaterial({ color: 0x64748b, roughness: 0.2, metalness: 0.9 });
    const woodMat = new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.7 });

    if (type === 'pistol') {
      // 9mm Tactical Pistol
      const slideGeo = new THREE.BoxGeometry(0.1, 0.14, 0.45);
      const slide = new THREE.Mesh(slideGeo, gunDarkMat);
      slide.castShadow = true;
      group.add(slide);

      const barrelGeo = new THREE.CylinderGeometry(0.025, 0.025, 0.15, 6);
      barrelGeo.rotateX(Math.PI / 2);
      const barrel = new THREE.Mesh(barrelGeo, gunSteelMat);
      barrel.position.set(0, 0.02, 0.26);
      group.add(barrel);

      const gripGeo = new THREE.BoxGeometry(0.09, 0.22, 0.12);
      const grip = new THREE.Mesh(gripGeo, gunDarkMat);
      grip.position.set(0, -0.14, -0.1);
      grip.rotation.x = -0.25;
      group.add(grip);
    } else if (type === 'shotgun') {
      // Tactical Combat Pump-Action Shotgun
      const bodyGeo = new THREE.BoxGeometry(0.12, 0.18, 0.85);
      const body = new THREE.Mesh(bodyGeo, gunDarkMat);
      body.castShadow = true;
      group.add(body);

      // Dual Heavy Barrel
      const barrelGeo = new THREE.CylinderGeometry(0.04, 0.04, 0.65, 8);
      barrelGeo.rotateX(Math.PI / 2);
      const barrel = new THREE.Mesh(barrelGeo, gunSteelMat);
      barrel.position.set(0, 0.04, 0.65);
      group.add(barrel);

      // Underbarrel Magazine Tube
      const tubeGeo = new THREE.CylinderGeometry(0.035, 0.035, 0.55, 8);
      tubeGeo.rotateX(Math.PI / 2);
      const tube = new THREE.Mesh(tubeGeo, gunSteelMat);
      tube.position.set(0, -0.04, 0.6);
      group.add(tube);

      // Pump Grip (Fore-end)
      const pumpGeo = new THREE.BoxGeometry(0.15, 0.14, 0.28);
      const pump = new THREE.Mesh(pumpGeo, woodMat);
      pump.position.set(0, -0.03, 0.5);
      group.add(pump);

      // Stock
      const stockGeo = new THREE.BoxGeometry(0.1, 0.18, 0.4);
      const stock = new THREE.Mesh(stockGeo, woodMat);
      stock.position.set(0, -0.08, -0.55);
      group.add(stock);
    } else if (type === 'rifle') {
      // M4 / AR-15 Style Tactical Assault Rifle
      const receiverGeo = new THREE.BoxGeometry(0.12, 0.2, 0.7);
      const receiver = new THREE.Mesh(receiverGeo, gunDarkMat);
      receiver.castShadow = true;
      group.add(receiver);

      // Long Fluted Barrel with Flash Hider
      const barrelGeo = new THREE.CylinderGeometry(0.032, 0.032, 0.75, 8);
      barrelGeo.rotateX(Math.PI / 2);
      const barrel = new THREE.Mesh(barrelGeo, gunSteelMat);
      barrel.position.set(0, 0.03, 0.65);
      group.add(barrel);

      // Handguard Rail
      const railGeo = new THREE.BoxGeometry(0.14, 0.16, 0.45);
      const rail = new THREE.Mesh(railGeo, gunDarkMat);
      rail.position.set(0, 0.02, 0.48);
      group.add(rail);

      // Curved Extended Magazine
      const magGeo = new THREE.BoxGeometry(0.09, 0.32, 0.18);
      const mag = new THREE.Mesh(magGeo, gunSteelMat);
      mag.position.set(0, -0.2, 0.08);
      mag.rotation.x = -0.3;
      group.add(mag);

      // Holographic Sight (Glowing Amber Glass)
      const sightGeo = new THREE.BoxGeometry(0.12, 0.12, 0.22);
      const sight = new THREE.Mesh(sightGeo, gunDarkMat);
      sight.position.set(0, 0.16, -0.05);
      group.add(sight);

      const dotMat = new THREE.MeshBasicMaterial({ color: 0xef4444 });
      const dot = new THREE.Mesh(new THREE.SphereGeometry(0.02, 4, 4), dotMat);
      dot.position.set(0, 0.16, -0.05);
      group.add(dot);

      // Telescopic Stock
      const stockGeo = new THREE.BoxGeometry(0.1, 0.18, 0.42);
      const stock = new THREE.Mesh(stockGeo, gunDarkMat);
      stock.position.set(0, -0.05, -0.5);
      group.add(stock);
    } else if (type === 'plasma') {
      // Futuristic Plasma Railgun / Sniper
      const bodyGeo = new THREE.BoxGeometry(0.15, 0.22, 0.95);
      const plasmaBodyMat = new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.2, metalness: 0.9 });
      const body = new THREE.Mesh(bodyGeo, plasmaBodyMat);
      group.add(body);

      // Twin Long Energy Rails
      const railUpperGeo = new THREE.BoxGeometry(0.05, 0.05, 0.9);
      const railMat = new THREE.MeshStandardMaterial({ color: 0x38bdf8, metalness: 0.9, roughness: 0.1 });
      const railUp = new THREE.Mesh(railUpperGeo, railMat);
      railUp.position.set(0, 0.06, 0.7);
      group.add(railUp);

      const railDown = new THREE.Mesh(railUpperGeo, railMat);
      railDown.position.set(0, -0.06, 0.7);
      group.add(railDown);

      // Glowing Cyan Plasma Coils
      const coilMat = new THREE.MeshBasicMaterial({ color: 0x00f0ff });
      for (let i = 0; i < 4; i++) {
        const ringGeo = new THREE.TorusGeometry(0.09, 0.022, 6, 12);
        const ring = new THREE.Mesh(ringGeo, coilMat);
        ring.position.set(0, 0, 0.45 + i * 0.18);
        group.add(ring);
      }

      // High-Tech Optical Scope
      const scopeGeo = new THREE.CylinderGeometry(0.055, 0.055, 0.48, 8);
      scopeGeo.rotateX(Math.PI / 2);
      const scope = new THREE.Mesh(scopeGeo, plasmaBodyMat);
      scope.position.set(0, 0.19, -0.05);
      group.add(scope);
    } else if (type === 'rpg') {
      // Heavy Rocket-Propelled Grenade Launcher
      const tubeGeo = new THREE.CylinderGeometry(0.09, 0.09, 1.25, 12);
      tubeGeo.rotateX(Math.PI / 2);
      const tubeMat = new THREE.MeshStandardMaterial({ color: 0x2e3524, roughness: 0.6, metalness: 0.4 });
      const tube = new THREE.Mesh(tubeGeo, tubeMat);
      group.add(tube);

      // Exhaust Bell at Rear
      const bellGeo = new THREE.ConeGeometry(0.16, 0.25, 12);
      bellGeo.rotateX(-Math.PI / 2);
      const bell = new THREE.Mesh(bellGeo, tubeMat);
      bell.position.set(0, 0, -0.65);
      group.add(bell);

      // Conical Warhead protruding from muzzle
      const warheadGeo = new THREE.ConeGeometry(0.13, 0.35, 10);
      warheadGeo.rotateX(Math.PI / 2);
      const warheadMat = new THREE.MeshStandardMaterial({ color: 0xb91c1c, metalness: 0.6 });
      const warhead = new THREE.Mesh(warheadGeo, warheadMat);
      warhead.position.set(0, 0, 0.72);
      group.add(warhead);

      // Grip and Trigger
      const gripGeo = new THREE.BoxGeometry(0.08, 0.25, 0.12);
      const grip = new THREE.Mesh(gripGeo, gunDarkMat);
      grip.position.set(0, -0.18, 0.1);
      group.add(grip);
    }

    return group;
  }

  /**
   * Create detailed 3D Houses, Barns, and Cabins!
   */
  public static createHouseModel(variant: 'house' | 'barn' | 'cabin' = 'house'): THREE.Group {
    const group = new THREE.Group();

    if (variant === 'house') {
      // Suburban 2-Story House with Pitched Roof, Porch, Chimney, Windows & Door
      const wallMat = new THREE.MeshStandardMaterial({ color: 0xf1f5f9, roughness: 0.85 }); // clean white/cream siding
      const roofMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.7 }); // slate grey shingles
      const trimMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.5 }); // dark trim
      const doorMat = new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.7 }); // oak wood door
      const brickMat = new THREE.MeshStandardMaterial({ color: 0x881337, roughness: 0.9 }); // red brick chimney

      // Main House Structure (Width: 6.0, Height: 3.5, Depth: 5.5)
      const baseGeo = new THREE.BoxGeometry(6.0, 3.5, 5.5);
      const base = new THREE.Mesh(baseGeo, wallMat);
      base.position.y = 1.75;
      base.castShadow = true;
      base.receiveShadow = true;
      group.add(base);

      // Pitched Gable Roof (Triangular Prism)
      const roofLength = 6.4;
      const roofWidth = 6.0;
      const roofHeight = 2.0;

      const roofShape = new THREE.Shape();
      roofShape.moveTo(-roofWidth / 2, 0);
      roofShape.lineTo(0, roofHeight);
      roofShape.lineTo(roofWidth / 2, 0);
      roofShape.closePath();

      const extrudeSettings = { depth: roofLength, bevelEnabled: false };
      const roofGeo = new THREE.ExtrudeGeometry(roofShape, extrudeSettings);
      roofGeo.rotateY(Math.PI / 2);
      const roof = new THREE.Mesh(roofGeo, roofMat);
      roof.position.set(roofLength / 2, 3.5, 0);
      roof.castShadow = true;
      roof.receiveShadow = true;
      group.add(roof);

      // Red Brick Chimney
      const chimneyGeo = new THREE.BoxGeometry(0.7, 3.2, 0.7);
      const chimney = new THREE.Mesh(chimneyGeo, brickMat);
      chimney.position.set(2.0, 4.2, 1.2);
      chimney.castShadow = true;
      group.add(chimney);

      // Front Porch Platform
      const porchGeo = new THREE.BoxGeometry(3.2, 0.35, 1.6);
      const porch = new THREE.Mesh(porchGeo, trimMat);
      porch.position.set(0, 0.18, 3.4);
      porch.receiveShadow = true;
      group.add(porch);

      // Porch Awning Roof
      const awningGeo = new THREE.BoxGeometry(3.4, 0.25, 1.8);
      const awning = new THREE.Mesh(awningGeo, roofMat);
      awning.position.set(0, 2.5, 3.4);
      awning.castShadow = true;
      group.add(awning);

      // Porch Support Pillars
      const pillarGeo = new THREE.CylinderGeometry(0.08, 0.08, 2.2, 6);
      const pillarLeft = new THREE.Mesh(pillarGeo, wallMat);
      pillarLeft.position.set(-1.4, 1.35, 4.0);
      pillarLeft.castShadow = true;
      group.add(pillarLeft);

      const pillarRight = new THREE.Mesh(pillarGeo, wallMat);
      pillarRight.position.set(1.4, 1.35, 4.0);
      pillarRight.castShadow = true;
      group.add(pillarRight);

      // Front Door
      const doorGeo = new THREE.BoxGeometry(1.0, 2.0, 0.1);
      const door = new THREE.Mesh(doorGeo, doorMat);
      door.position.set(0, 1.35, 2.8);
      group.add(door);

      // Door Brass Knob
      const knobGeo = new THREE.SphereGeometry(0.05, 4, 4);
      const knobMat = new THREE.MeshBasicMaterial({ color: 0xf59e0b });
      const knob = new THREE.Mesh(knobGeo, knobMat);
      knob.position.set(0.35, 1.3, 2.88);
      group.add(knob);

      // Front Windows (Upper & Lower Floors)
      const windowPositions = [
        [-1.8, 1.5, 2.78],
        [1.8, 1.5, 2.78],
        [-1.8, 2.8, 2.78],
        [0, 2.8, 2.78],
        [1.8, 2.8, 2.78],
      ];

      const winFrameMat = new THREE.MeshStandardMaterial({ color: 0xffffff });
      windowPositions.forEach(([x, y, z]) => {
        // Window Frame
        const frameGeo = new THREE.BoxGeometry(0.9, 1.0, 0.08);
        const frame = new THREE.Mesh(frameGeo, winFrameMat);
        frame.position.set(x, y, z);
        group.add(frame);

        // Glass Pane
        const glassGeo = new THREE.BoxGeometry(0.75, 0.85, 0.1);
        const glass = new THREE.Mesh(glassGeo, this.glassMat);
        glass.position.set(x, y, z + 0.02);
        group.add(glass);
      });

      // Side Windows
      const sideWinGeo = new THREE.BoxGeometry(0.08, 1.0, 0.9);
      const leftWin = new THREE.Mesh(sideWinGeo, this.glassMat);
      leftWin.position.set(-3.02, 1.8, 0);
      group.add(leftWin);

      const rightWin = new THREE.Mesh(sideWinGeo, this.glassMat);
      rightWin.position.set(3.02, 1.8, 0);
      group.add(rightWin);

      return group;
    }

    if (variant === 'barn') {
      // Traditional Rural Red Farm Barn
      const barnMat = new THREE.MeshStandardMaterial({ color: 0x991b1b, roughness: 0.85 }); // rustic barn red
      const roofMat = new THREE.MeshStandardMaterial({ color: 0x475569, roughness: 0.6, metalness: 0.4 }); // galvanized metal
      const whiteTrimMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.6 });

      // Barn Body
      const bodyGeo = new THREE.BoxGeometry(7.0, 4.0, 6.0);
      const body = new THREE.Mesh(bodyGeo, barnMat);
      body.position.y = 2.0;
      body.castShadow = true;
      body.receiveShadow = true;
      group.add(body);

      // Gabled Roof
      const roofShape = new THREE.Shape();
      roofShape.moveTo(-3.7, 0);
      roofShape.lineTo(-1.8, 2.4);
      roofShape.lineTo(0, 2.7);
      roofShape.lineTo(1.8, 2.4);
      roofShape.lineTo(3.7, 0);
      roofShape.closePath();

      const roofGeo = new THREE.ExtrudeGeometry(roofShape, { depth: 7.2, bevelEnabled: false });
      roofGeo.rotateY(Math.PI / 2);
      const roof = new THREE.Mesh(roofGeo, roofMat);
      roof.position.set(3.6, 4.0, 0);
      roof.castShadow = true;
      group.add(roof);

      // Large White Cross-Braced Double Barn Doors
      const doorLeft = new THREE.Mesh(new THREE.BoxGeometry(1.6, 2.8, 0.12), whiteTrimMat);
      doorLeft.position.set(-0.85, 1.4, 3.05);
      group.add(doorLeft);

      const doorRight = new THREE.Mesh(new THREE.BoxGeometry(1.6, 2.8, 0.12), whiteTrimMat);
      doorRight.position.set(0.85, 1.4, 3.05);
      group.add(doorRight);

      // Upper Hay Loft Opening
      const loftDoor = new THREE.Mesh(new THREE.BoxGeometry(1.2, 1.4, 0.1), whiteTrimMat);
      loftDoor.position.set(0, 4.6, 3.52);
      group.add(loftDoor);

      return group;
    }

    // Rustic Wood Cabin / Military Barracks
    const logMat = new THREE.MeshStandardMaterial({ color: 0x543d2b, roughness: 0.9 });
    const cabinRoofMat = new THREE.MeshStandardMaterial({ color: 0x1e3a29, roughness: 0.8 }); // forest green shingles

    const cabinGeo = new THREE.BoxGeometry(5.2, 2.8, 4.5);
    const cabin = new THREE.Mesh(cabinGeo, logMat);
    cabin.position.y = 1.4;
    cabin.castShadow = true;
    cabin.receiveShadow = true;
    group.add(cabin);

    // Cabin Pitched Roof
    const roofShape = new THREE.Shape();
    roofShape.moveTo(-2.8, 0);
    roofShape.lineTo(0, 1.6);
    roofShape.lineTo(2.8, 0);
    roofShape.closePath();

    const cabinRoof = new THREE.Mesh(
      new THREE.ExtrudeGeometry(roofShape, { depth: 5.6, bevelEnabled: false }).rotateY(Math.PI / 2),
      cabinRoofMat
    );
    cabinRoof.position.set(2.8, 2.8, 0);
    cabinRoof.castShadow = true;
    group.add(cabinRoof);

    // Front Door
    const cDoor = new THREE.Mesh(
      new THREE.BoxGeometry(0.9, 1.9, 0.1),
      new THREE.MeshStandardMaterial({ color: 0x271911 })
    );
    cDoor.position.set(0, 1.0, 2.3);
    group.add(cDoor);

    return group;
  }

  /**
   * Create Wooden Rustic Farm Fence.
   */
  public static createFenceModel(): THREE.Group {
    const group = new THREE.Group();
    const woodMat = new THREE.MeshStandardMaterial({ color: 0x785338, roughness: 0.9 });

    // 2 Vertical Posts
    const postGeo = new THREE.CylinderGeometry(0.08, 0.08, 1.2, 6);
    const post1 = new THREE.Mesh(postGeo, woodMat);
    post1.position.set(-1.4, 0.6, 0);
    post1.castShadow = true;
    group.add(post1);

    const post2 = new THREE.Mesh(postGeo, woodMat);
    post2.position.set(1.4, 0.6, 0);
    post2.castShadow = true;
    group.add(post2);

    // 2 Horizontal Rails
    const railGeo = new THREE.BoxGeometry(2.9, 0.1, 0.08);
    const rail1 = new THREE.Mesh(railGeo, woodMat);
    rail1.position.set(0, 0.45, 0);
    rail1.castShadow = true;
    group.add(rail1);

    const rail2 = new THREE.Mesh(railGeo, woodMat);
    rail2.position.set(0, 0.9, 0);
    rail2.castShadow = true;
    group.add(rail2);

    return group;
  }

  /**
   * Create Soft 3D Puffy Cloud Model.
   */
  public static createCloudModel(): THREE.Group {
    const group = new THREE.Group();
    const cloudMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.95,
      metalness: 0.05,
      transparent: true,
      opacity: 0.88,
    });

    // Cluster of random soft spheres
    const parts = [
      { x: 0, y: 0, z: 0, r: 2.8 },
      { x: 2.2, y: -0.2, z: 0.4, r: 2.2 },
      { x: -2.2, y: -0.3, z: -0.2, r: 2.3 },
      { x: 1.0, y: 0.8, z: -0.5, r: 2.0 },
      { x: -1.2, y: 0.7, z: 0.5, r: 1.9 },
    ];

    parts.forEach((p) => {
      const geo = new THREE.DodecahedronGeometry(p.r, 2);
      const mesh = new THREE.Mesh(geo, cloudMat);
      mesh.position.set(p.x, p.y, p.z);
      group.add(mesh);
    });

    return group;
  }

  /**
   * Create Zombie 3D Models based on type.
   */
  public static createZombieModel(type: ZombieType): THREE.Group {
    const group = new THREE.Group();

    if (type === 'boss') {
      // COLOSSAL TANK BOSS ZOMBIE
      const bossSkinMat = new THREE.MeshStandardMaterial({ color: 0x4a1818, roughness: 0.85, metalness: 0.1 });
      const bossArmorMat = new THREE.MeshStandardMaterial({ color: 0x1c1917, roughness: 0.4, metalness: 0.7 });

      // Massive Torso
      const torsoGeo = new THREE.BoxGeometry(1.9, 2.2, 1.3);
      const torso = new THREE.Mesh(torsoGeo, bossSkinMat);
      torso.position.y = 2.1;
      torso.castShadow = true;
      group.add(torso);

      // Glowing Volcanic Core
      const coreGeo = new THREE.SphereGeometry(0.35, 8, 8);
      const coreMat = new THREE.MeshBasicMaterial({ color: 0xff3300 });
      const core = new THREE.Mesh(coreGeo, coreMat);
      core.position.set(0, 2.3, 0.65);
      group.add(core);

      // Massive Spiked Shoulders
      const shoulderGeo = new THREE.BoxGeometry(0.8, 0.8, 0.8);
      const leftShoulder = new THREE.Mesh(shoulderGeo, bossArmorMat);
      leftShoulder.position.set(-1.25, 2.8, 0);
      leftShoulder.castShadow = true;
      group.add(leftShoulder);

      const rightShoulder = new THREE.Mesh(shoulderGeo, bossArmorMat);
      rightShoulder.position.set(1.25, 2.8, 0);
      rightShoulder.castShadow = true;
      group.add(rightShoulder);

      // Shoulder Spikes
      const spikeGeo = new THREE.ConeGeometry(0.2, 0.65, 4);
      const spike1 = new THREE.Mesh(spikeGeo, bossArmorMat);
      spike1.position.set(-1.25, 3.4, 0);
      group.add(spike1);

      const spike2 = new THREE.Mesh(spikeGeo, bossArmorMat);
      spike2.position.set(1.25, 3.4, 0);
      group.add(spike2);

      // Heavy Arms & Giant Fists
      const armGeo = new THREE.CylinderGeometry(0.32, 0.4, 1.8, 8);
      const leftArm = new THREE.Mesh(armGeo, bossSkinMat);
      leftArm.position.set(-1.25, 1.6, 0.35);
      leftArm.rotation.x = Math.PI / 4;
      leftArm.name = 'leftArm';
      leftArm.castShadow = true;
      group.add(leftArm);

      const rightArm = new THREE.Mesh(armGeo, bossSkinMat);
      rightArm.position.set(1.25, 1.6, 0.35);
      rightArm.rotation.x = Math.PI / 4;
      rightArm.name = 'rightArm';
      rightArm.castShadow = true;
      group.add(rightArm);

      // Gauntlets
      const fistGeo = new THREE.BoxGeometry(0.65, 0.65, 0.7);
      const leftFist = new THREE.Mesh(fistGeo, bossArmorMat);
      leftFist.position.set(-1.25, 0.9, 0.85);
      leftFist.castShadow = true;
      group.add(leftFist);

      const rightFist = new THREE.Mesh(fistGeo, bossArmorMat);
      rightFist.position.set(1.25, 0.9, 0.85);
      rightFist.castShadow = true;
      group.add(rightFist);

      // Head
      const headGeo = new THREE.BoxGeometry(0.8, 0.8, 0.8);
      const head = new THREE.Mesh(headGeo, bossSkinMat);
      head.position.set(0, 3.25, 0.2);
      head.castShadow = true;
      group.add(head);

      // Glowing Red Eyes
      const eyeGeo = new THREE.SphereGeometry(0.12, 6, 6);
      const leftEye = new THREE.Mesh(eyeGeo, this.redEyeMat);
      leftEye.position.set(-0.22, 3.3, 0.62);
      group.add(leftEye);

      const rightEye = new THREE.Mesh(eyeGeo, this.redEyeMat);
      rightEye.position.set(0.22, 3.3, 0.62);
      group.add(rightEye);

      // Massive Legs
      const legGeo = new THREE.CylinderGeometry(0.38, 0.32, 1.2, 8);
      const leftLeg = new THREE.Mesh(legGeo, bossArmorMat);
      leftLeg.position.set(-0.65, 0.6, 0);
      leftLeg.castShadow = true;
      group.add(leftLeg);

      const rightLeg = new THREE.Mesh(legGeo, bossArmorMat);
      rightLeg.position.set(0.65, 0.6, 0);
      rightLeg.castShadow = true;
      group.add(rightLeg);

      return group;
    }

    // Regular Zombies (Walker, Runner, Toxic, Armored)
    let skinColor = 0x556b2f; // Walker greenish
    let shirtColor = 0x3f3f46;
    let pantsColor = 0x27272a;
    let scale = 1.0;

    if (type === 'runner') {
      skinColor = 0x8b2525; // Runner blood red
      shirtColor = 0x18181b;
      pantsColor = 0x09090b;
      scale = 0.92;
    } else if (type === 'toxic') {
      skinColor = 0x15803d; // Toxic green
      shirtColor = 0x14532d;
      pantsColor = 0x1c1917;
      scale = 1.05;
    } else if (type === 'armored') {
      skinColor = 0x475569;
      shirtColor = 0x1e293b;
      pantsColor = 0x0f172a;
      scale = 1.08;
    }

    const skinMat = new THREE.MeshStandardMaterial({ color: skinColor, roughness: 0.9 });
    const shirtMat = new THREE.MeshStandardMaterial({ color: shirtColor, roughness: 0.8 });
    const pantsMat = new THREE.MeshStandardMaterial({ color: pantsColor, roughness: 0.8 });

    // Torso
    const torsoGeo = new THREE.CylinderGeometry(0.35, 0.3, 0.8, 6);
    const torso = new THREE.Mesh(torsoGeo, shirtMat);
    torso.position.y = 0.95;
    torso.rotation.x = type === 'runner' ? 0.3 : 0.08;
    torso.castShadow = true;
    group.add(torso);

    // Head
    const headGeo = new THREE.SphereGeometry(0.24, 7, 7);
    const head = new THREE.Mesh(headGeo, skinMat);
    head.position.set(0, 1.5, type === 'runner' ? 0.18 : 0.05);
    head.castShadow = true;
    group.add(head);

    // Eyes
    const eyeGeo = new THREE.SphereGeometry(0.045, 4, 4);
    const eyeMat = type === 'toxic' ? this.greenToxicMat : this.redEyeMat;
    const leftEye = new THREE.Mesh(eyeGeo, eyeMat);
    leftEye.position.set(-0.09, 1.52, type === 'runner' ? 0.4 : 0.28);
    group.add(leftEye);

    const rightEye = new THREE.Mesh(eyeGeo, eyeMat);
    rightEye.position.set(0.09, 1.52, type === 'runner' ? 0.4 : 0.28);
    group.add(rightEye);

    // Armored Zombie Helmet & Armor Vest
    if (type === 'armored') {
      const helmetGeo = new THREE.BoxGeometry(0.55, 0.35, 0.55);
      const helmetMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.4, metalness: 0.7 });
      const helmet = new THREE.Mesh(helmetGeo, helmetMat);
      helmet.position.set(0, 1.58, 0.05);
      group.add(helmet);

      const vestGeo = new THREE.BoxGeometry(0.65, 0.6, 0.5);
      const vest = new THREE.Mesh(vestGeo, helmetMat);
      vest.position.set(0, 1.0, 0);
      group.add(vest);
    }

    // Toxic pustules on back
    if (type === 'toxic') {
      const cystGeo = new THREE.SphereGeometry(0.12, 5, 5);
      const cyst1 = new THREE.Mesh(cystGeo, this.greenToxicMat);
      cyst1.position.set(-0.18, 1.15, -0.22);
      group.add(cyst1);

      const cyst2 = new THREE.Mesh(cystGeo, this.greenToxicMat);
      cyst2.position.set(0.16, 1.25, -0.2);
      group.add(cyst2);
    }

    // Arms reaching forward
    const armGeo = new THREE.CylinderGeometry(0.08, 0.07, 0.65, 5);
    const leftArm = new THREE.Mesh(armGeo, skinMat);
    leftArm.name = 'leftArm';
    leftArm.position.set(-0.35, 1.1, 0.3);
    leftArm.rotation.x = Math.PI / 2.2;
    leftArm.rotation.z = -0.15;
    leftArm.castShadow = true;
    group.add(leftArm);

    const rightArm = new THREE.Mesh(armGeo, skinMat);
    rightArm.name = 'rightArm';
    rightArm.position.set(0.35, 1.1, 0.3);
    rightArm.rotation.x = Math.PI / 2.2;
    rightArm.rotation.z = 0.15;
    rightArm.castShadow = true;
    group.add(rightArm);

    // Legs
    const legGeo = new THREE.CylinderGeometry(0.12, 0.1, 0.65, 5);
    const leftLeg = new THREE.Mesh(legGeo, pantsMat);
    leftLeg.name = 'leftLeg';
    leftLeg.position.set(-0.16, 0.35, 0);
    leftLeg.castShadow = true;
    group.add(leftLeg);

    const rightLeg = new THREE.Mesh(legGeo, pantsMat);
    rightLeg.name = 'rightLeg';
    rightLeg.position.set(0.16, 0.35, 0);
    rightLeg.castShadow = true;
    group.add(rightLeg);

    group.scale.set(scale, scale, scale);
    return group;
  }

  /**
   * Create environmental props & obstacle 3D models.
   */
  public static createObstacleModel(type: string): THREE.Group {
    if (type === 'house') {
      return this.createHouseModel('house');
    }
    if (type === 'barn') {
      return this.createHouseModel('barn');
    }
    if (type === 'cabin') {
      return this.createHouseModel('cabin');
    }
    if (type === 'fence') {
      return this.createFenceModel();
    }
    if (type === 'skyscraper') {
      return this.createSkyscraperModel();
    }
    if (type === 'storefront') {
      return this.createStorefrontModel();
    }
    if (type === 'billboard') {
      return this.createBillboardModel();
    }
    if (type === 'traffic_light') {
      return this.createTrafficLightModel();
    }
    if (type === 'barrier') {
      return this.createBarrierModel();
    }

    const group = new THREE.Group();

    if (type === 'car') {
      // 3D Abandoned Sedan Car
      const carMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.4, metalness: 0.5 });
      const glassMat = new THREE.MeshStandardMaterial({ color: 0x09090b, roughness: 0.1, metalness: 0.9 });
      const wheelMat = new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.9 });

      const chassisGeo = new THREE.BoxGeometry(2.0, 0.5, 4.0);
      const chassis = new THREE.Mesh(chassisGeo, carMat);
      chassis.position.y = 0.5;
      chassis.castShadow = true;
      chassis.receiveShadow = true;
      group.add(chassis);

      const cabinGeo = new THREE.BoxGeometry(1.7, 0.6, 2.2);
      const cabin = new THREE.Mesh(cabinGeo, glassMat);
      cabin.position.set(0, 0.95, -0.2);
      cabin.castShadow = true;
      group.add(cabin);

      const wheelGeo = new THREE.CylinderGeometry(0.32, 0.32, 0.22, 10);
      wheelGeo.rotateZ(Math.PI / 2);

      const positions = [
        [-1.02, 0.32, 1.2],
        [1.02, 0.32, 1.2],
        [-1.02, 0.32, -1.2],
        [1.02, 0.32, -1.2],
      ];

      positions.forEach(([x, y, z]) => {
        const wheel = new THREE.Mesh(wheelGeo, wheelMat);
        wheel.position.set(x, y, z);
        wheel.castShadow = true;
        group.add(wheel);
      });

      return group;
    }

    if (type === 'container') {
      // 3D Shipping Container
      const colors = [0x991b1b, 0x0f766e, 0x1e3a8a, 0x854d0e];
      const color = colors[Math.floor(Math.random() * colors.length)];
      const contMat = new THREE.MeshStandardMaterial({ color, roughness: 0.7, metalness: 0.3 });

      const contGeo = new THREE.BoxGeometry(2.4, 2.2, 5.0);
      const cont = new THREE.Mesh(contGeo, contMat);
      cont.position.y = 1.1;
      cont.castShadow = true;
      cont.receiveShadow = true;
      group.add(cont);

      return group;
    }

    if (type === 'streetlight') {
      // Streetlight
      const poleMat = new THREE.MeshStandardMaterial({ color: 0x3f3f46, roughness: 0.5, metalness: 0.8 });
      const poleGeo = new THREE.CylinderGeometry(0.08, 0.1, 4.5, 8);
      const pole = new THREE.Mesh(poleGeo, poleMat);
      pole.position.y = 2.25;
      pole.castShadow = true;
      group.add(pole);

      const armGeo = new THREE.BoxGeometry(0.15, 0.15, 1.2);
      const arm = new THREE.Mesh(armGeo, poleMat);
      arm.position.set(0, 4.4, 0.45);
      group.add(arm);

      const lampHeadGeo = new THREE.BoxGeometry(0.3, 0.12, 0.45);
      const bulbMat = new THREE.MeshBasicMaterial({ color: 0xffedd5 });
      const lampHead = new THREE.Mesh(lampHeadGeo, bulbMat);
      lampHead.position.set(0, 4.3, 0.85);
      group.add(lampHead);

      const light = new THREE.PointLight(0xffecd2, 1.8, 14, 1.5);
      light.position.set(0, 4.1, 0.85);
      group.add(light);

      return group;
    }

    if (type === 'pod') {
      // Bio-Containment Pod
      const baseMat = new THREE.MeshStandardMaterial({ color: 0x18181b, metalness: 0.8 });
      const baseGeo = new THREE.CylinderGeometry(1.0, 1.1, 0.4, 12);
      const base = new THREE.Mesh(baseGeo, baseMat);
      base.position.y = 0.2;
      group.add(base);

      const top = new THREE.Mesh(baseGeo, baseMat);
      top.position.y = 2.8;
      group.add(top);

      const glassMat = new THREE.MeshStandardMaterial({
        color: 0x22c55e,
        transparent: true,
        opacity: 0.35,
        roughness: 0.1,
      });
      const glassGeo = new THREE.CylinderGeometry(0.9, 0.9, 2.4, 12);
      const glass = new THREE.Mesh(glassGeo, glassMat);
      glass.position.y = 1.5;
      group.add(glass);

      const coreMat = new THREE.MeshBasicMaterial({ color: 0x4ade80 });
      const coreGeo = new THREE.CylinderGeometry(0.4, 0.4, 2.0, 8);
      const core = new THREE.Mesh(coreGeo, coreMat);
      core.position.y = 1.5;
      group.add(core);

      const pointLight = new THREE.PointLight(0x22c55e, 2.0, 8);
      pointLight.position.set(0, 1.5, 0);
      group.add(pointLight);

      return group;
    }

    if (type === 'sandbag') {
      // Sandbag Bunker
      const sandMat = new THREE.MeshStandardMaterial({ color: 0xa88a64, roughness: 0.95 });
      const bagGeo = new THREE.BoxGeometry(0.8, 0.3, 0.45);

      for (let y = 0; y < 3; y++) {
        for (let x = -2; x <= 2; x++) {
          const bag = new THREE.Mesh(bagGeo, sandMat);
          const offset = y % 2 === 1 ? 0.35 : 0;
          bag.position.set(x * 0.75 + offset, y * 0.28 + 0.15, (Math.random() - 0.5) * 0.08);
          bag.castShadow = true;
          bag.receiveShadow = true;
          group.add(bag);
        }
      }
      return group;
    }

    if (type === 'tree') {
      // Pine / Oak Tree
      const trunkMat = new THREE.MeshStandardMaterial({ color: 0x3d2817, roughness: 0.9 });
      const trunkGeo = new THREE.CylinderGeometry(0.25, 0.35, 1.8, 6);
      const trunk = new THREE.Mesh(trunkGeo, trunkMat);
      trunk.position.y = 0.9;
      trunk.castShadow = true;
      group.add(trunk);

      const foliageMat = new THREE.MeshStandardMaterial({ color: 0x166534, roughness: 0.8 }); // lush forest green
      for (let i = 0; i < 3; i++) {
        const coneGeo = new THREE.ConeGeometry(1.7 - i * 0.35, 1.6, 7);
        const cone = new THREE.Mesh(coneGeo, foliageMat);
        cone.position.y = 2.0 + i * 0.95;
        cone.castShadow = true;
        group.add(cone);
      }
      return group;
    }

    // Default Wooden Crate
    const crateMat = new THREE.MeshStandardMaterial({ color: 0x785338, roughness: 0.85 });
    const crateGeo = new THREE.BoxGeometry(1.4, 1.4, 1.4);
    const crate = new THREE.Mesh(crateGeo, crateMat);
    crate.position.y = 0.7;
    crate.castShadow = true;
    crate.receiveShadow = true;
    group.add(crate);

    return group;
  }

  /**
   * Create rotating 3D power-up pickups with glowing indicators.
   */
  public static createPowerUpModel(type: string): THREE.Group {
    const group = new THREE.Group();

    let boxColor = 0x10b981;
    let label = '+HP';

    if (type === 'shotgun_ammo') {
      boxColor = 0xf59e0b;
      label = 'SG';
    } else if (type === 'rifle_ammo') {
      boxColor = 0x3b82f6;
      label = 'AR';
    } else if (type === 'plasma_ammo') {
      boxColor = 0x06b6d4;
      label = 'PL';
    } else if (type === 'rpg_ammo') {
      boxColor = 0x8b5cf6;
      label = 'RPG';
    } else if (type === 'nuke') {
      boxColor = 0xef4444;
      label = 'NUKE';
    }

    const boxMat = new THREE.MeshStandardMaterial({ color: boxColor, roughness: 0.3, metalness: 0.6 });
    const boxGeo = new THREE.BoxGeometry(0.7, 0.5, 0.5);
    const box = new THREE.Mesh(boxGeo, boxMat);
    box.castShadow = true;
    group.add(box);

    const crossMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const crossH = new THREE.BoxGeometry(0.4, 0.12, 0.52);
    const crossV = new THREE.BoxGeometry(0.12, 0.35, 0.52);
    group.add(new THREE.Mesh(crossH, crossMat));
    group.add(new THREE.Mesh(crossV, crossMat));

    const pLight = new THREE.PointLight(boxColor, 1.8, 4);
    pLight.position.set(0, 0, 0);
    group.add(pLight);

    return group;
  }

  /**
   * Create Metropolis Skyscraper Model with glowing office windows and rooftop antenna.
   */
  public static createSkyscraperModel(): THREE.Group {
    const group = new THREE.Group();
    const h = 18 + Math.floor(Math.random() * 8); // 18 to 25 units tall
    const w = 6.4;
    const d = 6.4;

    const facadeColors = [0x0f172a, 0x1e293b, 0x18181b, 0x172554];
    const facadeColor = facadeColors[Math.floor(Math.random() * facadeColors.length)];
    const facadeMat = new THREE.MeshStandardMaterial({ color: facadeColor, roughness: 0.6, metalness: 0.4 });
    const trimMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.4, metalness: 0.6 });

    // Main tower shaft
    const towerGeo = new THREE.BoxGeometry(w, h, d);
    const tower = new THREE.Mesh(towerGeo, facadeMat);
    tower.position.y = h / 2;
    tower.castShadow = true;
    tower.receiveShadow = true;
    group.add(tower);

    // Architectural cornice bands every 4 floors
    const floors = Math.floor(h / 3);
    for (let f = 1; f < floors; f++) {
      const cornice = new THREE.Mesh(new THREE.BoxGeometry(w + 0.25, 0.35, d + 0.25), trimMat);
      cornice.position.y = f * 3;
      cornice.castShadow = true;
      group.add(cornice);
    }

    // Windows Grid (Emissive windows with glowing lights)
    const winGeo = new THREE.BoxGeometry(0.7, 0.9, 0.1);
    const litMat1 = new THREE.MeshBasicMaterial({ color: 0x67e8f9 }); // glowing cyan
    const litMat2 = new THREE.MeshBasicMaterial({ color: 0xfef08a }); // warm yellow
    const darkWinMat = new THREE.MeshStandardMaterial({ color: 0x09090b, roughness: 0.1, metalness: 0.9 });

    for (let y = 2.0; y < h - 2.5; y += 1.8) {
      for (let x = -2.2; x <= 2.2; x += 1.45) {
        // Front and back windows
        const rand = Math.random();
        const mat = rand < 0.35 ? litMat1 : rand < 0.7 ? litMat2 : darkWinMat;

        const wFront = new THREE.Mesh(winGeo, mat);
        wFront.position.set(x, y, d / 2 + 0.05);
        group.add(wFront);

        const wBack = new THREE.Mesh(winGeo, mat);
        wBack.position.set(x, y, -d / 2 - 0.05);
        group.add(wBack);

        // Side windows
        const wSideGeo = new THREE.BoxGeometry(0.1, 0.9, 0.7);
        const wLeft = new THREE.Mesh(wSideGeo, mat);
        wLeft.position.set(-w / 2 - 0.05, y, x);
        group.add(wLeft);

        const wRight = new THREE.Mesh(wSideGeo, mat);
        wRight.position.set(w / 2 + 0.05, y, x);
        group.add(wRight);
      }
    }

    // Rooftop Parapet
    const parapet = new THREE.Mesh(new THREE.BoxGeometry(w + 0.1, 0.8, d + 0.1), trimMat);
    parapet.position.y = h + 0.4;
    group.add(parapet);

    // HVAC Units on Roof
    const hvac = new THREE.Mesh(
      new THREE.BoxGeometry(2.0, 1.2, 1.8),
      new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.7 })
    );
    hvac.position.set(1.4, h + 0.6, 1.2);
    hvac.castShadow = true;
    group.add(hvac);

    // Communications Antenna Spire with flashing red beacon
    const spireGeo = new THREE.CylinderGeometry(0.04, 0.12, 4.5, 6);
    const spire = new THREE.Mesh(spireGeo, trimMat);
    spire.position.set(-1.4, h + 2.25, -1.4);
    group.add(spire);

    const beacon = new THREE.Mesh(new THREE.SphereGeometry(0.18, 6, 6), new THREE.MeshBasicMaterial({ color: 0xff2222 }));
    beacon.position.set(-1.4, h + 4.5, -1.4);
    group.add(beacon);

    const beaconLight = new THREE.PointLight(0xff2222, 1.5, 12);
    beaconLight.position.set(-1.4, h + 4.5, -1.4);
    group.add(beaconLight);

    return group;
  }

  /**
   * Create City Retail Storefront with display window, awning, and illuminated neon signage.
   */
  public static createStorefrontModel(): THREE.Group {
    const group = new THREE.Group();
    const w = 5.6;
    const d = 5.0;
    const h = 3.8;

    const brickMat = new THREE.MeshStandardMaterial({ color: 0x3b2820, roughness: 0.85 });
    const trimMat = new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.5 });
    const frameMat = new THREE.MeshStandardMaterial({ color: 0x27272a, roughness: 0.4, metalness: 0.7 });

    // Main Store Building
    const building = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), brickMat);
    building.position.y = h / 2;
    building.castShadow = true;
    building.receiveShadow = true;
    group.add(building);

    // Large Front Display Windows
    const winLeft = new THREE.Mesh(new THREE.BoxGeometry(1.9, 2.0, 0.1), this.glassMat);
    winLeft.position.set(-1.4, 1.3, d / 2 + 0.05);
    group.add(winLeft);

    const winRight = new THREE.Mesh(new THREE.BoxGeometry(1.9, 2.0, 0.1), this.glassMat);
    winRight.position.set(1.4, 1.3, d / 2 + 0.05);
    group.add(winRight);

    // Store Entrance Double Door
    const door = new THREE.Mesh(
      new THREE.BoxGeometry(1.1, 2.2, 0.12),
      new THREE.MeshStandardMaterial({ color: 0x09090b, roughness: 0.3 })
    );
    door.position.set(0, 1.1, d / 2 + 0.05);
    group.add(door);

    // Commercial Striped Fabric Awning
    const awningGeo = new THREE.BoxGeometry(w + 0.2, 0.3, 1.6);
    awningGeo.rotateX(0.25);
    const awningMat = new THREE.MeshStandardMaterial({ color: 0xb91c1c, roughness: 0.7 }); // crimson retail awning
    const awning = new THREE.Mesh(awningGeo, awningMat);
    awning.position.set(0, 2.7, d / 2 + 0.8);
    awning.castShadow = true;
    group.add(awning);

    // Neon Shop Signboard
    const signBoard = new THREE.Mesh(
      new THREE.BoxGeometry(3.6, 0.8, 0.2),
      new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.5 })
    );
    signBoard.position.set(0, 3.3, d / 2 + 0.15);
    group.add(signBoard);

    // Glowing Neon Lettering Bar
    const neonColors = [0x38bdf8, 0xf43f5e, 0x10b981, 0xf59e0b];
    const nColor = neonColors[Math.floor(Math.random() * neonColors.length)];
    const neonSign = new THREE.Mesh(
      new THREE.BoxGeometry(3.2, 0.45, 0.25),
      new THREE.MeshBasicMaterial({ color: nColor })
    );
    neonSign.position.set(0, 3.3, d / 2 + 0.2);
    group.add(neonSign);

    const signLight = new THREE.PointLight(nColor, 1.6, 8);
    signLight.position.set(0, 3.3, d / 2 + 0.7);
    group.add(signLight);

    return group;
  }

  /**
   * Create Elevated Highway Advertising Billboard.
   */
  public static createBillboardModel(): THREE.Group {
    const group = new THREE.Group();
    const steelMat = new THREE.MeshStandardMaterial({ color: 0x3f3f46, roughness: 0.5, metalness: 0.8 });

    // Dual Steel Support Pillars
    const pillarGeo = new THREE.CylinderGeometry(0.16, 0.16, 5.5, 8);
    const p1 = new THREE.Mesh(pillarGeo, steelMat);
    p1.position.set(-1.8, 2.75, 0);
    p1.castShadow = true;
    group.add(p1);

    const p2 = new THREE.Mesh(pillarGeo, steelMat);
    p2.position.set(1.8, 2.75, 0);
    p2.castShadow = true;
    group.add(p2);

    // Cross brace
    const braceGeo = new THREE.BoxGeometry(3.8, 0.1, 0.1);
    const brace = new THREE.Mesh(braceGeo, steelMat);
    brace.position.set(0, 3.5, 0);
    group.add(brace);

    // Large Billboard Display Frame
    const board = new THREE.Mesh(new THREE.BoxGeometry(5.2, 2.6, 0.35), steelMat);
    board.position.set(0, 6.2, 0);
    board.castShadow = true;
    group.add(board);

    // Glowing Neon Advert Screen
    const neonMat = new THREE.MeshBasicMaterial({ color: 0xec4899 });
    const screen = new THREE.Mesh(new THREE.BoxGeometry(4.8, 2.2, 0.38), neonMat);
    screen.position.set(0, 6.2, 0);
    group.add(screen);

    const bLight = new THREE.PointLight(0xec4899, 2.2, 12);
    bLight.position.set(0, 6.2, 1.2);
    group.add(bLight);

    return group;
  }

  /**
   * Create Overhead City Traffic Light Pole.
   */
  public static createTrafficLightModel(): THREE.Group {
    const group = new THREE.Group();
    const steelMat = new THREE.MeshStandardMaterial({ color: 0x27272a, roughness: 0.5, metalness: 0.7 });

    // Vertical Post
    const post = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.14, 5.0, 8), steelMat);
    post.position.y = 2.5;
    post.castShadow = true;
    group.add(post);

    // Horizontal Mast Arm extending over road
    const arm = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 3.4, 8), steelMat);
    arm.rotation.z = Math.PI / 2;
    arm.position.set(1.7, 4.8, 0);
    arm.castShadow = true;
    group.add(arm);

    // Signal Heads (One overhead, one on pole)
    const createSignalHead = (x: number, y: number) => {
      const headBox = new THREE.Mesh(new THREE.BoxGeometry(0.35, 1.0, 0.3), steelMat);
      headBox.position.set(x, y, 0);
      headBox.castShadow = true;
      group.add(headBox);

      // Red, Yellow, Green lamps
      const redLamp = new THREE.Mesh(new THREE.SphereGeometry(0.1, 8, 8), new THREE.MeshBasicMaterial({ color: 0xef4444 }));
      redLamp.position.set(x, y + 0.3, 0.16);
      group.add(redLamp);

      const yellowLamp = new THREE.Mesh(new THREE.SphereGeometry(0.1, 8, 8), new THREE.MeshBasicMaterial({ color: 0x713f12 }));
      yellowLamp.position.set(x, y, 0.16);
      group.add(yellowLamp);

      const greenLamp = new THREE.Mesh(new THREE.SphereGeometry(0.1, 8, 8), new THREE.MeshBasicMaterial({ color: 0x15803d }));
      greenLamp.position.set(x, y - 0.3, 0.16);
      group.add(greenLamp);

      const rLight = new THREE.PointLight(0xef4444, 1.2, 5);
      rLight.position.set(x, y + 0.3, 0.35);
      group.add(rLight);
    };

    createSignalHead(2.8, 4.3);
    createSignalHead(0, 3.2);

    return group;
  }

  /**
   * Create Concrete Jersey Highway Barrier with hazard warning stripes.
   */
  public static createBarrierModel(): THREE.Group {
    const group = new THREE.Group();
    const concreteMat = new THREE.MeshStandardMaterial({ color: 0x71717a, roughness: 0.9 });
    const hazardMat = new THREE.MeshStandardMaterial({ color: 0xeab308, roughness: 0.6 });
    const blackMat = new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.8 });

    // Sloped Jersey Barrier Profile
    const barrier = new THREE.Mesh(new THREE.BoxGeometry(3.2, 0.9, 0.7), concreteMat);
    barrier.position.y = 0.45;
    barrier.castShadow = true;
    barrier.receiveShadow = true;
    group.add(barrier);

    // Diagonal hazard warning stripes
    for (let i = -1.2; i <= 1.2; i += 0.6) {
      const stripe = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.7, 0.72), (Math.abs(i) % 1.2 < 0.1) ? hazardMat : blackMat);
      stripe.position.set(i, 0.45, 0);
      group.add(stripe);
    }

    return group;
  }

  /**
   * Create Drivable Vehicle 3D Model with functional dual headlights and detailed chassis.
   */
  public static createDrivableCarModel(type: CarType, isDriven = false): THREE.Group {
    const group = new THREE.Group();

    let bodyColor = 0x2563eb; // Royal blue sedan
    let isPolice = false;
    let isMuscle = false;
    let isSUV = false;
    let isCyber = false;

    if (type === 'police') {
      bodyColor = 0x111827; // Squad car black
      isPolice = true;
    } else if (type === 'suv') {
      bodyColor = 0x365314; // Tactical army olive / tan
      isSUV = true;
    } else if (type === 'muscle') {
      bodyColor = 0xb91c1c; // Crimson Red Muscle
      isMuscle = true;
    } else if (type === 'cyber') {
      bodyColor = 0x06b6d4; // Cyber Neon Cyan
      isCyber = true;
    }

    const bodyMat = new THREE.MeshStandardMaterial({
      color: bodyColor,
      roughness: isCyber ? 0.2 : 0.35,
      metalness: isCyber ? 0.85 : 0.65,
    });
    const darkChassisMat = new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.6, metalness: 0.8 });
    const wheelMat = new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.9 });
    const rimMat = new THREE.MeshStandardMaterial({ color: 0xd4d4d8, roughness: 0.2, metalness: 0.9 });
    const grillMat = new THREE.MeshStandardMaterial({ color: 0x09090b, roughness: 0.4, metalness: 0.8 });

    // Chassis dimensions
    const cWidth = isSUV ? 2.4 : isCyber ? 2.25 : 2.1;
    const cLength = isSUV ? 4.8 : isCyber ? 4.7 : isMuscle ? 4.6 : 4.4;
    const cHeight = isSUV ? 0.75 : isCyber ? 0.48 : 0.55;
    const cabinHeight = isSUV ? 0.85 : isCyber ? 0.52 : 0.65;
    const rideHeight = isSUV ? 0.55 : isCyber ? 0.36 : 0.42;

    // Lower Chassis Body
    const chassis = new THREE.Mesh(new THREE.BoxGeometry(cWidth, cHeight, cLength), bodyMat);
    chassis.position.y = rideHeight + cHeight / 2;
    chassis.castShadow = true;
    chassis.receiveShadow = true;
    group.add(chassis);

    // Front Bumper / Grill
    const bumper = new THREE.Mesh(new THREE.BoxGeometry(cWidth + 0.08, 0.35, 0.4), darkChassisMat);
    bumper.position.set(0, rideHeight + 0.18, cLength / 2 + 0.1);
    bumper.castShadow = true;
    group.add(bumper);

    const grille = new THREE.Mesh(new THREE.BoxGeometry(cWidth * 0.7, 0.25, 0.1), grillMat);
    grille.position.set(0, rideHeight + 0.32, cLength / 2 + 0.25);
    group.add(grille);

    // Cabin / Roof & Tinted Glass
    const cabinWidth = cWidth * 0.88;
    const cabinLength = isSUV ? cLength * 0.65 : cLength * 0.52;
    const cabinZ = isSUV ? 0.1 : -0.2;
    const cabin = new THREE.Mesh(new THREE.BoxGeometry(cabinWidth, cabinHeight, cabinLength), this.glassMat);
    cabin.position.set(0, rideHeight + cHeight + cabinHeight / 2 - 0.05, cabinZ);
    cabin.castShadow = true;
    group.add(cabin);

    // Solid Roof panel
    const roof = new THREE.Mesh(new THREE.BoxGeometry(cabinWidth + 0.04, 0.08, cabinLength + 0.04), bodyMat);
    roof.position.set(0, rideHeight + cHeight + cabinHeight - 0.02, cabinZ);
    roof.castShadow = true;
    group.add(roof);

    // Police Squad Car Livery & Roof Lightbar
    if (isPolice) {
      // White door panels
      const whiteDoorMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.35 });
      const leftDoor = new THREE.Mesh(new THREE.BoxGeometry(0.08, cHeight * 0.85, cLength * 0.45), whiteDoorMat);
      leftDoor.position.set(-cWidth / 2 - 0.02, rideHeight + cHeight / 2, 0);
      group.add(leftDoor);

      const rightDoor = new THREE.Mesh(new THREE.BoxGeometry(0.08, cHeight * 0.85, cLength * 0.45), whiteDoorMat);
      rightDoor.position.set(cWidth / 2 + 0.02, rideHeight + cHeight / 2, 0);
      group.add(rightDoor);

      // Heavy Front Push Bumper / Bull Bar
      const bullBar = new THREE.Mesh(
        new THREE.BoxGeometry(cWidth * 0.8, 0.65, 0.2),
        new THREE.MeshStandardMaterial({ color: 0x09090b, metalness: 0.8, roughness: 0.3 })
      );
      bullBar.position.set(0, rideHeight + 0.35, cLength / 2 + 0.35);
      bullBar.castShadow = true;
      group.add(bullBar);

      // Tactical Emergency Strobe Lightbar on Roof
      const lightbarBase = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.12, 0.3), darkChassisMat);
      lightbarBase.position.set(0, rideHeight + cHeight + cabinHeight + 0.06, cabinZ);
      group.add(lightbarBase);

      const blueStrobe = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.16, 0.25), new THREE.MeshBasicMaterial({ color: 0x0066ff }));
      blueStrobe.position.set(-0.35, rideHeight + cHeight + cabinHeight + 0.14, cabinZ);
      blueStrobe.name = 'blueStrobe';
      group.add(blueStrobe);

      const redStrobe = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.16, 0.25), new THREE.MeshBasicMaterial({ color: 0xff0033 }));
      redStrobe.position.set(0.35, rideHeight + cHeight + cabinHeight + 0.14, cabinZ);
      redStrobe.name = 'redStrobe';
      group.add(redStrobe);

      const strobeLight = new THREE.PointLight(0x0066ff, isDriven ? 2.5 : 0.8, 14);
      strobeLight.position.set(0, rideHeight + cHeight + cabinHeight + 0.3, cabinZ);
      strobeLight.name = 'strobeLight';
      group.add(strobeLight);
    }

    // SUV Roof Rack & Spare Tire
    if (isSUV) {
      const rackMat = new THREE.MeshStandardMaterial({ color: 0x18181b, metalness: 0.8 });
      const rack = new THREE.Mesh(new THREE.BoxGeometry(cabinWidth * 0.9, 0.15, cabinLength * 0.85), rackMat);
      rack.position.set(0, rideHeight + cHeight + cabinHeight + 0.1, cabinZ);
      group.add(rack);

      // Spare Tire on Rear Door
      const spareGeo = new THREE.CylinderGeometry(0.38, 0.38, 0.25, 12);
      spareGeo.rotateZ(Math.PI / 2);
      const spareTire = new THREE.Mesh(spareGeo, wheelMat);
      spareTire.position.set(0, rideHeight + 0.65, -cLength / 2 - 0.14);
      spareTire.castShadow = true;
      group.add(spareTire);
    }

    // Muscle Car Hood Scoop & Rear Spoiler
    if (isMuscle) {
      // Dual White Racing Stripes
      const stripeMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.3 });
      const stripe1 = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.04, cLength * 0.98), stripeMat);
      stripe1.position.set(-0.25, rideHeight + cHeight + 0.02, 0);
      group.add(stripe1);

      const stripe2 = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.04, cLength * 0.98), stripeMat);
      stripe2.position.set(0.25, rideHeight + cHeight + 0.02, 0);
      group.add(stripe2);

      // Hood Scoop
      const scoop = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.16, 0.9), darkChassisMat);
      scoop.position.set(0, rideHeight + cHeight + 0.08, 1.1);
      group.add(scoop);

      // Rear Spoiler Wing
      const wing = new THREE.Mesh(new THREE.BoxGeometry(cWidth * 0.95, 0.08, 0.35), bodyMat);
      wing.position.set(0, rideHeight + cHeight + 0.32, -cLength / 2 + 0.2);
      wing.castShadow = true;
      group.add(wing);

      const wingStalkL = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.32, 0.1), darkChassisMat);
      wingStalkL.position.set(-0.65, rideHeight + cHeight + 0.16, -cLength / 2 + 0.2);
      group.add(wingStalkL);

      const wingStalkR = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.32, 0.1), darkChassisMat);
      wingStalkR.position.set(0.65, rideHeight + cHeight + 0.16, -cLength / 2 + 0.2);
      group.add(wingStalkR);
    }

    // Cyber Supercar Aero Diffuser & Neon Underglow
    if (isCyber) {
      const neonCyanMat = new THREE.MeshBasicMaterial({ color: 0x22d3ee });
      const neonMagentaMat = new THREE.MeshBasicMaterial({ color: 0xf43f5e });

      // Neon Underglow Strips
      const underglowL = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.04, cLength * 0.75), neonCyanMat);
      underglowL.position.set(-cWidth / 2 + 0.1, 0.08, 0);
      group.add(underglowL);

      const underglowR = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.04, cLength * 0.75), neonCyanMat);
      underglowR.position.set(cWidth / 2 - 0.1, 0.08, 0);
      group.add(underglowR);

      const underLight = new THREE.PointLight(0x06b6d4, isDriven ? 2.5 : 1.2, 9);
      underLight.position.set(0, 0.2, 0);
      group.add(underLight);

      // Carbon Fiber Rear Wing Spoiler
      const wingMat = new THREE.MeshStandardMaterial({ color: 0x09090b, roughness: 0.2, metalness: 0.9 });
      const cyberWing = new THREE.Mesh(new THREE.BoxGeometry(cWidth * 0.98, 0.06, 0.45), wingMat);
      cyberWing.position.set(0, rideHeight + cHeight + 0.38, -cLength / 2 + 0.1);
      cyberWing.castShadow = true;
      group.add(cyberWing);

      const cyberWingStrip = new THREE.Mesh(new THREE.BoxGeometry(cWidth * 0.94, 0.02, 0.04), neonMagentaMat);
      cyberWingStrip.position.set(0, rideHeight + cHeight + 0.41, -cLength / 2 - 0.12);
      group.add(cyberWingStrip);

      const stalkL = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.36, 0.15), wingMat);
      stalkL.position.set(-0.7, rideHeight + cHeight + 0.18, -cLength / 2 + 0.1);
      group.add(stalkL);

      const stalkR = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.36, 0.15), wingMat);
      stalkR.position.set(0.7, rideHeight + cHeight + 0.18, -cLength / 2 + 0.1);
      group.add(stalkR);
    }

    // 4 Heavy Rubber Wheels with Silver Rims
    const wRadius = isSUV ? 0.44 : 0.34;
    const wWidth = isSUV ? 0.34 : 0.26;
    const wheelGeo = new THREE.CylinderGeometry(wRadius, wRadius, wWidth, 12);
    wheelGeo.rotateZ(Math.PI / 2);

    const rimGeo = new THREE.CylinderGeometry(wRadius * 0.65, wRadius * 0.65, wWidth + 0.02, 10);
    rimGeo.rotateZ(Math.PI / 2);

    const wheelZOffset = cLength * 0.32;
    const wheelXOffset = cWidth / 2 + 0.05;

    const wheelPos = [
      [-wheelXOffset, wRadius, wheelZOffset],
      [wheelXOffset, wRadius, wheelZOffset],
      [-wheelXOffset, wRadius, -wheelZOffset],
      [wheelXOffset, wRadius, -wheelZOffset],
    ];

    wheelPos.forEach(([wx, wy, wz]) => {
      const wheel = new THREE.Mesh(wheelGeo, wheelMat);
      wheel.position.set(wx, wy, wz);
      wheel.castShadow = true;
      group.add(wheel);

      const rim = new THREE.Mesh(rimGeo, rimMat);
      rim.position.set(wx, wy, wz);
      group.add(rim);
    });

    // Front Headlights
    const hlX = cWidth * 0.38;
    const hlY = rideHeight + cHeight * 0.65;
    const hlZ = cLength / 2 + 0.02;

    const hlGeo = new THREE.BoxGeometry(0.32, 0.2, 0.08);
    const hlMat = new THREE.MeshBasicMaterial({ color: 0xffffff });

    const leftHL = new THREE.Mesh(hlGeo, hlMat);
    leftHL.position.set(-hlX, hlY, hlZ);
    group.add(leftHL);

    const rightHL = new THREE.Mesh(hlGeo, hlMat);
    rightHL.position.set(hlX, hlY, hlZ);
    group.add(rightHL);

    // Forward SpotLight Headlights
    const spotTargetL = new THREE.Object3D();
    spotTargetL.position.set(-hlX, 0.5, hlZ + 25);
    group.add(spotTargetL);

    const spotLightL = new THREE.SpotLight(0xfffaed, 3.5, 36, Math.PI / 7, 0.45, 1.2);
    spotLightL.position.set(-hlX, hlY, hlZ + 0.2);
    spotLightL.target = spotTargetL;
    spotLightL.castShadow = false;
    spotLightL.name = 'spotLightL';
    group.add(spotLightL);

    const spotTargetR = new THREE.Object3D();
    spotTargetR.position.set(hlX, 0.5, hlZ + 25);
    group.add(spotTargetR);

    const spotLightR = new THREE.SpotLight(0xfffaed, 3.5, 36, Math.PI / 7, 0.45, 1.2);
    spotLightR.position.set(hlX, hlY, hlZ + 0.2);
    spotLightR.target = spotTargetR;
    spotLightR.castShadow = false;
    spotLightR.name = 'spotLightR';
    group.add(spotLightR);

    // Red Tail / Brake Lights
    const tlMat = new THREE.MeshBasicMaterial({ color: 0xff1111 });
    const leftTL = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.16, 0.08), tlMat);
    leftTL.position.set(-hlX, hlY, -cLength / 2 - 0.02);
    group.add(leftTL);

    const rightTL = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.16, 0.08), tlMat);
    rightTL.position.set(hlX, hlY, -cLength / 2 - 0.02);
    group.add(rightTL);

    return group;
  }

  /**
   * Create Realistic 3D Asphalt Road Segment with concrete sidewalk curbs,
   * yellow dashed centerline lane markings, and pedestrian crosswalks.
   */
  public static createRoadMesh(
    width: number,
    length: number,
    angle: number = 0,
    isCrosswalk = false
  ): THREE.Group {
    const group = new THREE.Group();

    // Dark Asphalt Surface
    const asphaltMat = new THREE.MeshStandardMaterial({
      color: 0x181a20, // dark matte asphalt
      roughness: 0.92,
      metalness: 0.05,
    });
    const roadPlaneGeo = new THREE.PlaneGeometry(width, length);
    roadPlaneGeo.rotateX(-Math.PI / 2);
    const roadPlane = new THREE.Mesh(roadPlaneGeo, asphaltMat);
    roadPlane.position.y = 0.025; // slightly above ground mesh to prevent z-fighting
    roadPlane.receiveShadow = true;
    group.add(roadPlane);

    // Concrete Sidewalk Curbs on left and right borders
    const curbMat = new THREE.MeshStandardMaterial({
      color: 0x71717a, // sidewalk concrete
      roughness: 0.85,
    });
    const curbWidth = 0.55;
    const curbHeight = 0.12;
    const curbGeo = new THREE.BoxGeometry(curbWidth, curbHeight, length);

    const leftCurb = new THREE.Mesh(curbGeo, curbMat);
    leftCurb.position.set(-width / 2 + curbWidth / 2, curbHeight / 2 + 0.02, 0);
    leftCurb.receiveShadow = true;
    group.add(leftCurb);

    const rightCurb = new THREE.Mesh(curbGeo, curbMat);
    rightCurb.position.set(width / 2 - curbWidth / 2, curbHeight / 2 + 0.02, 0);
    rightCurb.receiveShadow = true;
    group.add(rightCurb);

    // Solid Outer White Shoulder Lines
    const whiteLineMat = new THREE.MeshBasicMaterial({ color: 0xf4f4f5 });
    const shoulderGeo = new THREE.BoxGeometry(0.18, 0.015, length);

    const leftWhite = new THREE.Mesh(shoulderGeo, whiteLineMat);
    leftWhite.position.set(-width / 2 + curbWidth + 0.25, 0.035, 0);
    group.add(leftWhite);

    const rightWhite = new THREE.Mesh(shoulderGeo, whiteLineMat);
    rightWhite.position.set(width / 2 - curbWidth - 0.25, 0.035, 0);
    group.add(rightWhite);

    // Yellow Dashed Centerline Markings
    const yellowMat = new THREE.MeshBasicMaterial({ color: 0xfacc15 });
    const dashLength = 2.4;
    const gap = 2.2;
    const step = dashLength + gap;
    const numDashes = Math.floor(length / step);
    const startZ = -((numDashes - 1) * step) / 2;

    for (let i = 0; i < numDashes; i++) {
      const dash = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.02, dashLength), yellowMat);
      dash.position.set(0, 0.035, startZ + i * step);
      group.add(dash);
    }

    // Pedestrian Zebra Crosswalk at ends or intersection
    if (isCrosswalk) {
      const zebraWidth = width - curbWidth * 2 - 0.8;
      const stripeCount = Math.floor(zebraWidth / 0.8);
      for (let zOffset of [-length / 2 + 3.0, length / 2 - 3.0]) {
        for (let s = 0; s < stripeCount; s++) {
          const stripe = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.025, 2.2), whiteLineMat);
          const xPos = -zebraWidth / 2 + s * 0.85 + 0.4;
          stripe.position.set(xPos, 0.038, zOffset);
          group.add(stripe);
        }
      }
    }

    group.rotation.y = angle;
    return group;
  }
}
