/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';
import { sounds } from './game/audio';
import { GameEngine3D } from './game/GameEngine3D';
import { GameState, HudStats, PlayerClass, WeaponType } from './game/types';
import { GameHUD } from './components/GameHUD';
import { StartMenu } from './components/StartMenu';
import { LevelTransitionModal } from './components/LevelTransitionModal';
import { GameOverModal } from './components/GameOverModal';
import { VictoryModal } from './components/VictoryModal';
import { PauseModal } from './components/PauseModal';
import { AreaMapModal } from './components/AreaMapModal';
import { MobileControls } from './components/MobileControls';

export default function App() {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<GameEngine3D | null>(null);

  const [gameState, setGameState] = useState<GameState>('START_MENU');
  const [selectedClass, setSelectedClass] = useState<PlayerClass>('commando');
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [showAreaMap, setShowAreaMap] = useState<boolean>(false);
  const [startLevel, setStartLevel] = useState<number>(1);
  const [showTouchControls, setShowTouchControls] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return (
        'ontouchstart' in window ||
        navigator.maxTouchPoints > 0 ||
        window.innerWidth < 1024
      );
    }
    return false;
  });
  const [hudStats, setHudStats] = useState<HudStats>({
    health: 100,
    maxHealth: 100,
    score: 0,
    highScore: 0,
    level: 1,
    levelName: 'Green Valley Homestead',
    levelSubtitle: 'Sunlit Farmlands & Country Cottages',
    levelKills: 0,
    targetKills: 12,
    activeWeapon: 'pistol',
    unlockedWeapons: {
      pistol: true,
      shotgun: true,
      rifle: true,
      plasma: true,
      rpg: true,
    },
    ammo: {
      pistol: 99999,
      shotgun: 35,
      rifle: 140,
      plasma: 25,
      rpg: 8,
    },
    playerClass: 'commando',
    bossHp: undefined,
    bossMaxHp: undefined,
    combo: 1,
    cameraMode: 'isometric',
    isDriving: false,
  });

  useEffect(() => {
    if (!containerRef.current) return;

    const engine = new GameEngine3D(containerRef.current);
    engineRef.current = engine;

    engine.onStateChange = (state) => {
      setGameState(state);
    };

    engine.onHudUpdate = (stats) => {
      setHudStats(stats);
    };

    engine.onToggleMap = () => {
      setShowAreaMap((prev) => !prev);
    };

    setHudStats((prev) => ({
      ...prev,
      highScore: engine.highScore,
    }));

    engine.loop(performance.now());

    return () => {
      engine.stop();
      if (engine.renderer.domElement.parentElement) {
        engine.renderer.domElement.parentElement.removeChild(engine.renderer.domElement);
      }
      engine.renderer.dispose();
    };
  }, []);

  const handleStartGame = (chosenLevel = startLevel) => {
    if (engineRef.current) {
      engineRef.current.setPlayerClass(selectedClass);
      if (chosenLevel === 1) {
        engineRef.current.startGame();
      } else {
        engineRef.current.startGame();
        engineRef.current.startLevel(chosenLevel);
      }
    }
  };

  const handleSelectLevelFromMap = (lvl: number) => {
    setStartLevel(lvl);
    if (gameState === 'START_MENU') {
      handleStartGame(lvl);
    } else {
      if (engineRef.current) {
        engineRef.current.startLevel(lvl);
      }
    }
    setShowAreaMap(false);
  };

  const handleSelectClass = (cls: PlayerClass) => {
    setSelectedClass(cls);
    if (engineRef.current) {
      engineRef.current.setPlayerClass(cls);
    }
  };

  const handleContinueNextLevel = () => {
    if (engineRef.current) {
      const nextLvl = engineRef.current.currentLevel + 1;
      engineRef.current.startLevel(nextLvl);
    }
  };

  const handleRestart = () => {
    if (engineRef.current) {
      engineRef.current.restartGame();
    }
  };

  const handleTogglePause = () => {
    if (!engineRef.current) return;
    if (gameState === 'PLAYING') {
      engineRef.current.pauseGame();
    } else if (gameState === 'PAUSED') {
      engineRef.current.resumeGame();
    }
  };

  const handleToggleMute = () => {
    const muted = sounds.toggleMute();
    setIsMuted(muted);
  };

  const handleToggleCamera = () => {
    if (engineRef.current) {
      engineRef.current.toggleCameraMode();
    }
  };

  const handleSelectWeapon = (weapon: WeaponType) => {
    if (engineRef.current) {
      engineRef.current.selectWeapon(weapon);
    }
  };

  return (
    <main className="relative w-screen h-screen overflow-hidden bg-[#0d0d0f] text-[#e4e4e7] flex flex-col items-center justify-center select-none font-sans">
      {/* 3D Three.js Container */}
      <div
        ref={containerRef}
        className="relative w-full h-full cursor-crosshair overflow-hidden"
      >
        {/* Subtle Vignette Overlay */}
        <div className="vignette pointer-events-none" />

        {/* In-Game HUD (during gameplay and pause) */}
        {gameState !== 'START_MENU' && (
          <>
            <GameHUD
              stats={hudStats}
              engine={engineRef.current}
              isPaused={gameState === 'PAUSED'}
              onTogglePause={handleTogglePause}
              isMuted={isMuted}
              onToggleMute={handleToggleMute}
              onToggleCamera={handleToggleCamera}
              onSelectWeapon={handleSelectWeapon}
              onOpenMap={() => setShowAreaMap(true)}
              showTouchControls={showTouchControls}
              onToggleTouchControls={() => setShowTouchControls((prev) => !prev)}
            />

            {/* Mobile On-Screen Touch Controls */}
            {showTouchControls && (
              <MobileControls
                engine={engineRef.current}
                stats={hudStats}
                onOpenMap={() => setShowAreaMap(true)}
                onTogglePause={handleTogglePause}
                onToggleCamera={handleToggleCamera}
                isPaused={gameState === 'PAUSED'}
              />
            )}
          </>
        )}

        {/* Start Menu Overlay */}
        {gameState === 'START_MENU' && (
          <StartMenu
            highScore={hudStats.highScore}
            selectedClass={selectedClass}
            onSelectClass={handleSelectClass}
            onStartGame={() => handleStartGame(startLevel)}
            startLevel={startLevel}
            onSelectStartLevel={(lvl) => setStartLevel(lvl)}
            onOpenMap={() => setShowAreaMap(true)}
          />
        )}

        {/* Level Transition Overlay */}
        {gameState === 'LEVEL_TRANSITION' && (
          <LevelTransitionModal
            currentLevel={hudStats.level}
            nextLevel={hudStats.level + 1}
            score={hudStats.score}
            onContinue={handleContinueNextLevel}
          />
        )}

        {/* Pause Overlay */}
        {gameState === 'PAUSED' && (
          <PauseModal
            onResume={handleTogglePause}
            onRestart={handleRestart}
            isMuted={isMuted}
            onToggleMute={handleToggleMute}
            onOpenMap={() => setShowAreaMap(true)}
          />
        )}

        {/* Tactical Area Map Modal (Accessible anywhere via M key or Map buttons) */}
        {showAreaMap && (
          <AreaMapModal
            currentLevel={hudStats.level}
            onSelectLevel={handleSelectLevelFromMap}
            onClose={() => setShowAreaMap(false)}
          />
        )}

        {/* Game Over Overlay */}
        {gameState === 'GAME_OVER' && (
          <GameOverModal
            score={hudStats.score}
            highScore={hudStats.highScore}
            totalKills={engineRef.current?.playerStats.totalKills || 0}
            level={hudStats.level}
            onRestart={handleRestart}
          />
        )}

        {/* Victory Overlay */}
        {gameState === 'VICTORY' && (
          <VictoryModal
            score={hudStats.score}
            highScore={hudStats.highScore}
            totalKills={engineRef.current?.playerStats.totalKills || 0}
            healthRemaining={hudStats.health}
            onPlayAgain={handleRestart}
          />
        )}
      </div>
    </main>
  );
}
